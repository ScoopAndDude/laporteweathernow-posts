// Newsletter signup (Netlify Forms). Works for every <form data-newsletter> on the page.
// Submissions show up in Netlify under Site > Forms > "newsletter".
(function () {
  // Only suggest a town the visitor actually picked (not the La Porte default
  // everyone sees), so signups aren't mis-tagged.
  function savedLocation() {
    try {
      const chose = localStorage.getItem("lpwn_custom_location") || localStorage.getItem("lpwn_location");
      if (!chose || typeof getCurrentLocation !== "function") return null;
      return getCurrentLocation();
    } catch (e) { return null; }
  }

  // Which box a sign-up came from: the page, plus the box's own label when it has one
  // (data-source="in-scoop" on /daily-scoop gives "/daily-scoop#in-scoop"), so the
  // Newsletter tab and the visit counts show which boxes bring readers in.
  function where(form) {
    const tag = form.getAttribute("data-source");
    return (location.pathname || "/") + (tag ? "#" + tag : "");
  }

  function prepare(form) {
    const town = form.querySelector('[name="town"]');
    const source = form.querySelector('[name="source"]');
    if (source) source.value = where(form);
    const loc = savedLocation();
    if (town && !town.value && loc && loc.name) town.value = loc.name;
  }

  // Oct. 11, 2026: people who join the Thursday email (forms "newsletter" and "weekend-list",
  // the same list the welcome email covers) get the free La Porte County Winter Storm Prep
  // Planner, a PDF made in Canva. The box says so, and the thanks line has the download link.
  // The golf outlook list doesn't offer it. Both lines only show when this script runs, so
  // nobody is promised a link they won't see.
  const PLANNER = "/la-porte-county-winter-storm-planner.pdf";
  const PLANNER_LISTS = ["newsletter", "weekend-list"];

  function offersPlanner(form) {
    return PLANNER_LISTS.indexOf(form.getAttribute("name")) !== -1;
  }

  function plannerNote(form) {
    if (!offersPlanner(form) || form.querySelector(".newsletter-gift")) return;
    const note = document.createElement("p");
    note.className = "newsletter-gift";
    note.textContent = "Sign up and get our free La Porte County Winter Storm Prep Planner (PDF).";
    // Its own line: in the boxes laid out as a row it takes the full width; in the
    // stacked ones (home page top, Field Day and Hard Hat thanks pages) it gets a gap above.
    const row = getComputedStyle(form).display.indexOf("flex") !== -1;
    note.style.flexBasis = "100%";
    note.style.maxWidth = "none";
    note.style.margin = row ? "0" : "8px 0 0";
    note.style.fontSize = "13.5px";
    note.style.fontWeight = "600";
    const status = form.querySelector(".newsletter-status");
    if (status) status.parentNode.insertBefore(note, status);
    else form.appendChild(note);
  }

  function thanks(form, status) {
    status.textContent = "Thanks, you're on the list! Watch your inbox for the next update.";
    if (!offersPlanner(form)) return;
    const link = document.createElement("a");
    link.href = PLANNER;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = "Download your free Winter Storm Prep Planner (PDF)";
    link.style.color = "inherit";
    link.style.textDecoration = "underline";
    link.addEventListener("click", () => {
      if (typeof lpwnTrack === "function") lpwnTrack("planner-download", where(form));
    });
    status.appendChild(document.createTextNode(" "));
    status.appendChild(link);
  }

  function beforeSend(form) {
    // Coordinates only go along when the visitor kept the town we suggested.
    const town = form.querySelector('[name="town"]');
    const lat = form.querySelector('[name="lat"]');
    const lon = form.querySelector('[name="lon"]');
    const loc = savedLocation();
    const keep = town && loc && town.value.trim() === loc.name;
    if (lat) lat.value = keep ? Number(loc.lat).toFixed(3) : "";
    if (lon) lon.value = keep ? Number(loc.lon).toFixed(3) : "";
  }

  document.querySelectorAll("form[data-newsletter]").forEach((form) => {
    prepare(form);
    plannerNote(form);
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const status = form.querySelector(".newsletter-status");
      const btn = form.querySelector('button[type="submit"]');
      beforeSend(form);
      if (btn) btn.disabled = true;
      try {
        const res = await fetch("/", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams(new FormData(form)).toString(),
        });
        if (!res.ok) throw new Error(String(res.status));
        form.reset();
        // reset() leaves hidden fields alone, so clear them too (the trip only
        // goes along when its box is checked again).
        form.querySelectorAll('input[type="hidden"]:not([name="form-name"])').forEach((el) => { el.value = ""; });
        const optIn = form.querySelector("#tripOptIn");
        if (optIn) optIn.dispatchEvent(new Event("change"));
        prepare(form);
        if (status) thanks(form, status);
        if (typeof lpwnTrack === "function") lpwnTrack("newsletter-signup", where(form));
      } catch (err) {
        if (status) status.textContent = "Sorry, that didn't go through. Please try again in a minute.";
      } finally {
        if (btn) btn.disabled = false;
      }
    });
  });
})();
