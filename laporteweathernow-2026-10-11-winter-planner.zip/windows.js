// Field Day and Hard Hat: map pin plus the next five mornings.
// Loaded after workday.js. Uses the same call engine, so a card matches the 5 AM text.

function wdEnsureChrome() {
  if (document.getElementById("wd-windows-css")) return;
  const s = document.createElement("style");
  s.id = "wd-windows-css";
  s.textContent = [
    ".wd-pinmap{height:240px;border-radius:16px;margin-top:12px;border:1px solid var(--line,#2b2f36);z-index:0;background:#1c2128}",
    ".wd-pin{background:transparent;border:0}",
    ".wd-pin span{display:block;width:18px;height:18px;border-radius:50%;background:#e5484d;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.45)}",
    ".wd-windows{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin:0 0 14px}",
    "@media (max-width:720px){.wd-windows{grid-template-columns:repeat(2,minmax(0,1fr))}}",
    ".wd-win{display:flex;flex-direction:column;align-items:flex-start;gap:2px;text-align:left;padding:10px 12px;border-radius:14px;border:1px solid var(--line,#2b2f36);background:transparent;color:inherit;min-height:44px;width:100%}",
    ".wd-win[aria-pressed=true]{outline:2px solid currentColor;outline-offset:1px}",
    ".wd-win-day{font-weight:700}",
    ".wd-win-date,.wd-win-note{font-size:.78rem;opacity:.75}",
    ".wd-win-call{font-size:.72rem;font-weight:800;letter-spacing:.04em}",
    ".wd-win-go .wd-win-call{color:var(--go,#2fb36b)}",
    ".wd-win-delay .wd-win-call{color:var(--delay,#f2a900)}",
    ".wd-win-stop .wd-win-call{color:var(--stop,#e5484d)}",
  ].join("");
  document.head.appendChild(s);
}

/** One card per day for the next five days. Clicking a card is the page's job (data-win is the date). */
function wdWindowsHtml(point, tradeKey, opts) {
  wdEnsureChrome();
  const o = opts || {};
  const now = o.now || new Date();
  const today = ymdInZone(now, point.tz);
  const cards = [];
  for (let i = 0; i < 5; i++) {
    const ymd = addDaysYmd(today, i);
    let r;
    try {
      r = wdCallFor(point, tradeKey, ymd, o);
    } catch (e) {
      continue;
    }
    if (!r) continue;
    const short = i === 0 ? "Today" : i === 1 ? "Tomorrow" : weekdayOfYmd(ymd, "short");
    let note = "No window";
    if (r.call === "go" && r.until) note = "Wrap " + wdTimeText(r.until, point.tz);
    else if (r.call === "go") note = "Open";
    else if (r.call === "delay" && r.startAt) note = "Opens " + wdTimeText(r.startAt, point.tz);
    else if (r.call === "stop" && r.longest && r.longest.len) note = "Only " + r.longest.len + "h";
    else if (r.call === "unknown") note = r.over ? "Workday over" : "Forecast short";
    else if (r.over) note = "Workday over";
    cards.push(
      `<button type="button" class="wd-win wd-win-${r.call || "unknown"}" data-win="${ymd}" aria-pressed="false">` +
        `<span class="wd-win-day">${escapeHtml(short)}</span>` +
        `<span class="wd-win-date">${escapeHtml(monthDayOfYmd(ymd))}</span>` +
        `<span class="wd-win-call">${escapeHtml(r.label || "")}</span>` +
        `<span class="wd-win-note">${escapeHtml(note)}</span>` +
      `</button>`
    );
  }
  return `<div class="wd-windows" role="group" aria-label="The next five days">${cards.join("")}</div>`;
}

/** Drop a pin. onPick(lat, lon) fires when the map is tapped. Returns { move(lat, lon) }. */
function wdPinMap(id, lat, lon, onPick) {
  wdEnsureChrome();
  const el = document.getElementById(id);
  if (!el || !window.L) return null;
  const map = L.map(el, { scrollWheelZoom: false }).setView([lat, lon], 11);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 18,
    attribution: "&copy; OpenStreetMap",
  }).addTo(map);
  const icon = L.divIcon({ className: "wd-pin", html: "<span></span>", iconSize: [18, 18], iconAnchor: [9, 9] });
  const marker = L.marker([lat, lon], { icon: icon }).addTo(map);
  map.on("click", function (e) {
    const nextLat = Math.round(e.latlng.lat * 1e4) / 1e4;
    const nextLon = Math.round(e.latlng.lng * 1e4) / 1e4;
    marker.setLatLng([nextLat, nextLon]);
    onPick(nextLat, nextLon);
  });
  setTimeout(function () { map.invalidateSize(); }, 60);
  return {
    move: function (a, b) {
      marker.setLatLng([a, b]);
      map.setView([a, b], Math.max(map.getZoom(), 12));
    },
  };
}
