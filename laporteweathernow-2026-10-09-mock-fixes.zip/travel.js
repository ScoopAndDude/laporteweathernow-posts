/* Indiana's official county travel status: Advisory, Watch or Warning (Oct. 6, 2026).
 *
 * Each county sets its own level under Indiana law (Indiana Code 10-14-3-29.5), and the Indiana
 * Department of Homeland Security shows them all on its county travel map. It is not a National
 * Weather Service warning, and we never set or guess a level: this passes along the county's own.
 * Read straight from the state's map when it answers; otherwise from the copy our "Homepage weather
 * copy" job saves every 15 minutes (posts repo, live branch, travel.json), shown with its time.
 *
 *   <div class="lw-travel" data-mode="full" data-nearby="Porter,St. Joseph,Starke,Lake,Marshall"></div>
 *     La Porte County's level, always, and the nearby counties'
 *   <div class="lw-travel" data-mode="elevated" data-nearby="..." hidden></div>
 *     only when one of those counties is at Advisory, Watch or Warning
 *   data-follow="place": follows the Alerts page's town (lpwnTravel.setPlace(loc)); hidden outside Indiana
 */
(function () {
  "use strict";
  var LAYER = "https://services8.arcgis.com/mRWfR9ONMmLivkAh/arcgis/rest/services/WebEOC_prod_TravelAdvisories/FeatureServer/0/query";
  var COPY = "https://raw.githubusercontent.com/ScoopAndDude/laporteweathernow-posts/live/travel.json";
  var MAP = "https://www.in.gov/dhs/travel-advisory-map/";
  var LAW = "https://codes.findlaw.com/in/title-10-public-safety/in-code-sect-10-14-3-29-5/";
  var NWS = "https://api.weather.gov";
  var TZ = "America/Chicago";
  var HOME = "LaPorte", HOME_LAT = 41.6081, HOME_LON = -86.7189;
  var COPY_MAX_MIN = 180;   // a saved copy older than 3 hours isn't shown
  var LEVELS = {
    warning: { rank: 3, badge: "Warning", means: "Don't travel. Travel may be limited to emergency workers." },
    watch: { rank: 2, badge: "Watch", means: "Only essential travel, like to and from work or in an emergency." },
    advisory: { rank: 1, badge: "Advisory", means: "Use caution. Some roads or areas may be dangerous or closed; avoid them if you can." },
    none: { rank: 0, badge: "None", means: "" }
  };

  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function get(url, ms, accept) {
    var c = typeof AbortController === "function" ? new AbortController() : null;
    var t = setTimeout(function () { if (c) c.abort(); }, ms || 8000);
    var opt = { signal: c ? c.signal : undefined, cache: "no-cache" };
    if (accept) opt.headers = { Accept: accept };
    return fetch(url, opt).then(function (r) { clearTimeout(t); if (!r.ok) throw new Error(r.status); return r.json(); });
  }
  function key(name) { return String(name || "").toLowerCase().replace(/^saint\b/, "st").replace(/[^a-z]/g, ""); }
  function countyLabel(n) {
    if (n === "LaPorte") return "La Porte County";
    if (n === "Dekalb") return "DeKalb County";
    if (/band$/i.test(n)) return n;
    return n + " County";
  }
  function level(status) {
    var s = String(status || "");
    if (/warning/i.test(s)) return "warning";
    if (/watch/i.test(s)) return "watch";
    if (/advisory/i.test(s)) return "advisory";
    if (!s || /no elevated|normal|none/i.test(s)) return "none";
    return "advisory";   // a level we don't know: show it as raised, with the county's own word
  }
  function when(ms) {
    if (!ms) return "";
    var d = new Date(ms), f = function (o) { return new Intl.DateTimeFormat("en-US", Object.assign({ timeZone: TZ }, o)).format(d); };
    var today = f({ year: "numeric", month: "2-digit", day: "2-digit" }) === new Intl.DateTimeFormat("en-US", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
    var t = f({ hour: "numeric", minute: "2-digit" }).replace(" AM", " a.m.").replace(" PM", " p.m.");
    return today ? t : t + " " + f({ weekday: "short" }) + ".";
  }
  function clockOf(d) { return new Intl.DateTimeFormat("en-US", { timeZone: TZ, hour: "numeric", minute: "2-digit" }).format(d).replace(" AM", " a.m.").replace(" PM", " p.m."); }

  // ---------- data: { rows: {name: {status, changed(ms)}}, from: "live"|"copy", at: Date }
  function fromLayer(d) {
    if (!d || d.error || !d.features) throw new Error("map");
    var rows = {};
    d.features.forEach(function (f) {
      var a = f.attributes || {};
      if (a.orginating_county) rows[String(a.orginating_county).trim()] = { status: a.countytravelstatus, changed: a.traveldatetime };
    });
    return rows;
  }
  var copyPromise = null;
  function copy() {
    if (!copyPromise) copyPromise = get(COPY, 8000).then(function (c) {
      var at = new Date(c.checked), rows = {};
      if (!c.counties || isNaN(at) || (Date.now() - at.getTime()) / 60000 > COPY_MAX_MIN) throw new Error("old copy");
      Object.keys(c.counties).forEach(function (n) { var v = c.counties[n]; rows[n] = { status: v.status, changed: v.changed ? Date.parse(v.changed) : null }; });
      return { rows: rows, from: "copy", at: at };
    });
    var p = copyPromise; setTimeout(function () { if (copyPromise === p) copyPromise = null; }, 60000);
    return p;
  }
  function byNames(names) {
    var where = "orginating_county IN (" + names.map(function (n) { return "'" + n.replace(/'/g, "''") + "'"; }).join(",") + ")";
    var q = "?where=" + encodeURIComponent(where) + "&outFields=orginating_county,countytravelstatus,traveldatetime&returnGeometry=false&f=json";
    return get(LAYER + q, 6000).then(function (d) { return { rows: fromLayer(d), from: "live", at: new Date() }; })
      .catch(function () { return copy(); });
  }
  // The county a point is in: from the state's map, or (if it doesn't answer) the NWS county name and our copy.
  function byPoint(lat, lon) {
    var q = "?geometry=" + (+lon).toFixed(4) + "," + (+lat).toFixed(4) + "&geometryType=esriGeometryPoint&inSR=4326&spatialRel=esriSpatialRelIntersects" +
      "&outFields=orginating_county,countytravelstatus,traveldatetime&returnGeometry=false&f=json";
    return get(LAYER + q, 6000).then(function (d) {
      var rows = fromLayer(d), names = Object.keys(rows).filter(function (n) { return !/band$/i.test(n); });
      return { rows: rows, from: "live", at: new Date(), county: names[0] || null };
    }).catch(function () {
      return get(NWS + "/points/" + (+lat).toFixed(4) + "," + (+lon).toFixed(4), 8000, "application/geo+json").then(function (pt) {
        var z = String((pt.properties || {}).county || "");
        if (!/\/INC\d{3}$/.test(z)) return { rows: {}, from: "none", county: null };
        return get(z, 8000, "application/geo+json").then(function (zone) {
          var want = key((zone.properties || {}).name);
          return copy().then(function (c) {
            var hit = Object.keys(c.rows).filter(function (n) { return key(n) === want; })[0];
            c.county = hit || null;
            return c;
          });
        });
      });
    });
  }

  // ---------- drawing
  var STYLE = ".lwt{background:var(--card,#fff);border-radius:var(--radius,14px);box-shadow:var(--shadow,0 1px 3px rgba(0,0,0,.12));padding:14px 18px;margin:14px 0;border-left:6px solid var(--line,#e2e2e2);color:var(--ink,#171717);text-align:start}" +
    ".lwt.lv-advisory{border-left-color:#e3c800}.lwt.lv-watch{border-left-color:#f78f07}.lwt.lv-warning{border-left-color:#d7261e}" +
    ".lwt-h{font-weight:800;font-size:16px;margin:0 0 2px}.lwt-sub{font-size:13px;color:var(--ink-soft,#52525b);margin:0 0 10px}" +
    ".lwt-list{list-style:none;margin:0;padding:0;display:grid;gap:10px}.lwt-row{display:grid;grid-template-columns:84px minmax(0,1fr);gap:10px;align-items:start;font-size:15px;line-height:1.45}" +
    ".lwt-badge{display:block;margin-top:1px;text-align:center;font-size:11px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;padding:3px 8px;border-radius:999px;background:var(--cream,#fafafa);color:var(--ink-soft,#52525b);border:1px solid var(--line,#e2e2e2)}" +
    ".lv-advisory>.lwt-badge{background:#fcfe41;color:#1a1a1a;border-color:#d8c800}.lv-watch>.lwt-badge{background:#f78f07;color:#1a1a1a;border-color:#d97a00}.lv-warning>.lwt-badge{background:#d7261e;color:#fff;border-color:#b01e17}" +
    ".lwt-means{margin-top:2px;color:var(--ink,#171717)}.lwt-time{color:var(--ink-soft,#52525b);font-size:13px}" +
    ".lwt-foot{font-size:13px;color:var(--ink-soft,#52525b);margin:10px 0 0;line-height:1.5}.lwt-foot a,.lwt-row a{color:var(--forest,#1a1a1a);font-weight:700;text-decoration:underline;text-underline-offset:2px}" +
    ".lwt details{margin-top:8px;font-size:14px}.lwt summary{cursor:pointer;font-weight:700}.lwt dl{margin:8px 0 0}.lwt dt{font-weight:800;margin-top:6px}.lwt dd{margin:0}";
  function style() {
    if (document.getElementById("lwt-style")) return;
    var s = el("style"); s.id = "lwt-style"; s.textContent = STYLE; document.head.appendChild(s);
  }
  function explain() {
    var d = el("details"), dl = el("dl");
    d.appendChild(el("summary", null, "What the levels mean"));
    [["Advisory (yellow)", LEVELS.advisory.means], ["Watch (orange)", LEVELS.watch.means], ["Warning (red)", LEVELS.warning.means + " Directed to stay off the roads; it takes a local disaster declaration."]]
      .forEach(function (x) { dl.appendChild(el("dt", null, x[0])); dl.appendChild(el("dd", null, x[1])); });
    d.appendChild(dl);
    var p = el("p", "lwt-foot", "Set by each county under Indiana law. ");
    var a = el("a", null, "Indiana Code 10-14-3-29.5"); a.href = LAW; a.target = "_blank"; a.rel = "noopener";
    p.appendChild(a); p.appendChild(document.createTextNode("."));
    d.appendChild(p);
    return d;
  }
  function row(name, r, full) {
    var lv = level(r && r.status), L = LEVELS[lv];
    var li = el("li", "lwt-row lv-" + lv), body = el("div", "lwt-body");
    li.appendChild(el("span", "lwt-badge", lv === "none" ? "None" : (/^(warning|watch|advisory)$/i.test(String(r.status).trim()) ? L.badge : String(r.status))));
    body.appendChild(el("strong", null, countyLabel(name)));
    if (lv !== "none") {
      if (r.changed) body.appendChild(el("span", "lwt-time", " \u00b7 since " + when(r.changed)));
      body.appendChild(el("div", "lwt-means", L.means));
    }
    li.appendChild(body);
    return li;
  }
  function draw(box, data, names, full) {
    var shown = names.filter(function (n) { return data.rows[n]; });
    var up = shown.filter(function (n) { return level(data.rows[n].status) !== "none"; });
    if (!full) shown = up;
    if (!shown.length) { box.hidden = true; box.textContent = ""; return; }
    var top = shown.reduce(function (m, n) { var lv = level(data.rows[n].status); return LEVELS[lv].rank > LEVELS[m].rank ? lv : m; }, "none");
    var card = el("div", "lwt lv-" + top);
    card.appendChild(el("p", "lwt-h", full ? "County travel status" : "County travel " + (up.length === 1 ? "level" : "levels") + " in effect"));
    card.appendChild(el("p", "lwt-sub", "Indiana's official travel levels, set by each county. Not a Weather Service warning."));
    var ul = el("ul", "lwt-list");
    shown.forEach(function (n) { ul.appendChild(row(n, data.rows[n], full)); });
    card.appendChild(ul);
    var foot = el("p", "lwt-foot", data.from === "live"
      ? "Checked " + clockOf(data.at) + " Central from Indiana's county travel map. "
      : "As of " + clockOf(data.at) + " Central (our saved copy; the state's map didn't answer just now). ");
    var a = el("a", null, "Indiana's county travel map ↗"); a.href = MAP; a.target = "_blank"; a.rel = "noopener";
    foot.appendChild(a);
    card.appendChild(foot);
    card.appendChild(explain());
    box.textContent = "";
    box.appendChild(card);
    box.setAttribute("role", "status");
    box.hidden = false;
  }
  function unavailable(box) {
    box.textContent = "";
    var p = el("p", "lwt-foot", "Couldn't reach Indiana's county travel map just now. ");
    var a = el("a", null, "Open the map ↗"); a.href = MAP; a.target = "_blank"; a.rel = "noopener";
    p.appendChild(a);
    var card = el("div", "lwt"); card.appendChild(el("p", "lwt-h", "County travel status")); card.appendChild(p);
    box.appendChild(card); box.hidden = false;
  }

  // ---------- each box
  var place = null;   // the Alerts page's town, when it isn't La Porte
  function nearbyOf(box) { return String(box.getAttribute("data-nearby") || "").split(",").map(function (s) { return s.trim(); }).filter(Boolean); }
  function isHome(loc) { return !loc || (Math.abs(loc.lat - HOME_LAT) < 0.03 && Math.abs(loc.lon - HOME_LON) < 0.03); }
  function refresh(box) {
    var full = box.getAttribute("data-mode") === "full";
    var follow = box.getAttribute("data-follow") === "place";
    var seq = (box._seq = (box._seq || 0) + 1);
    var job;
    if (follow && place && !isHome(place)) {
      job = byPoint(place.lat, place.lon).then(function (d) {
        if (!d.county) return { hide: true };
        return { data: d, names: d.county === HOME ? [HOME].concat(nearbyOf(box)) : [d.county] };
      });
    } else {
      var names = [HOME].concat(nearbyOf(box));
      job = byNames(names).then(function (d) { return { data: d, names: names }; });
    }
    job.then(function (r) {
      if (seq !== box._seq) return;
      if (r.hide) { box.hidden = true; box.textContent = ""; return; }
      draw(box, r.data, r.names, full);
    }).catch(function () {
      if (seq !== box._seq) return;
      if (full) unavailable(box); else { box.hidden = true; box.textContent = ""; }
    });
  }
  function all() { Array.prototype.forEach.call(document.querySelectorAll(".lw-travel"), refresh); }

  function toPlace(loc) { return loc && isFinite(loc.lat) && isFinite(loc.lon) ? { lat: +loc.lat, lon: +loc.lon } : null; }
  // The Alerts page may name its town before this file loads (window.lpwnTravel = { q: [...] }).
  var api = window.lpwnTravel, queued = api && api.q && api.q.length ? api.q[api.q.length - 1] : null;
  window.lpwnTravel = {
    setPlace: function (loc) {
      place = toPlace(loc);
      Array.prototype.forEach.call(document.querySelectorAll('.lw-travel[data-follow="place"]'), refresh);
    }
  };
  function start() {
    if (!window.fetch || !document.querySelector(".lw-travel")) return;
    style();
    if (queued) place = toPlace(queued);
    all();
    setInterval(function () { if (!document.hidden) all(); }, 5 * 60 * 1000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
