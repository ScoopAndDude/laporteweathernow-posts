/* Live National Weather Service blocks for the town pages and Friday night forecasts (Oct. 6, 2026).
 *
 *   <div class="lw" data-lat="41.7344" data-lon="-86.8731" data-name="Michigan City"></div>
 *     -> active alerts, the latest reading at the nearest NWS station, the next 12 hours and 7 days
 *   <div class="lw-friday" data-towns='[{"name":"La Porte","lat":41.61,"lon":-86.72}, ...]'></div>
 *     -> Friday 7 p.m. (kickoff) forecast for each town
 *
 * Every time is shown in La Porte's time (Central), whatever time zone the NWS office uses.
 * The page's own text stays if NWS doesn't answer; nothing here is made up. */
(function () {
  "use strict";
  var TZ = "America/Chicago";
  var API = "https://api.weather.gov";

  function get(url, ms) {
    var c = typeof AbortController === "function" ? new AbortController() : null;
    var t = setTimeout(function () { if (c) c.abort(); }, ms || 12000);
    return fetch(url, { headers: { Accept: "application/geo+json" }, signal: c ? c.signal : undefined })
      .then(function (r) { clearTimeout(t); if (!r.ok) throw new Error("NWS " + r.status); return r.json(); });
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function fmt(d, opts) {
    try { return new Intl.DateTimeFormat("en-US", Object.assign({ timeZone: TZ }, opts)).format(d); }
    catch (e) { return d.toLocaleString(); }
  }
  function hourLabel(iso) { return fmt(new Date(iso), { hour: "numeric" }).replace(" AM", " a.m.").replace(" PM", " p.m."); }
  function clock(d) { return fmt(d, { hour: "numeric", minute: "2-digit" }).replace(" AM", " a.m.").replace(" PM", " p.m."); }
  function pop(p) { var v = p && p.probabilityOfPrecipitation && p.probabilityOfPrecipitation.value; return v == null ? null : Math.round(v); }
  function cToF(c) { return c == null ? null : Math.round(c * 9 / 5 + 32); }

  function alertsBox(al) {
    var box = el("div", "lw-alerts");
    var list = (al && al.features) || [];
    if (!list.length) {
      box.appendChild(el("p", "lw-ok", "No National Weather Service watches, warnings or advisories here right now."));
      return box;
    }
    box.classList.add("on");
    var h = el("p", "lw-alert-h", list.length === 1 ? "1 weather alert in effect:" : list.length + " weather alerts in effect:");
    box.appendChild(h);
    var ul = el("ul");
    list.slice(0, 6).forEach(function (f) {
      var p = f.properties || {};
      var li = el("li");
      li.appendChild(el("strong", null, p.event || "Alert"));
      var end = p.ends || p.expires;
      if (end) li.appendChild(document.createTextNode(" until " + fmt(new Date(end), { weekday: "short", hour: "numeric", minute: "2-digit" }).replace(" AM", " a.m.").replace(" PM", " p.m.")));
      ul.appendChild(li);
    });
    box.appendChild(ul);
    var a = el("a", null, "What to do: the Emergency view");
    a.href = "/emergency";
    box.appendChild(a);
    return box;
  }

  function nowBox(obs, stationName) {
    var p = obs && obs.properties;
    if (!p || !p.temperature || p.temperature.value == null) return null;
    var box = el("div", "lw-now");
    box.appendChild(el("div", "lw-temp", cToF(p.temperature.value) + "°F"));
    var side = el("div");
    side.appendChild(el("div", "lw-cond", p.textDescription || ""));
    var bits = [];
    if (p.windSpeed && p.windSpeed.value != null) bits.push("Wind " + Math.round(p.windSpeed.value * 0.621371) + " mph");
    if (p.windGust && p.windGust.value != null) bits.push("gusts " + Math.round(p.windGust.value * 0.621371));
    if (p.relativeHumidity && p.relativeHumidity.value != null) bits.push("humidity " + Math.round(p.relativeHumidity.value) + "%");
    if (bits.length) side.appendChild(el("div", "lw-meta", bits.join(", ")));
    side.appendChild(el("div", "lw-meta", (stationName || "Nearest NWS station") + ", " + clock(new Date(p.timestamp)) + " Central"));
    box.appendChild(side);
    return box;
  }

  function hoursBox(hr) {
    var periods = ((hr && hr.properties && hr.properties.periods) || []).slice(0, 12);
    if (!periods.length) return null;
    var wrap = el("div", "lw-block");
    wrap.appendChild(el("h3", null, "Next 12 hours"));
    var row = el("div", "lw-hours");
    periods.forEach(function (p) {
      var c = el("div", "lw-hour");
      c.appendChild(el("span", "lw-h", hourLabel(p.startTime)));
      c.appendChild(el("span", "lw-t", p.temperature + "°"));
      c.appendChild(el("span", "lw-s", p.shortForecast || ""));
      var r = pop(p);
      if (r >= 20) c.appendChild(el("span", "lw-r", r + "% rain"));
      row.appendChild(c);
    });
    wrap.appendChild(row);
    return wrap;
  }

  function daysBox(fc) {
    var periods = ((fc && fc.properties && fc.properties.periods) || []).slice(0, 14);
    if (!periods.length) return null;
    var wrap = el("div", "lw-block");
    wrap.appendChild(el("h3", null, "7-day forecast"));
    var ul = el("ul", "lw-days");
    periods.forEach(function (p) {
      var li = el("li");
      li.appendChild(el("strong", null, p.name));
      var r = pop(p);
      li.appendChild(document.createTextNode(": " + (p.isDaytime ? "high " : "low ") + p.temperature + "°. " + (p.shortForecast || "") + (r >= 20 ? ", " + r + "% chance of rain or snow" : "") + "."));
      ul.appendChild(li);
    });
    wrap.appendChild(ul);
    return wrap;
  }

  function town(box) {
    var lat = box.getAttribute("data-lat"), lon = box.getAttribute("data-lon");
    if (!lat || !lon || !window.fetch) return;
    get(API + "/points/" + lat + "," + lon).then(function (pt) {
      var pr = pt.properties;
      var stations = get(pr.observationStations).then(function (s) {
        var st = s.features && s.features[0];
        if (!st) return [null, null];
        return get(st.id + "/observations/latest", 10000).then(function (o) { return [o, st.properties && st.properties.name]; });
      }).catch(function () { return [null, null]; });
      return Promise.all([
        get(API + "/alerts/active?point=" + lat + "," + lon).catch(function () { return null; }),
        stations,
        get(pr.forecastHourly).catch(function () { return null; }),
        get(pr.forecast).catch(function () { return null; })
      ]);
    }).then(function (r) {
      var out = el("div", "lw-live");
      if (r[0]) out.appendChild(alertsBox(r[0]));
      var n = nowBox(r[1][0], r[1][1]);
      if (n) out.appendChild(n);
      var h = hoursBox(r[2]);
      if (h) out.appendChild(h);
      var d = daysBox(r[3]);
      if (d) out.appendChild(d);
      if (!out.children.length) return;
      out.appendChild(el("p", "lw-credit", "From the National Weather Service, checked " + clock(new Date()) + " Central."));
      box.textContent = "";
      box.appendChild(out);
    }).catch(function () { /* the page's own text stays */ });
  }

  // The next Friday at 7 p.m. in La Porte (today, if it's Friday before 9 p.m.).
  function nextFridayKickoff() {
    var now = new Date();
    for (var i = 0; i < 8; i++) {
      var d = new Date(now.getTime() + i * 86400000);
      var parts = new Intl.DateTimeFormat("en-US", { timeZone: TZ, weekday: "short", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(d);
      var o = {};
      parts.forEach(function (p) { o[p.type] = p.value; });
      if (o.weekday === "Fri") {
        var h = Number(new Intl.DateTimeFormat("en-US", { timeZone: TZ, hour: "numeric", hourCycle: "h23" }).format(now));
        if (i === 0 && h >= 21) continue;
        return { ymd: o.year + "-" + o.month + "-" + o.day, label: fmt(d, { weekday: "long", month: "long", day: "numeric" }) };
      }
    }
    return null;
  }
  function ymdHourCentral(iso) {
    var d = new Date(iso);
    var o = {};
    new Intl.DateTimeFormat("en-US", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit", hour: "numeric", hourCycle: "h23" })
      .formatToParts(d).forEach(function (p) { o[p.type] = p.value; });
    return { ymd: o.year + "-" + o.month + "-" + o.day, hour: Number(o.hour) };
  }

  function friday(box) {
    var towns;
    try { towns = JSON.parse(box.getAttribute("data-towns") || "[]"); } catch (e) { return; }
    var k = nextFridayKickoff();
    if (!k || !towns.length || !window.fetch) return;
    var head = document.getElementById("fridayWhen");
    if (head) head.textContent = k.label + ", 7 p.m. kickoff";
    towns.forEach(function (t) {
      var card = document.getElementById("fn-" + t.id);
      if (!card) return;
      var slot = card.querySelector(".fn-live");
      get(API + "/points/" + t.lat + "," + t.lon).then(function (pt) {
        var pr = pt.properties;
        return Promise.all([get(pr.forecastHourly).catch(function () { return null; }), get(pr.forecast).catch(function () { return null; })]);
      }).then(function (r) {
        var hourly = (r[0] && r[0].properties && r[0].properties.periods) || [];
        var hit = null, after = null;
        hourly.forEach(function (p) {
          var c = ymdHourCentral(p.startTime);
          if (c.ymd === k.ymd && c.hour === 19) hit = p;
          if (c.ymd === k.ymd && c.hour === 21) after = p;
        });
        slot.textContent = "";
        if (hit) {
          slot.appendChild(el("div", "fn-temp", hit.temperature + "°F at kickoff"));
          var r1 = pop(hit);
          slot.appendChild(el("div", "fn-cond", (hit.shortForecast || "") + (r1 >= 20 ? ", " + r1 + "% chance of rain" : "") + ". Wind " + (hit.windSpeed || "") + " " + (hit.windDirection || "") + "."));
          if (after) slot.appendChild(el("div", "fn-meta", "By 9 p.m.: " + after.temperature + "°F, " + (after.shortForecast || "").toLowerCase() + "."));
          if (/thunder/i.test((hit.shortForecast || "") + " " + (after ? after.shortForecast : ""))) {
            slot.appendChild(el("div", "fn-storm", "Thunderstorms possible: when thunder roars, everyone goes indoors."));
          }
          return;
        }
        // Too far out for the hour-by-hour forecast: use the 7-day "Friday Night" period.
        var periods = (r[1] && r[1].properties && r[1].properties.periods) || [];
        var night = null;
        periods.forEach(function (p) { var c = ymdHourCentral(p.startTime); if (!p.isDaytime && c.ymd === k.ymd && !night) night = p; });
        if (night) {
          var r2 = pop(night);
          slot.appendChild(el("div", "fn-temp", "Low " + night.temperature + "°F Friday night"));
          slot.appendChild(el("div", "fn-cond", (night.shortForecast || "") + (r2 >= 20 ? ", " + r2 + "% chance of rain" : "") + "."));
          slot.appendChild(el("div", "fn-meta", "The hour-by-hour forecast for kickoff shows up by midweek."));
        } else {
          slot.appendChild(el("div", "fn-meta", "The forecast for Friday night isn't out yet."));
        }
      }).catch(function () {
        slot.textContent = "The Weather Service didn't answer. Try again in a minute.";
      });
    });
  }

  function start() {
    Array.prototype.forEach.call(document.querySelectorAll(".lw[data-lat]"), town);
    Array.prototype.forEach.call(document.querySelectorAll(".lw-friday"), friday);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
