// Daily Scoop posts: where they live and how pages load them.
//
// Posts are kept in a public GitHub repository instead of in the site's files, so
// publishing a Scoop never needs a new Netlify deploy (each deploy costs credits).
// GitHub also keeps every change to the posts, with its time, in a public history.
//
// Pages load posts in this order:
//   1. the posts file on GitHub Pages (a CDN made for public websites),
//   2. the copy this browser saved on its last visit, if GitHub can't be reached,
//   3. the copy bundled with the site (scoop-posts.js), as a last resort.
//
// To publish or correct a post, use laporteweathernow.com/scoop-draft.

const SCOOP_SOURCE = {
  owner: "ScoopAndDude",
  repo: "laporteweathernow-posts",
  branch: "main",
  path: "scoop-posts.json",
};
const SCOOP_POSTS_CACHE_KEY = "lpwn_posts_v1";

function scoopLiveUrl() {
  return `https://${SCOOP_SOURCE.owner.toLowerCase()}.github.io/${SCOOP_SOURCE.repo}/${SCOOP_SOURCE.path}`;
}
function scoopApiUrl() {
  return `https://api.github.com/repos/${SCOOP_SOURCE.owner}/${SCOOP_SOURCE.repo}/contents/${SCOOP_SOURCE.path}?ref=${SCOOP_SOURCE.branch}`;
}
function scoopEditUrl() {
  return `https://github.com/${SCOOP_SOURCE.owner}/${SCOOP_SOURCE.repo}/edit/${SCOOP_SOURCE.branch}/${SCOOP_SOURCE.path}`;
}
function scoopHistoryUrl() {
  return `https://github.com/${SCOOP_SOURCE.owner}/${SCOOP_SOURCE.repo}/commits/${SCOOP_SOURCE.branch}/${SCOOP_SOURCE.path}`;
}

// ---------- Checking posts ----------
// Every post is checked before it's shown, so a typo in the posts file can't break a page:
// a post that doesn't make sense is left out, and a file that can't be read at all is
// skipped in favor of the saved or bundled copy.

const POST_YMD = /^\d{4}-\d{2}-\d{2}$/;

function cleanForecastValue(v) {
  if (Array.isArray(v)) {
    return v.length === 2 && v.every((x) => typeof x === "number" && isFinite(x)) ? [v[0], v[1]] : undefined;
  }
  return typeof v === "number" && isFinite(v) ? v : undefined;
}

function cleanForecast(f) {
  if (!f || typeof f !== "object" || !POST_YMD.test(String(f.date || ""))) return null;
  const out = { date: f.date };
  const high = cleanForecastValue(f.high);
  const low = cleanForecastValue(f.low);
  if (high !== undefined) out.high = high;
  if (low !== undefined) out.low = low;
  if (typeof f.rain === "number" && isFinite(f.rain) && f.rain >= 0 && f.rain <= 100) out.rain = f.rain;
  return out;
}

function cleanPost(p) {
  if (!p || typeof p !== "object") return null;
  const type = p.type === "weekly" ? "weekly" : (p.type === undefined || p.type === "daily") ? "daily" : null;
  if (!type || !POST_YMD.test(String(p.date || "")) || typeof p.title !== "string" || !p.title.trim()) return null;
  const text = (v) => (typeof v === "string" ? v.trim() : "");
  const time = (v) => (typeof v === "string" && isFinite(Date.parse(v)) ? v : undefined);
  const out = {
    type,
    date: p.date,
    title: p.title.trim(),
    summary: text(p.summary),
    body: (Array.isArray(p.body) ? p.body : [p.body]).map(text).filter(Boolean),
    sources: (Array.isArray(p.sources) ? p.sources : [])
      .filter((s) => s && typeof s.url === "string" && /^https?:\/\//i.test(s.url.trim()))
      .map((s) => ({ label: text(s.label) || s.url.trim(), url: s.url.trim() })),
    author: text(p.author),
  };
  const posted = time(p.posted);
  const updated = time(p.updated);
  if (posted) out.posted = posted;
  if (updated) out.updated = updated;
  if (Array.isArray(p.forecasts)) out.forecasts = p.forecasts.map(cleanForecast).filter(Boolean);
  out.corrections = (Array.isArray(p.corrections) ? p.corrections : [])
    .filter((c) => c && typeof c.text === "string" && c.text.trim())
    .map((c) => (POST_YMD.test(String(c.date || "")) ? { date: c.date, text: c.text.trim() } : { text: c.text.trim() }));
  return out;
}

/** The posts in a posts file ({posts: [...]} or a plain list), checked. Throws if it isn't a posts file. */
function parsePostsFile(data) {
  const list = Array.isArray(data) ? data : data && Array.isArray(data.posts) ? data.posts : null;
  if (!list) throw new Error("That isn't a posts file");
  return list.map(cleanPost).filter(Boolean);
}

// ---------- Saved and bundled copies ----------

function savedScoopPosts() {
  try {
    const saved = JSON.parse(localStorage.getItem(SCOOP_POSTS_CACHE_KEY) || "null");
    if (saved && Array.isArray(saved.posts)) {
      const posts = saved.posts.map(cleanPost).filter(Boolean);
      if (posts.length) return { posts, savedAt: saved.savedAt };
    }
  } catch (e) { /* private browsing or blocked storage: no saved copy */ }
  return null;
}

function saveScoopPosts(posts) {
  try { localStorage.setItem(SCOOP_POSTS_CACHE_KEY, JSON.stringify({ savedAt: Date.now(), posts })); } catch (e) { /* storage full or blocked */ }
}

function bundledScoopPosts() {
  return (Array.isArray(window.SCOOP_POSTS) ? window.SCOOP_POSTS : []).map(cleanPost).filter(Boolean);
}

/**
 * Load the posts. Resolves to { posts, source, savedAt?, raw?, problems } where source is
 *   "live"    - the posts file on GitHub Pages (what visitors normally see),
 *   "github"  - straight from GitHub's API (only with opts.fresh, for the draft helper;
 *               `raw` then holds the file's posts exactly as written),
 *   "saved"   - this browser's copy from its last visit,
 *   "bundled" - the copy that shipped with the site.
 * problems lists the sources that failed: { source, kind: "network" | "unreadable" | "empty" }.
 * Never rejects.
 */
async function loadScoopPosts(opts) {
  const o = opts || {};
  const problems = [];
  const tries = o.fresh
    // A unique address each time, so no cache anywhere can hand back an older copy.
    ? [["github", `${scoopApiUrl()}&_=${Date.now()}`, { headers: { Accept: "application/vnd.github.raw+json" }, cache: "no-store" }], ["live", scoopLiveUrl(), { cache: "no-cache" }]]
    : [["live", scoopLiveUrl(), { cache: "no-cache" }]];
  for (const [source, url, init] of tries) {
    let data;
    try {
      data = await fetchJson(url, init, o.timeout || 6000);
    } catch (e) {
      problems.push({ source, kind: e instanceof SyntaxError ? "unreadable" : "network" });
      continue;
    }
    let posts;
    try {
      posts = parsePostsFile(data);
    } catch (e) {
      problems.push({ source, kind: "unreadable" });
      continue;
    }
    if (!posts.length) { problems.push({ source, kind: "empty" }); continue; }
    saveScoopPosts(posts);
    const out = { posts, source, problems };
    if (source === "github") out.raw = Array.isArray(data) ? data : data.posts;
    return out;
  }
  const saved = savedScoopPosts();
  if (saved) return { posts: saved.posts, source: "saved", savedAt: saved.savedAt, problems };
  return { posts: bundledScoopPosts(), source: "bundled", problems };
}

/**
 * What cleanPost() would silently leave out of a raw post from the file: [] when nothing.
 * The draft helper refuses to rebuild the file while anything would be lost.
 */
function postLosses(raw) {
  const clean = cleanPost(raw);
  if (!clean) return ["the post can't be read (check its type, date, and title)"];
  const out = [];
  const len = (v) => (Array.isArray(v) ? v.length : 0);
  if (raw.posted !== undefined && !clean.posted) out.push("its posted time isn't a valid time");
  if (raw.updated !== undefined && !clean.updated) out.push("its updated time isn't a valid time");
  if (len(raw.sources) !== clean.sources.length) out.push("a source is missing its web address");
  if (len(raw.corrections) !== clean.corrections.length) out.push("a correction has no text");
  if (Array.isArray(raw.body) && raw.body.some((b) => typeof b !== "string")) out.push("a paragraph isn't text");
  if (raw.forecasts !== undefined) {
    if (!Array.isArray(raw.forecasts) || raw.forecasts.length !== (clean.forecasts || []).length) out.push("a forecast on record can't be read");
    else raw.forecasts.forEach((f, i) => {
      ["high", "low", "rain"].forEach((k) => {
        if (f && f[k] !== undefined && f[k] !== null && f[k] !== "" && clean.forecasts[i][k] === undefined) out.push(`the ${k} for ${f.date} isn't a number`);
      });
    });
  }
  return out;
}
