/* ---------- Lake Michigan (Oct. 1, 2026; shared by /weekend and /lake-michigan since Oct. 5) ----------
   NWS Northern Indiana's beach (surf zone) forecast for the La Porte County shore (zone INZ103), its
   nearshore marine forecast (Michigan City to New Buffalo, LMZ046), and active alerts for the shore and
   the nearby waters (LMZ046, and LMZ745 west of Michigan City). Loads when you scroll near it. */
(function () {
  const TZ = "America/Chicago", NWS = "https://api.weather.gov";
  const $ = (id) => document.getElementById(id);
  const ZONE_NAMES = { INZ103: "La Porte County shore", LMZ046: "Michigan City to New Buffalo", LMZ745: "Burns Harbor to Michigan City" };
  const SHORE_EVENTS = /Beach Hazards|Rip Current|Surf|Lakeshore/i;
  // Plain-language notes for the lake alerts people see most (ours, not part of the official alert).
  const MEANS = [
    [/Beach Hazards/i, "Dangerous swimming: high waves and strong currents are expected at the beaches. Stay out of the water and off the piers."],
    [/Rip Current/i, "Life-threatening currents are expected. Stay out of the water."],
    [/High Surf/i, "Large, dangerous waves are breaking along the shore. Stay off piers and back from the water's edge."],
    [/Lakeshore Flood/i, "High water and waves could flood or wash away parts of the shoreline."],
    [/Small Craft/i, "Wind or waves are hazardous to small boats. Inexperienced boaters, especially in smaller boats, should stay off the lake."],
    [/Gale/i, "Gale-force winds of 39 to 54 mph on the lake."],
    [/^Storm (Warning|Watch)/i, "Storm-force winds of 55 to 73 mph on the lake."],
    [/Hurricane Force/i, "Hurricane-force winds of 74 mph or more on the lake."],
    [/Special Marine/i, "A thunderstorm over the lake with strong winds, hail or waterspouts. Get off the water now."],
    [/Freezing Spray/i, "Spray will freeze on boats and piers."],
    [/Dense Fog/i, "Thick fog over the lake, with very low visibility."],
  ];
  // What NWS's swim risk levels mean (from the footnote in its beach forecast).
  const RISK_MEANS = {
    low: "Large waves and dangerous currents aren't expected, but dangerous currents can happen at any time near piers, breakwalls and river outlets.",
    moderate: "Breaking waves and currents are expected. Stay away from piers, breakwalls and river outlets, and always have a flotation device with you in the water.",
    high: "Life-threatening waves and currents are expected. Stay out of the water, and stay away from piers, breakwalls and river outlets.",
  };
  const WEEKDAYS = ["SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"];
  const today = () => ymdInZone(new Date(), TZ);
  const stampOf = (t) => `${fmtInZone(t, TZ, { weekday: "short" })} ${fmtClock(t, TZ)} ${zoneAbbrev(t, TZ)}`;
  const productLink = (type, label) => `<a href="https://forecast.weather.gov/product.php?site=NWS&amp;issuedby=IWX&amp;product=${type}" target="_blank" rel="noopener">${label} &#8599;</a>`;
  const titleCase = (s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();

  /* UGC codes in a product segment header, e.g. "LMZ043-046-012015-" -> ["LMZ043", "LMZ046"]. */
  function ugcCodes(ugc) {
    const out = [];
    let prefix = "";
    String(ugc).replace(/\s+/g, "").split("-").forEach((tok) => {
      const m = /^([A-Z]{2}[CZ])?(\d{3})(?:>(\d{3}))?$/.exec(tok);
      if (!m || (!m[1] && !prefix)) return;
      if (m[1]) prefix = m[1];
      for (let n = +m[2]; n <= +(m[3] || m[2]); n++) out.push(prefix + String(n).padStart(3, "0"));
    });
    return out;
  }
  /* The part of an NWS text product written for one zone. */
  function segmentFor(text, zone) {
    for (const seg of String(text || "").split("$$")) {
      const m = /(?:^|\n)([A-Z]{2}[CZ]\d{3}[\s\S]*?\d{6}-)/.exec(seg);
      if (m && ugcCodes(m[1]).includes(zone)) return seg.slice(m.index + m[0].length);
    }
    return null;
  }
  /* ".FRIDAY...text" blocks; each ends at the next block or a blank line. */
  function periodsOf(seg) {
    const out = [], re = /\n\.([A-Z][A-Z ]*?)\.\.\.([\s\S]*?)(?=\n\.[A-Z][A-Z ]*?\.\.\.|\n[ \t]*\n|$)/g;
    let m;
    while ((m = re.exec(seg))) out.push({ name: m[1].trim(), body: m[2] });
    return out;
  }
  /* The calendar day a period like "FRIDAY" or "TODAY" falls on, counting from when it was issued. */
  function periodYmd(name, issuedYmd) {
    if (/TODAY|THIS (MORNING|AFTERNOON|EVENING)|TONIGHT/.test(name)) return issuedYmd;
    const want = WEEKDAYS.findIndex((d) => name.indexOf(d) === 0);
    if (want < 0) return null;
    let ymd = issuedYmd;
    for (let i = 0; i < 7; i++, ymd = addDaysYmd(ymd, 1)) if (ymdToUTCDate(ymd).getUTCDay() === want) return ymd;
    return null;
  }
  async function latestProduct(type) {
    const list = await nwsGet(`${NWS}/products/types/${type}/locations/IWX`, 15000);
    const first = (list["@graph"] || [])[0];
    if (!first) throw new Error("none issued");
    return nwsGet(`${NWS}/products/${first.id}`, 15000);
  }

  /* ----- Alerts for the shore and the nearby water ----- */
  async function lakeAlerts() {
    const box = $("lakeAlerts");
    try {
      const d = await nwsGet(`${NWS}/alerts/active?zone=INZ103,LMZ046,LMZ745`, 15000);
      const groups = {};
      sortAlerts(liveAlerts(d.features)).forEach((a) => {
        const p = a.properties;
        const ugc = (p.geocode && p.geocode.UGC) || [];
        const marine = ugc.some((z) => /^LMZ/.test(z));
        if (!marine && !SHORE_EVENTS.test(p.event)) return;   // land alerts are on the home page
        const g = groups[p.event] || (groups[p.event] = { p: p, zones: [], senders: [], from: Infinity, to: 0 });
        ugc.forEach((z) => { if (ZONE_NAMES[z] && g.zones.indexOf(ZONE_NAMES[z]) < 0) g.zones.push(ZONE_NAMES[z]); });
        if (g.senders.indexOf(p.senderName) < 0) g.senders.push(p.senderName);
        g.from = Math.min(g.from, Date.parse(p.onset || p.effective) || Infinity);
        if (alertEndMs(p) > g.to) { g.to = alertEndMs(p); g.p = p; }
      });
      const list = Object.keys(groups).map((k) => groups[k]);
      if (!list.length) {
        box.innerHTML = `<p class="lake-calm">&#10003; No beach or marine alerts for the La Porte County shore right now. Checked ${escapeHtml(stampOf(new Date()))}.</p>`;
        return;
      }
      box.innerHTML = list.map((g) => {
        const p = g.p, mean = MEANS.find((m) => m[0].test(p.event));
        const from = g.from > Date.now() ? `From ${fmtInZone(new Date(g.from), TZ, { weekday: "short", hour: "numeric", minute: "2-digit" })} ` : "";
        return `<div class="lake-alert${/warning/i.test(p.event) ? " warning" : ""}">
          <div class="kicker">Official &middot; ${escapeHtml(g.senders.length === 1 && p.senderName ? p.senderName : "National Weather Service")}</div>
          <h3>${escapeHtml(p.event)}</h3>
          <div class="when">${escapeHtml((from + alertUntilText(p, TZ)).trim())}${g.zones.length ? " &middot; " + escapeHtml(g.zones.join("; ")) : ""}</div>
          ${mean ? `<p class="means"><strong>What it means:</strong> ${escapeHtml(mean[1])}</p>` : ""}
        </div>`;
      }).join("");
    } catch (e) {
      box.innerHTML = `<p class="lake-calm">We couldn't check the lake alerts just now. See the <a href="/emergency" style="text-decoration:underline;">Emergency view</a> or ${productLink("NSH", "the marine forecast")}.</p>`;
    }
  }

  /* ----- Swim forecast (in season) ----- */
  function swimFacts(body) {
    const facts = {};
    body.split("\n").forEach((line) => {
      const m = /^\s*([A-Za-z][A-Za-z ]*?)\*{0,2}\.{3,}\s*(.+?)\s*$/.exec(line);
      if (m) facts[m[1].trim().toLowerCase()] = m[2].replace(/\.$/, "");
    });
    if (Object.keys(facts).length) return facts;
    // Later days are written as one paragraph: "Low swim risk*. Wave height around 2 feet. Sunny. ..."
    let text = body.replace(/\s+/g, " ").replace(/\*/g, "").trim();
    const risk = /\b(Low|Moderate|High) swim risk\.?\s*/i.exec(text);
    if (risk) { facts["swim risk"] = risk[1]; text = text.replace(risk[0], ""); }
    const wave = /\bWave height ([^.]+)\.\s*/i.exec(text);
    if (wave) { facts["wave height"] = titleCase(wave[1]); text = text.replace(wave[0], ""); }
    facts.text = text.trim();
    return facts;
  }
  async function swimForecast(waterTemp) {
    const card = $("swimCard");
    const head = '<div class="k">At the beach &middot; National Weather Service</div><h3>Swim forecast</h3>';
    let product = null, seg = null;
    try { product = await latestProduct("SRF"); seg = segmentFor(product.productText, "INZ103"); } catch (e) { /* handled below */ }
    const issued = product ? new Date(product.issuanceTime) : null;
    const fresh = issued && Date.now() - issued.getTime() < 48 * 3600 * 1000;
    const days = [];
    if (seg && fresh) {
      const issuedYmd = ymdInZone(issued, TZ), now = today();
      periodsOf("\n" + seg).forEach((per) => {
        const ymd = periodYmd(per.name, issuedYmd);
        if (!ymd || ymd < now || /NIGHT/.test(per.name) || days.length >= 3) return;
        days.push({ ymd: ymd, f: swimFacts(per.body) });
      });
    }
    const temp = waterTemp ? `<div class="water-temp">&#127777;&#65039; Water at Michigan City: ${waterTemp}&deg;F</div>` : "";
    if (!days.length) {
      const offSeason = !product || !fresh;
      card.innerHTML = head + `<div class="swim-off">${temp}` + (offSeason
        ? `<p><strong>The Weather Service&rsquo;s beach forecast is off for the season.</strong> It covers Washington Park, Long Beach and Mt. Baldy from just before Memorial Day weekend through early fall.</p><p>Until it&rsquo;s back, treat the lake as dangerous: check the wave forecast, stay off the piers when the waves are up, and remember the water is cold enough to take your breath away.</p>`
        : `<p>The latest beach forecast has no days left in it. Check back after the Weather Service&rsquo;s next update.</p>`) +
        `</div><p class="issued">${productLink("SRF", "Latest beach forecast on weather.gov")}</p>`;
      return;
    }
    const beaches = (/Including the beaches of ([\s\S]*?)\n\s*\d{3,4} [AP]M/.exec(seg) || [])[1];
    const attention = (/ATTENTION:\s*([\s\S]*?)(?:\n[ \t]*\n|$)/.exec(seg) || [])[1];
    const firstRisk = String(days[0].f["swim risk"] || "").toLowerCase();
    card.innerHTML = head +
      `<p class="where">${beaches ? "For the beaches at " + escapeHtml(beaches.replace(/\s+/g, " ").trim()) : "For the La Porte County shore"}</p>` + temp +
      days.map((d) => {
        const f = d.f, risk = String(f["swim risk"] || "").toLowerCase();
        const facts = [["Waves", f["wave height"]], ["Water", f["water temperature"]], ["Wind", f.winds], ["Weather", f.weather]].filter((x) => x[1]);
        return `<div class="swim-day"><div class="swim-top"><span class="swim-name">${escapeHtml(dayLabel(d.ymd, today(), "long"))}</span>` +
          (risk && RISK_MEANS[risk] ? `<span class="risk ${risk}">${escapeHtml(titleCase(risk))} swim risk</span>` : "") + `</div>` +
          (facts.length ? `<div class="swim-facts">${facts.map((x) => `<div><span>${x[0]}</span>${escapeHtml(x[1])}</div>`).join("")}</div>` : "") +
          (f.text ? `<p class="swim-text">${escapeHtml(f.text)}</p>` : "") + `</div>`;
      }).join("") +
      (RISK_MEANS[firstRisk] ? `<p class="swim-means"><strong>${escapeHtml(titleCase(firstRisk))} risk means:</strong> ${escapeHtml(RISK_MEANS[firstRisk])}</p>` : "") +
      (attention ? `<p class="swim-means"><strong>From the Weather Service:</strong> ${escapeHtml(attention.replace(/\s+/g, " ").trim())}</p>` : "") +
      `<p class="issued">Issued ${escapeHtml(stampOf(issued))}. ${productLink("SRF", "Full beach forecast")}</p>`;
  }

  /* ----- Nearshore marine forecast ----- */
  const mph = (kt) => Math.round(Number(kt) * 1.15078);
  const withMph = (s) => s
    .replace(/(\d+) to (\d+) knots/g, (m, a, b) => `${a} to ${b} knots (${mph(a)} to ${mph(b)} mph)`)
    .replace(/(\d+) knots(?! \()/g, (m, a) => `${a} knots (${mph(a)} mph)`);
  async function marineForecast() {
    const card = $("marineCard");
    const head = '<div class="k">On the water &middot; National Weather Service</div><h3>Waves and wind</h3>';
    try {
      const product = await latestProduct("NSH");
      const seg = segmentFor(product.productText, "LMZ046");
      if (!seg) throw new Error("no segment");
      const water = (/water temperature[\s\S]*?Michigan\s+City\s+is\s+(\d+)\s+degrees/i.exec(seg) || [])[1] || null;
      const periods = periodsOf("\n" + seg).slice(0, 4);
      if (!periods.length) throw new Error("no periods");
      card.innerHTML = head + `<p class="where">Lake Michigan within 5 nautical miles of shore, Michigan City to New Buffalo</p>` +
        periods.map((per) => {
          let text = per.body.replace(/\s+/g, " ").trim();
          const wave = /\b(Waves? [^.]*)\.\s*/i.exec(text);
          if (wave) text = text.replace(wave[0], "");
          return `<div class="marine-p"><strong>${escapeHtml(titleCase(per.name))}</strong>` +
            (wave ? `<span class="waves">${escapeHtml(wave[1])}</span>` : "") + escapeHtml(withMph(text)) + `</div>`;
        }).join("") +
        `<p class="issued">Issued ${escapeHtml(stampOf(new Date(product.issuanceTime)))}. ${productLink("NSH", "Full marine forecast")}</p>`;
      return water;
    } catch (e) {
      card.innerHTML = head + `<p>We couldn&rsquo;t load the marine forecast just now. ${productLink("NSH", "Read it on weather.gov")}</p>`;
      return null;
    }
  }

  let started = false;
  function start() {
    if (started) return;
    started = true;
    lakeAlerts();
    marineForecast().then((water) => swimForecast(water), () => swimForecast(null));
    $("lakeSource").innerHTML = "Source: National Weather Service Northern Indiana&rsquo;s beach (surf zone) and nearshore marine forecasts, and active NWS alerts for the La Porte County shore and nearby waters, checked " +
      escapeHtml(stampOf(new Date())) + ". Conditions on the lake change fast, so check again before you go.";
  }
  document.querySelectorAll("#lake a[data-track]").forEach((a) => a.addEventListener("click", () => { if (typeof lpwnTrack === "function") lpwnTrack(a.dataset.track); }));
  const sec = $("lake");
  if (sec && sec.getAttribute("data-start") === "now") {
    start();   // the beach page: the lake is the whole point, so load it right away
  } else if (sec && "IntersectionObserver" in window) {
    const io = new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) { io.disconnect(); start(); }
    }, { rootMargin: "600px 0px" });
    io.observe(sec);
  } else {
    start();
  }
})();
