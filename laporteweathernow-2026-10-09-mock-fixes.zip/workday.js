// Hard Hat Weather: the GO / DELAY / STOP engine.
//
// Reads the National Weather Service's hour-by-hour forecast grid for a job site,
// checks every work hour against a trade's limits, and makes one call for the day:
//   GO                     - workable all day (with any cautions noted)
//   GO, WRAP BY 2 PM       - start on time, finish before the weather turns
//   DELAY TILL 11 AM       - bad weather early, then a long enough workable stretch
//   STOP                   - not enough workable hours to be worth starting
// Every call comes with the reasons, the hours, and the exact text a crew would get.
//
// Needs timeutil.js (time zones, fetchJson, escapeHtml) and weather.js (nwsGet, alerts).

const WD_VERSION = "2026-10-09.1";

/* ---------- Business details shown on the Hard Hat Weather pages ---------- */
// Leave a field empty and the pages simply don't show it.
// textingLive: true since Oct. 2, 2026 (carriers approved the Telnyx number); set false to offer email only.
// The number still shows where the pages explain how joining by text will work.
const WD_CONTACT = { email: "laporteweathernow@gmail.com", phone: "(219) 258-7121", textingLive: true };

/** Shows the contact details on a page once they're filled in above. Elements marked
 * data-wd-contact="phone", "email", or "both" get "Text ... or email ...";
 * elements marked data-wd-contact-line only show when there's something to show. */
function wdFillContact(root) {
  const r = root || document;
  const phone = String(WD_CONTACT.phone || "").trim(), email = String(WD_CONTACT.email || "").trim();
  const link = (kind, v) => {
    const a = document.createElement("a");
    a.href = kind === "email" ? `mailto:${v}` : `sms:+1${v.replace(/\D/g, "").replace(/^1(?=\d{10}$)/, "")}`;
    a.textContent = v;
    return a;
  };
  r.querySelectorAll("[data-wd-contact]").forEach((el) => {
    const kind = el.getAttribute("data-wd-contact");
    const parts = [];
    // The business number is for texting (calls aren't forwarded), so the pages say "Text".
    if ((kind === "phone" || kind === "both") && phone && WD_CONTACT.textingLive) parts.push(["Text ", link("phone", phone)]);
    if ((kind === "email" || kind === "both") && email) parts.push([parts.length ? " or email " : "Email ", link("email", email)]);
    el.textContent = "";
    parts.forEach(([t, a]) => { el.appendChild(document.createTextNode(t)); el.appendChild(a); });
    if (parts.length) el.appendChild(document.createTextNode("."));
    el.hidden = !parts.length;
  });
  r.querySelectorAll("[data-wd-contact-line]").forEach((el) => { el.hidden = !(phone || email); });
  // The number written inline ("texts JOIN to our number (219) ...") shows only when there is one.
  r.querySelectorAll("[data-wd-phone-only]").forEach((el) => { el.textContent = phone; if (el.parentNode) el.parentNode.hidden = !phone; });
}

/* ---------- Trades and their starting limits ---------- */
// "stop" limits make an hour unworkable; "watch" limits add a heads-up. Customers can
// change every number (see wdMergeTrade); these are sensible starting points for each trade.
// Freezing rain stops every trade, and so does the ice it leaves while it's 32\u00B0F or colder.
const WD_TRADES = {
  roofing: {
    label: "Roofing",
    start: 7, end: 16, minBlock: 4, dryAfterRain: 1, iceDeck: 34,
    stop: { pop: 50, thunder: 40, gust: 25, snow: true },
    watch: { pop: 30, thunder: 20, gust: 20, below: 40, heatIndex: 95 },
    words: {
      below: "shingles won't self-seal; hand-seal per the maker",
      heatIndex: "plan water, shade, and breaks on the roof",
      wet: "deck may still be wet",
      icy: "ice or snow on the deck",
    },
  },
  concrete: {
    label: "Concrete & masonry",
    start: 6, end: 15, minBlock: 4, cureHours: 4, afterRain: 12, freezeNote: "protect fresh concrete",
    stop: { pop: 50, thunder: 40, snow: true },
    watch: { pop: 30, thunder: 20, gust: 25, below: 40, above: 90, heatIndex: 100 },
    words: {
      below: "cold-weather measures needed",
      above: "fast set, use hot-weather measures",
      gust: "fast drying, watch for cracking",
      cure: "fresh concrete needs 4 dry hours",
      afterRain: "cover fresh concrete",
    },
  },
  painting: {
    label: "Exterior painting",
    start: 8, end: 17, minBlock: 4, cureHours: 4, afterRain: 6,
    stop: { pop: 40, thunder: 40, below: 50, snow: true },
    watch: { pop: 25, thunder: 20, gust: 20, above: 90, dewSpread: 5, humidity: 85 },
    words: {
      below: "most exterior paints need 50\u00B0F (check the can)",
      above: "paint dries too fast",
      gust: "overspray and grit, brush and roll",
      dew: "surfaces may be damp",
      humidity: "slow drying",
      cure: "fresh paint needs 4 dry hours",
      afterRain: "fresh paint needs dry hours",
    },
  },
  landscaping: {
    label: "Landscaping & lawn",
    start: 7, end: 16, minBlock: 3, freezeNote: "cover new plantings", soak: { hours: 12, inches: 0.5 },
    stop: { pop: 60, thunder: 50, gust: 40, snow: true },
    watch: { pop: 40, thunder: 20, gust: 30, below: 32, heatIndex: 100 },
    words: { below: "frozen ground", heatIndex: "plan water and shade breaks", soaked: "soft turf and heavy leaves, watch for ruts" },
  },
  general: {
    label: "General construction",
    start: 7, end: 16, minBlock: 4,
    stop: { pop: 60, thunder: 50, gust: 28 },
    watch: { pop: 40, thunder: 20, gust: 20, heatIndex: 100, windChill: 10, snow: true },
    words: { gust: "most aerial lifts are rated to 28 mph", heatIndex: "plan water and shade breaks" },
  },
  events: {
    label: "Tents & outdoor events",
    start: 8, end: 18, minBlock: 4,
    stop: { thunder: 50, gust: 35, snow: true },
    watch: { pop: 40, thunder: 20, gust: 25, heatIndex: 100 },
    words: { thunder: "have a lightning shelter plan", gust: "check tent anchoring" },
  },
  inflatables: {
    label: "Inflatables & party rentals",
    start: 9, end: 18, minBlock: 4,
    stop: { pop: 60, thunder: 40, gust: 20, wind: 15, snow: true },
    watch: { pop: 40, thunder: 20, gust: 15, wind: 10, heatIndex: 100 },
    words: { gust: "most inflatable makers say deflate at 15 to 20 mph", wind: "most inflatable makers say deflate at 15 to 20 mph" },
  },
  // More trades (Oct. 5, 2026). Starting points: every number can be changed per job site.
  paving: {
    label: "Asphalt paving",
    start: 7, end: 17, minBlock: 4, dryAfterRain: 2,
    stop: { pop: 50, thunder: 40, below: 40, snow: true },
    watch: { pop: 30, thunder: 20, gust: 30, below: 50, heatIndex: 100 },
    words: {
      below: "most paving specs call for 40\u00B0F and rising, more for thin lifts (check yours)",
      wet: "the base may still be wet",
      heatIndex: "plan water and shade breaks",
    },
  },
  sealcoating: {
    label: "Sealcoating & line striping",
    start: 8, end: 17, minBlock: 4, cureHours: 6, afterRain: 8, dryAfterRain: 2,
    stop: { pop: 40, thunder: 30, below: 50, snow: true },
    watch: { pop: 25, thunder: 20, gust: 25, above: 95, dewSpread: 4, humidity: 85 },
    words: {
      below: "sealer and traffic paint need 50\u00B0F and rising (check the label)",
      cure: "fresh sealer needs 6 rain-free hours (check the label)",
      afterRain: "fresh sealer needs rain-free hours",
      wet: "pavement may still be wet",
      dew: "pavement may be damp",
      humidity: "slow drying",
      above: "fast drying (check the label)",
    },
  },
  siding: {
    label: "Siding & gutters",
    start: 7, end: 16, minBlock: 4,
    stop: { pop: 60, thunder: 40, gust: 30, snow: true },
    watch: { pop: 40, thunder: 20, gust: 20, below: 35, heatIndex: 100 },
    words: {
      gust: "siding panels and ladders catch the wind",
      below: "vinyl gets brittle in the cold, cut and nail with care",
      heatIndex: "plan water and shade breaks",
    },
  },
  decks: {
    label: "Decks & fences",
    start: 7, end: 16, minBlock: 4, freezeNote: "protect fresh concrete in post holes", soak: { hours: 12, inches: 0.75 },
    stop: { pop: 60, thunder: 40, gust: 35, snow: true },
    watch: { pop: 40, thunder: 20, gust: 25, below: 40, heatIndex: 100 },
    words: {
      below: "stain and post-hole concrete need warmer air (check the label)",
      heatIndex: "plan water and shade breaks",
      soaked: "soft, muddy ground at the post holes",
    },
  },
  excavation: {
    label: "Excavation & earthwork",
    start: 7, end: 17, minBlock: 4, dryAfterRain: 3, soak: { hours: 12, inches: 0.5 },
    stop: { pop: 70, thunder: 40, gust: 45 },
    watch: { pop: 40, thunder: 20, gust: 30, below: 32, heatIndex: 100, snow: true },
    words: {
      thunder: "off the machines and out of the trench at the first thunder",
      wet: "trench walls and soil may still be wet",
      below: "frozen ground",
      heatIndex: "plan water and shade breaks",
      soaked: "mud and soft trench walls",
    },
  },
  tree: {
    label: "Tree service",
    start: 7, end: 16, minBlock: 4, soak: { hours: 12, inches: 0.75 },
    stop: { pop: 70, thunder: 30, gust: 30, wind: 20, snow: true },
    watch: { pop: 40, thunder: 20, gust: 20, wind: 15, heatIndex: 100, windChill: 10 },
    words: {
      thunder: "nobody up in the trees with lightning around",
      gust: "no climbing or felling in high wind",
      heatIndex: "plan water and shade breaks",
      soaked: "soft ground, watch where trucks and lifts go",
    },
  },
  solar: {
    label: "Solar installation",
    start: 7, end: 16, minBlock: 4, dryAfterRain: 1, iceDeck: 34,
    stop: { pop: 50, thunder: 30, gust: 25, wind: 20, snow: true },
    watch: { pop: 30, thunder: 20, gust: 18, wind: 15, heatIndex: 95 },
    words: {
      gust: "panels catch the wind, don't carry or set them",
      thunder: "off the roof and away from the arrays at the first thunder",
      heatIndex: "hot roofs and panels, plan water, shade, and breaks",
      wet: "the roof may still be wet",
      icy: "ice or snow on the roof",
    },
  },
  washing: {
    label: "Pressure washing & window cleaning",
    start: 8, end: 17, minBlock: 3,
    stop: { pop: 70, thunder: 40, gust: 25, below: 34, snow: true },
    watch: { pop: 40, thunder: 20, gust: 18, below: 40, heatIndex: 100 },
    words: {
      below: "water can freeze on surfaces, ladders, and walks",
      gust: "ladders, lifts, and spray in the wind",
      heatIndex: "plan water and shade breaks",
    },
  },
  // Farm presets (Oct. 5, 2026), for Field Day Weather, the farm version. Weather only: the
  // product label is the law, so spray calls point to it. "calm" stops spraying in still air,
  // which can mean an inversion that carries drift.
  spraying: {
    label: "Farm: spraying", farm: true,
    start: 6, end: 20, minBlock: 3, cureHours: 2,
    stop: { pop: 40, thunder: 30, wind: 10, gust: 20, calm: 3, snow: true },
    watch: { pop: 25, thunder: 20, wind: 8, gust: 15, above: 85, below: 45 },
    words: {
      wind: "drift risk, check your label's wind limits",
      gust: "drift risk, check your label's wind limits",
      calm: "still air can mean an inversion (drift risk)",
      cure: "spray needs 2 rain-free hours (check your label)",
      above: "heat can raise volatility, check your label",
      below: "some products work poorly in the cold, check your label",
    },
  },
  // Hay needs dry days to cure, not just a dry day to cut (Oct. 9, 2026): a cutting is GO only
  // when the forecast stays under the hay rain limit from now through the end of cureDays
  // (3 to start; "cureDays 1" in Limits for baleage). Otherwise the call is STOP, with the
  // time to have down hay baled by.
  hay: {
    label: "Farm: hay", farm: true,
    start: 9, end: 19, minBlock: 8, dryAfterRain: 2, cureDays: 3,
    stop: { pop: 30, thunder: 30, snow: true },
    watch: { pop: 20, thunder: 20, gust: 25, humidity: 80, dewSpread: 3 },
    words: {
      wet: "hay may still be wet",
      dew: "heavy dew, hay dries late",
      humidity: "hay dries slowly",
      gust: "wind can scatter windrows",
    },
  },
  fieldwork: {
    label: "Farm: field work & harvest", farm: true,
    start: 7, end: 20, minBlock: 4, dryAfterRain: 3, soak: { hours: 24, inches: 0.5 },
    stop: { pop: 60, thunder: 40, gust: 40, snow: true },
    watch: { pop: 40, thunder: 20, gust: 30, dewSpread: 2, humidity: 90 },
    words: {
      wet: "fields and crops may still be wet",
      dew: "dew on the crop, soybeans may need to dry before combining",
      humidity: "crops dry slowly",
      soaked: "fields may be too wet for equipment",
    },
  },
  // Over-the-top dicamba on soybeans, from the 2026-27 labels (Oct. 5, 2026): winds 3-10 mph;
  // none when today's or tomorrow's forecast high is 95\u00B0F or more (an acreage limit at 85-95);
  // none within 48 hours of forecast rain; only from 1 hour after sunrise to 2 hours before
  // sunset; none after June 30 (or the R1 stage). The label is the law; this only reads the weather.
  dicamba: {
    label: "Farm: dicamba (soybeans)", farm: true,
    start: 6, end: 20, minBlock: 2,
    stop: { pop: 30, thunder: 20, wind: 11, gust: 20, calm: 3, snow: true },
    watch: { pop: 20, wind: 9, gust: 15 },
    dayHigh: { stop: 95, watch: 85, days: 2 },
    rainAhead: { hours: 48, pop: 30 },
    sunWindow: { afterRise: 1, beforeSet: 2 },
    lastDay: "06-30", lastDayText: "June 30", lastDayNoteFrom: "06-01",
    // States with their own, earlier cutoff for these products (by the NWS zone's state).
    // Indiana: "cannot be applied after June 12th" (Office of Indiana State Chemist, 2026-27
    // registrations; checked Oct. 9, 2026).
    stateLastDay: { IN: { day: "06-12", text: "June 12", who: "Indiana" } },
    words: {
      wind: "the label's limit is 10 mph",
      gust: "drift risk",
      calm: "the label requires 3 mph or more (inversion risk)",
    },
  },
  // Livestock (Oct. 5, 2026): no work call; heat stress from the temperature-humidity index
  // (THI 75 alert, 79 danger, 84 emergency: the Livestock Weather Safety Index) and cold stress
  // from the wind chill (10, -10, -25\u00B0F), plus cold rain with wind. See wdLivestock.
  livestock: {
    label: "Farm: livestock", farm: true, livestock: true,
    start: 0, end: 24, minBlock: 1,
    stop: {}, watch: {},
    heat: { alert: 75, danger: 79, emergency: 84, relief: 72 },
    cold: { alert: 10, danger: -10, emergency: -25, wetBelow: 40, wetWind: 10 },
  },
  // Dairy cows (Oct. 9, 2026): the same calls as livestock, with heat levels set lower, since
  // high-producing cows lose milk from about THI 68 (extension dairy guidance), and nights that
  // stay at THI 65 or more give them no relief.
  dairy: {
    label: "Farm: dairy cows", farm: true, livestock: true, dairy: true,
    start: 0, end: 24, minBlock: 1,
    stop: {}, watch: {},
    heat: { alert: 68, danger: 72, emergency: 80, relief: 65 },
    cold: { alert: 10, danger: -10, emergency: -25, wetBelow: 40, wetWind: 10 },
  },
  // Orchards, berries, and u-pick (Oct. 9, 2026): the morning call is for picking (rain, storms,
  // wind on ladders, heat for pickers); the evening frost call also gives the time the field's own
  // critical temperature is reached (frostCrit: 28 to start; "frost 26" in Limits by bud stage).
  orchard: {
    label: "Farm: orchard & u-pick", farm: true, frostCrit: 28,
    start: 8, end: 18, minBlock: 3,
    stop: { pop: 50, thunder: 30, gust: 35, snow: true },
    watch: { pop: 30, thunder: 20, gust: 25, heatIndex: 90 },
    words: {
      thunder: "clear the fields at the first thunder",
      gust: "ladders and bins in the wind",
      heatIndex: "pickers need water, shade, and breaks",
    },
  },
};

function wdTrade(key) {
  return WD_TRADES[key] || WD_TRADES.roofing;
}

/**
 * A trade with a customer's own limits laid over it, e.g.
 * wdMergeTrade("roofing", { stop: { gust: 30 }, watch: { below: 35 }, minBlock: 3 }).
 * Only numbers (and true/false for snow) are taken; anything else is ignored.
 */
function wdMergeTrade(key, limits) {
  const base = wdTrade(key);
  if (!limits || typeof limits !== "object") return base;
  const pick = (src) => {
    const out = {};
    Object.keys(src || {}).forEach((k) => {
      const v = src[k];
      if ((typeof v === "number" && isFinite(v)) || typeof v === "boolean" || v === null) out[k] = v;
    });
    return out;
  };
  const t = Object.assign({}, base, {
    stop: Object.assign({}, base.stop, pick(limits.stop)),
    watch: Object.assign({}, base.watch, pick(limits.watch)),
  });
  const ranges = { minBlock: [1, 12], cureHours: [0, 12], dryAfterRain: [0, 6], iceDeck: [20, 40], cureDays: [1, 5] };
  Object.keys(ranges).forEach((k) => {
    const v = limits[k], [lo, hi] = ranges[k];
    if (typeof v === "number" && isFinite(v) && v >= lo && v <= hi) t[k] = v;
    else if (k === "iceDeck" && v === null) t[k] = null;   // turn the icy-deck rule off
  });
  return t;
}

/**
 * A trade with its state's own season cutoff, when the state has one (Oct. 9, 2026): the
 * site's state comes from its NWS forecast zone ("IN" for INZ103). Unknown state: the label's
 * date, and the notes name the states with earlier ones.
 */
function wdStateTrade(t, state) {
  const s = t && t.stateLastDay && state ? t.stateLastDay[String(state).toUpperCase()] : null;
  if (!s) return t;
  return Object.assign({}, t, { lastDay: s.day, lastDayText: s.text, lastDayWho: s.who, labelLastDayText: t.lastDayText });
}

/** Whole days from one "YYYY-MM-DD" to another. */
function wdDaysBetween(a, b) {
  return Math.round((ymdToUTCDate(b).getTime() - ymdToUTCDate(a).getTime()) / 86400000);
}

/** "1.3 in." / "0.6 in." for a rain amount. */
function wdInches(v) {
  return `${Math.round(v * 10) / 10} in.`;
}

/** The limits, in words, for the "Built for your trade" cards. */
function wdTradeLimitsText(key) {
  const t = wdTrade(key);
  const s = t.stop, w = t.watch;
  const stop = [], watch = [];
  if (s.pop != null) stop.push(`${s.pop}%+ chance of rain`);
  if (s.thunder != null) stop.push(`${s.thunder}%+ chance of storms`);
  if (s.gust != null) stop.push(`gusts ${s.gust} mph+`);
  if (s.wind != null) stop.push(`winds ${s.wind} mph+`);
  if (s.calm != null) stop.push(`winds under ${s.calm} mph (inversion risk)`);
  if (s.below != null) stop.push(`below ${s.below}\u00B0F`);
  stop.push(s.snow ? "snow, sleet, or freezing rain" : "freezing rain");
  if (t.iceDeck) stop.push(`ice or snow on the deck at ${t.iceDeck}\u00B0F or colder`);
  if (t.cureHours) stop.push(t.farm ? `rain within ${t.cureHours} hours of spraying` : `rain within ${t.cureHours} hours of fresh work`);
  if (t.dayHigh) stop.push(`a forecast high of ${t.dayHigh.stop}\u00B0F+ today or tomorrow`);
  if (t.rainAhead) stop.push(`rain in the forecast within ${t.rainAhead.hours} hours`);
  if (t.sunWindow) stop.push(`within ${t.sunWindow.afterRise} hour after sunrise or ${t.sunWindow.beforeSet} hours before sunset`);
  if (t.cureDays > 1) stop.push(`fewer than ${t.cureDays} dry days to cure`);
  if (t.lastDay) {
    const st = Object.keys(t.stateLastDay || {}).map((k) => `${t.stateLastDay[k].text} in ${t.stateLastDay[k].who}`);
    stop.push(`after ${t.lastDayText || t.lastDay}${st.length ? ` (${st.join(", ")})` : ""}`);
  }
  if (w.pop != null) watch.push(`${w.pop}%+ rain chance`);
  if (w.gust != null) watch.push(`gusts ${w.gust} mph+`);
  if (w.wind != null) watch.push(`winds ${w.wind} mph+`);
  if (w.calm != null) watch.push(`winds under ${w.calm} mph`);
  if (w.below != null) watch.push(`below ${w.below}\u00B0F`);
  if (w.above != null) watch.push(`above ${w.above}\u00B0F`);
  if (w.heatIndex != null) watch.push(`heat index ${w.heatIndex}\u00B0F+`);
  if (w.windChill != null) watch.push(`wind chill ${w.windChill}\u00B0F or colder`);
  if (w.dewSpread != null) watch.push("dew on surfaces");
  if (w.humidity != null) watch.push(`humidity ${w.humidity}%+`);
  if (w.snow && !s.snow) watch.push("snow or sleet");
  if (t.freezeNote) watch.push("a freeze that night");
  if (t.afterRain) watch.push(`rain in the ${t.afterRain} hours after work`);
  if (t.soak) watch.push(`${t.soak.inches} in. or more of rain in the ${t.soak.hours} hours before work`);
  if (t.dayHigh) watch.push(`a forecast high of ${t.dayHigh.watch}-${t.dayHigh.stop - 1}\u00B0F (the label's acreage limit)`);
  return { stop, watch };
}

/* ---------- Reading the NWS forecast grid ---------- */

const WD_HOUR = 3600000;

/** "PT3H" -> 3, "P1DT6H" -> 30, "PT30M" -> 1 (rounded up to whole hours). */
function wdDurationHours(iso) {
  const m = /^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?)?$/.exec(String(iso || ""));
  if (!m) return 1;
  const h = (Number(m[1] || 0) * 24) + Number(m[2] || 0) + Number(m[3] || 0) / 60;
  return Math.max(1, Math.ceil(h));
}

function wdConvert(value, uom) {
  if (value === null || value === undefined || typeof value !== "number" || isNaN(value)) return null;
  const u = String(uom || "");
  if (/degC$/.test(u)) return value * 9 / 5 + 32;
  if (/km_h-1$/.test(u)) return value * 0.621371;
  if (/m_s-1$/.test(u)) return value * 2.23694;
  if (/:kt$/.test(u)) return value * 1.15078;
  if (/:mm$/.test(u)) return value / 25.4;
  if (/:m$/.test(u)) return value * 39.3701;
  return value;
}

// NWS coverage words -> the range of chances they stand for (NWS: slight chance 10-24%,
// chance 25-54%, likely 55-74%). When the forecast gives no storm percentage, the storm
// chance is the rain chance held inside that range.
const WD_COVERAGE_RANGE = {
  slight_chance: [10, 24], isolated: [10, 24], chance: [25, 54], scattered: [25, 54], patchy: [25, 54], areas: [25, 54],
  likely: [55, 74], numerous: [55, 74], intermittent: [55, 100], occasional: [55, 100], periods: [75, 100],
  frequent: [75, 100], widespread: [75, 100], definitely: [75, 100],
};
const WD_COVERAGE = Object.fromEntries(Object.entries(WD_COVERAGE_RANGE).map(([k, v]) => [k, v[0]]));
const WD_ICE_TYPES = /^(freezing_rain|freezing_drizzle)$/;
const WD_SNOW_TYPES = /^(snow|snow_showers|flurries|sleet|blowing_snow|ice_pellets)$/;
const WD_LIQUID_TYPES = /^(rain|rain_showers|drizzle|thunderstorms)$/;
const WD_TRACE = 0.004; // inches: less than this in an hour doesn't count as falling

/** Hour-by-hour forecast from a gridpoints response: Map of UTC-hour -> hour record. */
function wdParseGrid(gridJson) {
  const p = (gridJson && gridJson.properties) || {};
  const hours = new Map();
  const at = (ms) => {
    let h = hours.get(ms);
    if (!h) { h = { t: new Date(ms) }; hours.set(ms, h); }
    return h;
  };
  const periods = (L, fn) => {
    if (!L || !Array.isArray(L.values)) return;
    L.values.forEach((v) => {
      const [startIso, dur] = String(v.validTime || "").split("/");
      const start = Date.parse(startIso);
      if (isNaN(start)) return;
      const n = wdDurationHours(dur);
      const first = Math.floor(start / WD_HOUR) * WD_HOUR;
      fn(v, n, first);
    });
  };
  const layer = (name, field, opts) => {
    const L = p[name];
    periods(L, (v, n, first) => {
      let val = wdConvert(v.value, L.uom);
      if (val !== null && opts && opts.spread) val = val / n; // amounts spread across the period
      else if (val !== null) val = Math.round(val);            // whole degrees, mph, and percents, as shown
      for (let i = 0; i < n; i++) at(first + i * WD_HOUR)[field] = val;
    });
  };
  layer("temperature", "tempF");
  layer("dewpoint", "dewF");
  layer("relativeHumidity", "rh");
  layer("heatIndex", "heatF");
  layer("windChill", "chillF");
  layer("windSpeed", "windMph");
  layer("windGust", "gustMph");
  layer("probabilityOfPrecipitation", "pop");
  layer("probabilityOfThunder", "thunderPct");
  layer("quantitativePrecipitation", "qpfIn", { spread: true });
  layer("snowfallAmount", "snowIn", { spread: true });
  layer("iceAccumulation", "iceIn", { spread: true });
  layer("skyCover", "sky");
  periods(p.weather, (v, n, first) => {
    const list = (Array.isArray(v.value) ? v.value : []).filter((c) => c && c.weather).map((c) => ({
      type: String(c.weather), chance: WD_COVERAGE[c.coverage] || 25, range: WD_COVERAGE_RANGE[c.coverage] || [25, 54], intensity: c.intensity || "",
    }));
    for (let i = 0; i < n; i++) at(first + i * WD_HOUR).wx = list;
  });

  hours.forEach((h) => {
    const list = h.wx || [];
    const pop = h.pop == null ? 0 : h.pop;
    const has = (re) => list.filter((c) => re.test(c.type));
    // Storms: the forecast's own storm percentage when it has one; otherwise, when storms
    // are in the forecast, the rain chance (storms are the rain), never below the coverage word.
    const storms = has(/^thunderstorms$/);
    const stormCov = storms.reduce((m, c) => Math.max(m, c.chance), 0);
    const stormFromPop = storms.reduce((m, c) => Math.max(m, Math.min(Math.max(pop, c.range[0]), c.range[1])), 0);
    h.thunder = h.thunderPct != null ? Math.max(h.thunderPct, stormCov) : stormFromPop;
    // Freezing rain, snow or sleet, and plain rain are judged separately; a mix can be all three.
    h.ice = has(WD_ICE_TYPES).length > 0 || (h.iceIn || 0) > WD_TRACE;
    h.snowy = has(WD_SNOW_TYPES).some((c) => c.chance >= 25) || (h.snowIn || 0) > WD_TRACE;
    h.liquid = has(WD_LIQUID_TYPES).length > 0 || (!h.ice && !has(WD_SNOW_TYPES).length);
    h.precipWord = wdPrecipWord(list, h);
  });
  return { hours, updated: p.updateTime || null, office: p.gridId || null };
}

function wdPrecipWord(list, h) {
  const types = list.map((c) => c.type);
  const snowWord = types.includes("sleet") || types.includes("ice_pellets") ? "sleet" : "snow";
  if (h.liquid && h.snowy && !types.includes("thunderstorms")) return `rain and ${snowWord}`;
  if (types.includes("rain")) return "rain";
  if (types.includes("rain_showers")) return "showers";
  if (types.includes("drizzle")) return "drizzle";
  if (h.snowy) return snowWord;
  return "rain";
}

/* ---------- Checking one hour against a trade's limits ---------- */

const WD_LEVEL = { ok: 0, watch: 1, stop: 2 };

/** Every limit an hour crosses, e.g. [{type:"rain", level:"stop", value:70, limit:50}]. */
function wdCheckHour(h, trade) {
  const s = trade.stop || {}, w = trade.watch || {};
  const hits = [];
  const add = (type, level, value, limit) => hits.push({ type, level, value, limit });
  const pop = h.pop == null ? 0 : h.pop;
  const falls = (amount) => (amount || 0) > WD_TRACE;
  const floor = w.pop != null ? w.pop : 30;   // below this chance, precipitation isn't worth a mention

  // Freezing rain: dangerous footing for every trade.
  if (h.ice && (pop >= floor || falls(h.iceIn))) add("ice", "stop", pop, null);
  // Rain (including the rain in a rain-and-snow mix).
  if (h.liquid) {
    if (s.pop != null && pop >= s.pop) add("rain", "stop", pop, s.pop);
    else if (w.pop != null && pop >= w.pop) add("rain", "watch", pop, w.pop);
  }
  // Snow and sleet.
  if (h.snowy && (pop >= floor || falls(h.snowIn))) {
    if (s.snow) add("winter", "stop", pop, null);
    else if (w.snow) add("winter", "watch", pop, null);
  }
  if (s.thunder != null && h.thunder >= s.thunder) add("thunder", "stop", h.thunder, s.thunder);
  else if (w.thunder != null && h.thunder >= w.thunder) add("thunder", "watch", h.thunder, w.thunder);

  const gust = Math.max(h.gustMph == null ? 0 : h.gustMph, h.windMph == null ? 0 : h.windMph);
  if (s.gust != null && gust >= s.gust) add("gust", "stop", gust, s.gust);
  else if (w.gust != null && gust >= w.gust) add("gust", "watch", gust, w.gust);
  if (h.windMph != null) {
    if (s.wind != null && h.windMph >= s.wind) add("wind", "stop", h.windMph, s.wind);
    else if (w.wind != null && h.windMph >= w.wind) add("wind", "watch", h.windMph, w.wind);
    // Too calm (farm spraying): still air near the ground can mean an inversion that carries drift.
    if (s.calm != null && h.windMph < s.calm) add("calm", "stop", h.windMph, s.calm);
    else if (w.calm != null && h.windMph < w.calm) add("calm", "watch", h.windMph, w.calm);
  }
  if (h.tempF != null) {
    if (s.below != null && h.tempF < s.below) add("cold", "stop", h.tempF, s.below);
    else if (w.below != null && h.tempF < w.below) add("cold", "watch", h.tempF, w.below);
    if (s.above != null && h.tempF > s.above) add("hot", "stop", h.tempF, s.above);
    else if (w.above != null && h.tempF > w.above) add("hot", "watch", h.tempF, w.above);
    const hi = h.heatF != null ? h.heatF : h.tempF;
    if (w.heatIndex != null && hi >= w.heatIndex) add("heat", "watch", hi, w.heatIndex);
    const wc = h.chillF != null ? h.chillF : h.tempF;
    if (w.windChill != null && wc <= w.windChill) add("chill", "watch", wc, w.windChill);
    if (w.dewSpread != null && h.dewF != null && h.tempF - h.dewF <= w.dewSpread) add("dew", "watch", h.tempF - h.dewF, w.dewSpread);
  }
  if (w.humidity != null && h.rh != null && h.rh >= w.humidity) add("humid", "watch", h.rh, w.humidity);
  return hits;
}

function wdTopLevel(hits) {
  return hits.reduce((m, x) => (WD_LEVEL[x.level] > WD_LEVEL[m] ? x.level : m), "ok");
}

/* ---------- NWS alerts that matter on a job site ---------- */

// Warnings that stop work while they're in effect.
const WD_ALERT_STOP = new Set([
  "Tornado Warning", "Severe Thunderstorm Warning", "Flash Flood Warning", "Blizzard Warning", "Ice Storm Warning",
  "Winter Storm Warning", "Lake Effect Snow Warning", "Snow Squall Warning", "High Wind Warning", "Extreme Wind Warning",
  "Hurricane Warning", "Tropical Storm Warning", "Typhoon Warning", "Storm Surge Warning", "Dust Storm Warning",
  "Excessive Heat Warning", "Extreme Heat Warning", "Extreme Cold Warning", "Wind Chill Warning", "Tsunami Warning",
  "Earthquake Warning", "Volcano Warning", "Avalanche Warning", "Fire Warning", "Shelter In Place Warning",
  "Evacuation Immediate", "Civil Danger Warning", "Civil Emergency Message", "Hazardous Materials Warning",
  "Nuclear Power Plant Warning", "Radiological Hazard Warning", "Law Enforcement Warning", "Local Area Emergency",
]);
// Products for boats, beaches, and other things that never affect a job site.
const WD_ALERT_IGNORE = new Set([
  "Special Marine Warning", "Marine Weather Statement", "Small Craft Advisory", "Gale Warning", "Gale Watch",
  "Storm Warning", "Storm Watch", "Hurricane Force Wind Warning", "Hurricane Force Wind Watch", "Heavy Freezing Spray Warning",
  "Heavy Freezing Spray Watch", "Freezing Spray Advisory", "Brisk Wind Advisory", "Hazardous Seas Warning", "Hazardous Seas Watch",
  "Low Water Advisory", "Beach Hazards Statement", "Rip Current Statement", "High Surf Advisory", "High Surf Warning",
  "Hydrologic Outlook", "Child Abduction Emergency", "Blue Alert", "Administrative Message", "Test Message",
]);

/** How an NWS alert affects work hours for a trade: "stop", "watch", or null (doesn't apply). */
function wdAlertLevel(event, tradeKey) {
  const e = String(event || "").trim();
  if (!e || WD_ALERT_IGNORE.has(e)) return null;
  if (WD_ALERT_STOP.has(e)) return "stop";
  if (e === "Wind Advisory") return /^(roofing|events|inflatables|general|siding|tree|solar)$/.test(tradeKey) ? "stop" : "watch";
  if (/^(Winter Weather|Freezing Rain|Freezing Drizzle|Freezing Fog) Advisory$/.test(e)) return /^(roofing|solar)$/.test(tradeKey) ? "stop" : "watch";
  if (/^(Frost Advisory|Freeze Warning|Freeze Watch|Hard Freeze Warning|Hard Freeze Watch)$/.test(e)) return /^(concrete|landscaping|painting|paving|sealcoating|decks|washing)$/.test(tradeKey) ? "watch" : null;
  // Other warnings for wide areas or shorelines (river floods, lakeshore floods, fire weather) get a heads-up.
  if (/^(Flood Warning|Coastal Flood Warning|Lakeshore Flood Warning|Red Flag Warning)$/.test(e)) return "watch";
  if (/Warning$/.test(e)) return "stop";   // any other warning: better safe
  if (/(Watch|Advisory|Statement|Alert|Message|Emergency)$/.test(e)) return "watch";
  return null;
}

/** Alerts with their time spans and job-site level, for one trade. */
function wdAlertSpans(alerts, tradeKey) {
  return (alerts || []).map((f) => {
    const p = (f && f.properties) || f || {};
    const level = wdAlertLevel(p.event, tradeKey);
    if (!level) return null;
    const from = Date.parse(p.onset || p.effective || p.sent || "") || 0;
    const to = typeof alertEndMs === "function" ? alertEndMs(p) : (Date.parse(p.ends || p.expires || "") || Infinity);
    return { event: String(p.event), level, from, to, props: p };
  }).filter(Boolean);
}

/* ---------- Times, in the job site's own time zone ---------- */

function wdLocalHour(d, tz) {
  const off = tzOffsetMinutes(d, tz);
  return new Date(d.getTime() + off * 60000).getUTCHours();
}

function wdHourWord(h, withSuffix) {
  const x = ((h % 24) + 24) % 24;
  if (x === 12) return "noon";
  if (x === 0) return "midnight";
  const n = x % 12 || 12;
  return withSuffix ? `${n} ${x < 12 ? "AM" : "PM"}` : String(n);
}

/** "7-11 AM", "11 AM-2 PM", "7 AM-noon". `to` is the end of the last hour. */
function wdRangeText(from, to, tz, dash) {
  const d = dash || "\u2013";
  const a = wdLocalHour(from, tz), b = wdLocalHour(to, tz);
  const special = (h) => h === 12 || h === 0;
  if (!special(a) && !special(b) && (a < 12) === (b < 12) && b > a) return `${wdHourWord(a, false)}${d}${wdHourWord(b, true)}`;
  return `${wdHourWord(a, true)}${d}${wdHourWord(b, true)}`;
}

function wdTimeText(d, tz) {
  return wdHourWord(wdLocalHour(d, tz), true);
}

/* ---------- Making the call for one day ---------- */

const WD_WET_TYPES = ["rain", "thunder", "winter", "ice"];

/**
 * The call for one job site on one day.
 * grid:  wdParseGrid() result.  tradeKey: key of WD_TRADES.  ymd: "YYYY-MM-DD" at the site.
 * opts:  { tz, start, end (hours, 24h clock), now (Date), alerts (NWS features), limits (see wdMergeTrade) }
 */
function wdDecideDay(grid, tradeKey, ymd, opts) {
  const o = opts || {};
  const trade = wdStateTrade(wdMergeTrade(tradeKey, o.limits), o.state);
  const tz = o.tz;
  let startH = o.start != null ? o.start : trade.start;
  let endH = o.end != null ? o.end : trade.end;
  const now = o.now || new Date();
  // The day the text is read (Oct. 9, 2026): the call's own day, or the day before for the
  // day-before text, so "today", "tonight", and "last night" mean what the reader thinks.
  const refYmd = o.refYmd || ymd;
  // A label's time-of-day window (dicamba: 1 hour after sunrise to 2 hours before sunset). Only
  // whole hours inside it are work hours (Oct. 5, 2026). Needs the spot's latitude and longitude.
  let sunNote = null;
  if (trade.sunWindow) {
    const sw = o.lat != null && o.lon != null ? wdSunWindow(o.lat, o.lon, ymd, tz, trade.sunWindow) : null;
    if (sw && sw.toH > sw.fromH) {
      const a = Math.max(startH, sw.fromH), b = Math.min(endH, sw.toH);
      if (b > a) { startH = a; endH = b; } else { startH = sw.fromH; endH = sw.toH; }
      sunNote = { type: "sun", level: "watch", text: `Label window: ${sw.text}`, window: sw };
    } else {
      sunNote = { type: "sun", level: "watch", text: "Check the label's sunrise and sunset limits" };
    }
  }
  const alertSpans = wdAlertSpans(o.alerts, tradeKey);

  // The work hours still ahead (today's call skips hours already gone).
  const slots = [];
  for (let hr = startH; hr < endH; hr++) {
    const t = zonedDateTime(ymd, hr, tz);
    if (t.getTime() + WD_HOUR <= now.getTime()) continue;
    slots.push(t);
  }
  const result = {
    ymd, refYmd, tradeKey, trade: trade.label, tradeObj: trade, tz, start: startH, end: endH,
    hours: [], call: "unknown", label: "NO CALL YET", startAt: null, until: null,
    reasons: [], notes: [], stats: null, over: false, restOfDay: slots.length < endH - startH,
  };
  if (!slots.length) { result.over = true; result.label = "WORKDAY OVER"; return result; }

  const rec = (t) => grid.hours.get(Math.floor(t.getTime() / WD_HOUR) * WD_HOUR);
  const usable = (h) => h && h.tempF != null && h.pop != null;
  const hours = slots.map((t) => {
    const h = rec(t);
    if (!usable(h)) return { t, level: "nodata", hits: [], h: h || null };
    const hits = wdCheckHour(h, trade);
    alertSpans.forEach((a) => {
      if (a.from < t.getTime() + WD_HOUR && a.to > t.getTime()) hits.push({ type: "alert", level: a.level, event: a.event, alert: a });
    });
    return { t, level: wdTopLevel(hits), hits, h };
  });
  result.hours = hours;
  // Any work hour the forecast doesn't cover: no call, rather than a guess.
  if (hours.some((x) => x.level === "nodata")) {
    result.window = { from: hours[0].t, to: new Date(hours[hours.length - 1].t.getTime() + WD_HOUR) };
    result.missing = true;
    return result;
  }

  // Label rules that look past the hour itself: the season, the day's high, rain ahead (Oct. 5, 2026).
  if (trade.lastDay || trade.dayHigh || trade.rainAhead) wdLabelRules(grid, trade, ymd, tz, hours, refYmd);
  const wetStop = (h) => usable(h) && wdCheckHour(h, trade).some((x) => WD_WET_TYPES.includes(x.type) && x.level === "stop");
  // Ice left behind: after freezing rain, every trade stops while it stays at or below 32\u00B0F;
  // a roof deck stays icy or snowy after ice or snow while it's at or below iceDeck. Only
  // weather that actually builds up counts (a forecast amount, or a likely chance when the
  // forecast gives no amounts), and a thaw since then clears it.
  const builds = (x, amount) => (amount != null ? amount > WD_TRACE : (x.pop || 0) >= 60);
  const icyAt = (t) => {
    const h = rec(t);
    if (!usable(h)) return false;
    const top = Math.max(32, trade.iceDeck || 0);
    let warmest = -Infinity;                         // warmest hour between then and now
    for (let k = 1; k <= 18; k++) {
      const prev = rec(new Date(t.getTime() - k * WD_HOUR));
      if (!usable(prev) || warmest > top) return false;
      let limit = -Infinity;
      if (prev.ice && builds(prev, prev.iceIn)) limit = Math.max(32, trade.iceDeck || -Infinity);
      if (prev.snowy && trade.iceDeck && builds(prev, prev.snowIn)) limit = Math.max(limit, trade.iceDeck);
      if (limit > -Infinity && h.tempF <= limit && warmest <= limit) return true;
      warmest = Math.max(warmest, prev.tempF);
    }
    return false;
  };
  hours.forEach((slot) => {
    if (slot.hits.some((x) => x.type === "ice" || x.type === "winter")) return;
    if (icyAt(slot.t)) {
      slot.hits.push({ type: "icy", level: "stop", value: slot.h.tempF });
      slot.level = "stop";
    }
  });
  // Fresh work needs dry hours after it: rain, storms, or snow in the next few hours make
  // this hour a stop for pours and paint. Looks past the end of the day too.
  if (trade.cureHours) {
    hours.forEach((slot) => {
      if (slot.level === "stop") return;
      for (let k = 1; k <= trade.cureHours; k++) {
        const t = new Date(slot.t.getTime() + k * WD_HOUR);
        const h = rec(t);
        if (wetStop(h)) {
          slot.hits.push({ type: "cure", level: "stop", value: h.pop || 0, rainAt: t });
          slot.level = "stop";
          break;
        }
      }
    });
  }
  // A roof stays wet for a while after rain.
  if (trade.dryAfterRain) {
    hours.forEach((slot) => {
      if (slot.level === "stop") return;
      for (let k = 1; k <= trade.dryAfterRain; k++) {
        const prev = rec(new Date(slot.t.getTime() - k * WD_HOUR));
        if (usable(prev) && wdCheckHour(prev, trade).some((x) => (x.type === "rain" || x.type === "thunder") && x.level === "stop")) {
          slot.hits.push({ type: "wet", level: "watch" });
          slot.level = wdTopLevel(slot.hits);
          break;
        }
      }
    });
  }

  // Hay needs dry days to cure (Oct. 9, 2026): hay cut at a given hour needs the forecast under
  // the hay rain limit from then through the end of the last cure day, so a morning shower only
  // delays the cutting, and rain later in the window stops it. Hours past the end of the forecast
  // aren't dry, they're unknown: no call until the forecast covers the whole window. The call
  // says when to have down hay baled by.
  let cureGap = false;
  if (trade.cureDays > 1) {
    const from = Math.floor(hours[0].t.getTime() / WD_HOUR) * WD_HOUR;
    const to = zonedDateTime(addDaysYmd(ymd, trade.cureDays - 1), endH, tz).getTime();
    const wet = [];
    let gap = false;
    for (let t = from; t < to; t += WD_HOUR) {
      const h = rec(new Date(t));
      if (!usable(h)) { gap = true; break; }
      if (wetStop(h)) wet.push({ t, pop: h.pop || 0 });
    }
    hours.forEach((slot) => {
      if (slot.level === "stop") return;
      const first = wet.find((w) => w.t >= slot.t.getTime());
      if (!first) { if (gap) slot.cureGap = true; return; }
      const peak = Math.max(...wet.filter((w) => w.t >= first.t && w.t - first.t <= 6 * WD_HOUR).map((w) => w.pop));
      slot.hits.push({ type: "nocure", level: "stop", value: peak, rainAt: new Date(first.t) });
      slot.level = "stop";
    });
    if (wet.length) result.baleBy = new Date(wet[0].t - WD_HOUR);
    cureGap = hours.some((x) => x.cureGap);
  }

  // The longest stretch of workable (not "stop") hours decides the call.
  const n = hours.length;
  const runs = [];
  let i = 0;
  while (i < n) {
    if (hours[i].level === "stop") { i++; continue; }
    let j = i;
    while (j < n && hours[j].level !== "stop") j++;
    runs.push({ s: i, e: j, len: j - i });
    i = j;
  }
  const best = runs.reduce((b, r) => (!b || r.len > b.len ? r : b), null);
  // The morning call needs a stretch worth starting; later in the day, any workable hours left count.
  const need = result.restOfDay ? 1 : Math.min(trade.minBlock || 4, endH - startH);
  const anyStop = hours.some((x) => x.level === "stop");
  const endAt = new Date(hours[n - 1].t.getTime() + WD_HOUR);
  result.need = need;

  if (!anyStop) {
    result.call = "go";                       // nothing stops work in the hours left
  } else if (!best || best.len < need) {
    result.call = "stop";
  } else {
    const late = best.s > 0, early = best.e < n;
    result.call = late ? "delay" : "go";
    if (late) result.startAt = hours[best.s].t;
    if (early) result.until = hours[best.e].t;
    // Workable hours before the start that are too few for the job: "Before that, only 7-10 AM
    // is workable, and the job needs 4 hours" (Oct. 9, 2026), so the delay makes sense.
    const before = runs.filter((x) => x.e <= best.s).sort((a, b) => b.len - a.len)[0];
    if (late && before && before.len < need) result.shortBefore = { from: hours[before.s].t, to: hours[before.e].t, len: before.len };
    // Hay with hours that would be cut before the forecast covers its cure days: no call yet.
    if (cureGap && hours.slice(best.s, best.e).some((x) => x.cureGap)) {
      result.call = "unknown";
      result.cureGap = true;
      result.startAt = result.until = null;
      delete result.shortBefore;
    }
  }
  if (cureGap && !anyStop) { result.call = "unknown"; result.cureGap = true; }
  result.label = wdCallLabel(result, tz);
  // A hay STOP only for rain before the hay could cure (nothing else stops a work hour that day)
  // isn't a weather delay that day: the sender keeps it out of delay records and the score.
  if (result.call === "stop") {
    const kinds = new Set();
    hours.forEach((x) => x.hits.forEach((y) => { if (y.level === "stop") kinds.add(y.type); }));
    result.cureOnly = kinds.size === 1 && kinds.has("nocure");
  }
  result.window = { from: hours[0].t, to: endAt };
  result.best = best && result.call !== "stop" ? { from: hours[best.s].t, to: best.e < n ? hours[best.e].t : endAt } : null;
  // The longest workable stretch, even on a STOP: "Only 10 AM-noon is workable" (Oct. 9, 2026).
  result.longest = best ? { from: hours[best.s].t, to: best.e < n ? hours[best.e].t : endAt, len: best.len, runs: runs.length } : null;

  // Weather during the hours the crew would actually work (or the whole day on a stop).
  const workHours = result.best ? hours.slice(best.s, best.e) : hours;
  result.stats = wdStats(workHours.map((x) => x.h));
  result.dayStats = wdStats(hours.map((x) => x.h));
  result.reasons = wdReasons(hours, trade, tz, endAt, result.restOfDay);
  const cureHit = hours.some((x) => x.hits.some((y) => y.type === "cure"));
  // Past a label's season, no notes: the season says it all (Oct. 9, 2026).
  const seasonOver = hours.some((x) => x.hits.some((y) => y.type === "season"));
  result.notes = seasonOver ? [] : wdSoakNotes(grid, trade, hours[0].t, tz, Object.assign({}, o, { refYmd }))
    .concat(wdLabelNotes(trade, ymd, sunNote, refYmd), wdNightNotes(grid, trade, endAt, { cureHit, tz, stop: result.call === "stop", ymd, refYmd }));
  if (!seasonOver && result.baleBy && result.baleBy.getTime() > hours[0].t.getTime()) {
    result.notes.push({ type: "bale", level: "watch", at: result.baleBy, ref: hours[0].t, text: `Bale any hay that's down by ${wdDayTimeText(result.baleBy, tz, hours[0].t)}` });
  }
  result.alerts = alertSpans.filter((a) => a.from < endAt.getTime() && a.to > hours[0].t.getTime());
  result.sky = wdSkyWord(hours.map((x) => x.h));
  return result;
}

function wdCallLabel(r, tz) {
  if (r.call === "stop") return "STOP";
  if (r.call === "unknown") return "NO CALL YET";
  const wrap = r.until ? `WRAP BY ${wdTimeText(r.until, tz).toUpperCase()}` : "";
  if (r.call === "delay") return `DELAY TILL ${wdTimeText(r.startAt, tz).toUpperCase()}${wrap ? ", " + wrap : ""}`;
  return wrap ? `GO, ${wrap}` : "GO";
}

function wdStats(list) {
  const hs = list.filter(Boolean);
  if (!hs.length) return null;
  const nums = (f) => hs.map((h) => h[f]).filter((v) => v != null);
  const temps = nums("tempF"), gusts = hs.map((h) => Math.max(h.gustMph || 0, h.windMph || 0)), pops = nums("pop");
  return {
    lo: temps.length ? Math.round(Math.min(...temps)) : null,
    hi: temps.length ? Math.round(Math.max(...temps)) : null,
    gust: gusts.length ? Math.round(Math.max(...gusts)) : null,
    pop: pops.length ? Math.round(Math.max(...pops)) : null,
  };
}

function wdSkyWord(list) {
  const sky = list.filter(Boolean).map((h) => h.sky).filter((v) => v != null);
  if (!sky.length) return "";
  const avg = sky.reduce((a, b) => a + b, 0) / sky.length;
  if (avg < 25) return "Sunny";
  if (avg < 50) return "Mostly sunny";
  if (avg < 70) return "Partly cloudy";
  if (avg < 88) return "Mostly cloudy";
  return "Cloudy";
}

/**
 * After the workday: a freeze the night after a pour or planting, and (Oct. 9, 2026) rain in the
 * hours after fresh concrete, paint, or sealer, at heads-up level (a stop-level rain that soon
 * already moves the wrap time). Both at once read as one line: "Showers likely 6-10 PM (45%),
 * then a freeze tonight (low 27F): cover fresh concrete".
 */
function wdNightNotes(grid, trade, endAt, o) {
  const opt = o || {};
  const notes = [];
  const base = Math.floor(endAt.getTime() / WD_HOUR) * WD_HOUR;
  let low = null;
  if (trade.freezeNote) {
    for (let k = 0; k < 18; k++) {
      const h = grid.hours.get(base + k * WD_HOUR);
      if (h && h.tempF != null) low = low == null ? h.tempF : Math.min(low, h.tempF);
    }
  }
  const freeze = low != null && low <= 32;
  let rain = null;
  if (trade.afterRain && !opt.cureHit && !opt.stop && opt.tz) {
    const w = trade.watch || {};
    const floor = w.pop != null ? w.pop : 30;
    for (let k = 0; k < trade.afterRain; k++) {
      const h = grid.hours.get(base + k * WD_HOUR);
      if (!h || h.pop == null || h.pop < floor || h.snowy || h.ice) continue;
      const t = base + k * WD_HOUR;
      if (!rain) rain = { from: t, to: t + WD_HOUR, peak: h.pop, word: h.precipWord };
      else { rain.to = t + WD_HOUR; rain.peak = Math.max(rain.peak, h.pop); }
    }
  }
  const words = trade.words || {};
  // "Tonight" in the morning text; "tomorrow night" in the day-before text (Oct. 9, 2026).
  const night = opt.ymd ? wdNightWord(opt.ymd, opt.refYmd) : "tonight";
  const day = { dayYmd: opt.ymd || null, refYmd: opt.refYmd || opt.ymd || null };
  if (rain) {
    const what = `${wdChanceWord(rain.peak, rain.word === "showers" || rain.word === "drizzle" ? rain.word : "rain")} ${wdRangeText(new Date(rain.from), new Date(rain.to), opt.tz)} (${Math.round(rain.peak)}%)`;
    const tail = freeze ? `, then a freeze ${night} (low ${Math.round(low)}\u00B0F): ${words.afterRain || trade.freezeNote}` : ` after work: ${words.afterRain || "cover fresh work"}`;
    notes.push(Object.assign({ type: "afterrain", level: "watch", value: rain.peak, rain, low: freeze ? Math.round(low) : null, text: what + tail }, day));
  } else if (freeze) {
    notes.push(Object.assign({ type: "freeze", level: "watch", value: Math.round(low), text: `Freeze ${night} (low ${Math.round(low)}\u00B0F): ${trade.freezeNote}` }, day));
  }
  return notes;
}

/** A day as the reader says it on refYmd (Oct. 9, 2026): "today", "tomorrow", "yesterday", or a weekday ("Thu"). */
function wdRelDay(dayYmd, refYmd) {
  if (!refYmd || dayYmd === refYmd) return "today";
  if (dayYmd === addDaysYmd(refYmd, 1)) return "tomorrow";
  if (dayYmd === addDaysYmd(refYmd, -1)) return "yesterday";
  return weekdayOfYmd(dayYmd, "short");
}

/** The night after a day, as the reader says it: "tonight", "tomorrow night", "last night", "Thu night". */
function wdNightWord(ymd, refYmd) {
  const d = wdRelDay(ymd, refYmd);
  return d === "today" ? "tonight" : d === "yesterday" ? "last night" : `${d} night`;
}

/**
 * Heavy rain before the workday (Oct. 9, 2026), for trades that work the ground: "1.3 in. of rain
 * overnight: soft turf and heavy leaves, watch for ruts". The sender passes the nearest weather
 * station's amount (opts.pastRain: { inches, endedAt }); the website's check adds up the
 * forecast hours it has before work starts. Comes first in the text (first: true).
 */
function wdSoakNotes(grid, trade, firstHour, tz, o) {
  const sk = trade.soak;
  if (!sk || !firstHour) return [];
  const start = Math.floor(firstHour.getTime() / WD_HOUR) * WD_HOUR;
  let inches = null, endedAt = null;
  if (o && o.pastRain && typeof o.pastRain.inches === "number") {
    inches = o.pastRain.inches;
    endedAt = o.pastRain.endedAt || null;
  } else {
    let sum = 0, any = false;
    for (let k = 1; k <= sk.hours; k++) {
      const h = grid.hours.get(start - k * WD_HOUR);
      if (!h) continue;
      any = true;
      if ((h.qpfIn || 0) > WD_TRACE) { sum += h.qpfIn; if (endedAt == null) endedAt = start - (k - 1) * WD_HOUR; }
    }
    inches = any ? sum : null;
  }
  if (inches == null || inches < sk.inches) return [];
  // When it fell, by when it ended: before work that day = "overnight"; the evening before = "last
  // night"; earlier the day before = "yesterday". Read the day before (the day-before text), the
  // evening before is "tonight" and earlier that day is "today" (Oct. 9, 2026).
  const workDay = ymdInZone(firstHour, tz);
  const ref = (o && o.refYmd) || workDay;
  let when = ref === workDay ? `in the last ${sk.hours} hours` : `in the ${sk.hours} hours before work`, whenKey = ref === workDay ? "hours" : "before";
  if (endedAt != null && endedAt <= start) {
    const endDay = ymdInZone(new Date(endedAt - 1), tz);
    const endHour = wdLocalHour(new Date(endedAt - 1), tz);
    if (endDay === workDay) { when = "overnight"; whenKey = "overnight"; }
    else if (endDay === addDaysYmd(workDay, -1)) {
      const late = endHour >= 20, early = ref !== workDay && endDay === ref;
      whenKey = early ? (late ? "tonight" : "today") : (late ? "lastnight" : "yesterday");
      when = { tonight: "tonight", today: "today", lastnight: "last night", yesterday: "yesterday" }[whenKey];
    }
  }
  const words = trade.words || {};
  return [{ type: "soak", level: "watch", first: true, value: inches, when: whenKey, hours: sk.hours, text: `${wdInches(inches)} of rain ${when}: ${words.soaked || "the ground may be soft"}` }];
}

/* ---------- Reasons, in plain words ---------- */

// What matters most comes first: official alerts, then ice, storms, snow, rain, and so on.
const WD_REASON_ORDER = ["alert", "season", "ice", "icy", "thunder", "winter", "rain", "dayhigh", "rainahead", "nocure", "cure", "gust", "wind", "calm", "wet", "heat", "chill", "cold", "hot", "dew", "humid"];
// Limits with a number, where the heads-up and the stop are different numbers: a span of these
// never runs across both levels, so a text never pairs one level's number with the other's hours
// ("Gusts to 31 mph after 9 AM" when 31 came at 1 PM; fixed Oct. 9, 2026).
const WD_SPLIT_TYPES = ["gust", "wind", "calm", "cold", "hot", "heat", "chill", "dew", "humid"];
// Which stop/watch limit each kind of reason compares with (for its trade words).
const WD_LIMIT_KEY = { gust: "gust", wind: "wind", calm: "calm", cold: "below", hot: "above", heat: "heatIndex", chill: "windChill", humid: "humidity", dew: "dewSpread" };
// Heads-ups that mean it isn't dry (so a text never says "dry" next to them).
const WD_PRECIP_TYPES = ["ice", "thunder", "winter", "rain"];

function wdPriority(x) {
  const i = WD_REASON_ORDER.indexOf(x.type);
  return i < 0 ? 99 : i;
}

/** Groups each kind of problem into time spans: "Rain likely 7-11 AM (70%)". */
function wdReasons(hours, trade, tz, endAt, restOfDay) {
  const spans = [];
  WD_REASON_ORDER.forEach((type) => {
    let cur = null;
    const close = () => { if (cur) { spans.push(cur); cur = null; } };
    hours.forEach((slot) => {
      const hits = slot.hits.filter((x) => x.type === type);
      if (!hits.length) { close(); return; }
      const key = type === "alert" ? hits.map((x) => x.event).sort().join("|") : "";
      const split = WD_SPLIT_TYPES.indexOf(type) >= 0 ? wdTopLevel(hits) : "";
      if (cur && (cur.key !== key || cur.split !== split)) close();
      if (!cur) cur = { type, key, split, level: "watch", from: slot.t, to: null, peak: null, low: null, hits: [], rest: !!restOfDay };
      cur.to = new Date(slot.t.getTime() + WD_HOUR);
      hits.forEach((x) => {
        if (WD_LEVEL[x.level] > WD_LEVEL[cur.level]) cur.level = x.level;
        if (typeof x.value === "number") {
          cur.peak = cur.peak == null ? x.value : Math.max(cur.peak, x.value);
          cur.low = cur.low == null ? x.value : Math.min(cur.low, x.value);
        }
        cur.hits.push(x);
      });
      cur.precip = cur.precip || (slot.h && slot.h.precipWord);
    });
    close();
  });
  // Rain inside a storm span says the same thing twice.
  const storms = spans.filter((s) => s.type === "thunder");
  const kept = spans.filter((s) => !(s.type === "rain" && storms.some((t) => t.from <= s.from && t.to >= s.to && WD_LEVEL[t.level] >= WD_LEVEL[s.level])));
  kept.forEach((s) => { s.text = wdReasonText(s, trade, tz, hours[0].t, endAt); });
  return kept.sort((a, b) => (WD_LEVEL[b.level] - WD_LEVEL[a.level]) || (a.from - b.from) || (wdPriority(a) - wdPriority(b)));
}

function wdCap(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function wdChanceWord(pct, noun) {
  const n = noun || "rain";
  if (pct >= 80) return wdCap(n);
  if (pct >= 55) return `${wdCap(n)} likely`;
  if (pct >= 25) return `Chance of ${n}`;
  return `Slight chance of ${n}`;
}

function wdWhen(s, tz, dayStart, dayEnd, dash) {
  // A group of same-kind spans (wdGroupSpans): "until 8 AM, 11 AM-1 PM, and after 3 PM"; past
  // three, "at times" over the whole stretch.
  if (s.parts && s.parts.length > 1) {
    if (s.parts.length > 3) return `at times ${wdWhen({ from: s.from, to: s.to, rest: s.rest }, tz, dayStart, dayEnd, dash)}`;
    const w = s.parts.map((p) => wdWhen(p, tz, dayStart, dayEnd, dash));
    return w.length === 2 ? `${w[0]} and ${w[1]}` : `${w[0]}, ${w[1]}, and ${w[2]}`;
  }
  const all = s.from.getTime() <= dayStart.getTime() && s.to.getTime() >= dayEnd.getTime();
  if (all) return s.rest ? "for the rest of the workday" : "all day";
  if (s.from.getTime() <= dayStart.getTime()) return `until ${wdTimeText(s.to, tz)}`;
  if (s.to.getTime() >= dayEnd.getTime()) return `after ${wdTimeText(s.from, tz)}`;
  return wdRangeText(s.from, s.to, tz, dash);
}

/** The hit in a span that set its level (for the limit it crossed). */
function wdTopHit(s) {
  return s.hits.reduce((m, x) => (WD_LEVEL[x.level] > WD_LEVEL[m.level] ? x : m), s.hits[0]);
}

function wdReasonText(s, trade, tz, dayStart, dayEnd, dash) {
  const when = wdWhen(s, tz, dayStart, dayEnd, dash);
  const words = trade.words || {};
  const r = (v) => Math.round(v);
  const pct = s.peak != null ? ` (${r(s.peak)}%)` : "";
  // A limit's words go with the span that crossed the limit they explain: the stop span, or the
  // heads-up span when the trade has no stop limit of that kind (Oct. 9, 2026).
  const say = (k) => (s.level === "stop" || (trade.stop || {})[WD_LIMIT_KEY[s.type]] == null) && words[k] ? `: ${words[k]}` : "";
  switch (s.type) {
    case "rain": return `${wdChanceWord(s.peak || 0, s.precip === "storms" || !s.precip ? "rain" : s.precip)} ${when}${pct}`;
    case "thunder": return `${s.peak >= 55 ? "Storms likely" : "Chance of storms"} ${when}${pct}${words.thunder ? `: ${words.thunder}` : ""}`;
    case "winter": return `${wdChanceWord(s.peak != null ? s.peak : 30, /sleet/.test(s.precip || "") ? "sleet" : "snow")} ${when}${pct}`;
    case "ice": return `${wdChanceWord(s.peak != null ? s.peak : 30, "freezing rain")} ${when}${pct}: icy surfaces`;
    case "icy": return `${wdCap(words.icy || "icy surfaces")} ${when} (${r(s.peak)}\u00B0F or colder)`;
    case "gust": return s.windPeak != null ? `Winds to ${r(s.windPeak)} mph, gusts to ${r(s.peak)} mph ${when}${say("wind") || say("gust")}`
      : `Gusts to ${r(s.peak)} mph ${when}${say("gust")}`;
    case "wind": return `Winds to ${r(s.peak)} mph ${when}${say("wind")}`;
    case "calm": return `Wind under ${wdTopHit(s).limit} mph ${when}${words.calm ? `: ${words.calm}` : ""}`;
    case "cold": return `Below ${wdTopHit(s).limit}\u00B0F ${when}${say("below")}`;
    case "hot": return `Above ${wdTopHit(s).limit}\u00B0F ${when} (up to ${r(s.peak)}\u00B0F)${say("above")}`;
    case "heat": return `Heat index up to ${r(s.peak)}\u00B0F ${when}${words.heatIndex ? `: ${words.heatIndex}` : ""}`;
    case "chill": return `Wind chill down to ${r(s.low)}\u00B0F ${when}`;
    case "dew": return `Dew likely ${when}${words.dew ? `: ${words.dew}` : ""}`;
    case "humid": return `Humidity ${r(s.peak)}% ${when}${words.humidity ? `: ${words.humidity}` : ""}`;
    case "wet": return `${wdCap(words.wet || "surfaces may be wet")} ${when}`;
    case "cure": {
      const rainAt = s.hits.map((x) => x.rainAt).filter(Boolean).sort((a, b) => a - b)[0];
      return `Rain due ${rainAt ? "by " + wdTimeText(rainAt, tz) : "soon after"}: ${words.cure || `fresh work needs ${trade.cureHours} dry hours`}`;
    }
    case "alert": {
      const a = s.hits[0].alert;
      const until = a && typeof alertUntilText === "function" ? alertUntilText(a.props, tz) : "";
      return `NWS ${s.hits[0].event}${until ? " " + until : ""}`;
    }
    case "season": return trade.lastDayWho ? `Past ${trade.lastDayText}, ${trade.lastDayWho}'s cutoff: no more spraying this season`
      : `Past ${trade.lastDayText || "the label's last day"}: the label's season is over`;
    case "nocure": {
      const x = s.hits.filter((y) => y.rainAt).sort((a, b) => a.rainAt - b.rainAt)[0];
      const n = trade.cureDays || 3;
      return x ? `${wdChanceWord(x.value, "rain")} from ${wdDayTimeText(x.rainAt, tz, s.from)} (${r(x.value)}%): not ${n} dry days for hay to cure, so don't cut`
        : `Not ${n} dry days for hay to cure, so don't cut`;
    }
    case "dayhigh": {
      const x = wdTopHit(s), dh = trade.dayHigh || {};
      // Days as the reader says them: the day-before text reads a day early (Oct. 9, 2026).
      const call = x.callYmd, ref = x.refYmd || call;
      const rel = (i) => (call ? wdRelDay(addDaysYmd(call, i), ref) : i ? "tomorrow" : "today");
      if (x.missing) return `${wdCap(rel(x.day != null ? x.day : 1))}'s high isn't in the forecast yet: check it before you spray`;
      const both = !call || ref === call ? "today or tomorrow" : ref === addDaysYmd(call, -1) ? "tomorrow or the day after" : `${rel(0)} or ${rel(1)}`;
      return s.level === "stop" ? `Forecast high ${r(x.value)}\u00B0F ${rel(x.day || 0)}: the label bars spraying at ${dh.stop}\u00B0F or hotter ${both}`
        : `Forecast high ${r(x.value)}\u00B0F ${rel(x.day || 0)}: at ${dh.watch}-${dh.stop - 1}\u00B0F the label limits how many acres you can spray`;
    }
    case "rainahead": {
      const x = s.hits.filter((y) => y.rainAt).sort((a, b) => a.rainAt - b.rainAt)[0];
      const hrs = (trade.rainAhead && trade.rainAhead.hours) || 48;
      if (!x) return `The rain forecast for the next ${hrs} hours isn't out yet: check it before you spray`;
      return `Rain in the forecast within ${hrs} hours ${when} (${r(x.value)}% by ${wdDayTimeText(x.rainAt, tz, s.from)}): the label bars spraying`;
    }
    default: return "";
  }
}

/* ---------- Text messages ---------- */
// Texts use only the standard SMS character set (no curly quotes, dashes, degree signs,
// or accents), so each part holds 160 characters and never switches to costly "unicode" texts.

function wdPlain(s) {
  return String(s == null ? "" : s)
    .replace(/[\u2018\u2019\u201A\u2032`\u00B4]/g, "'").replace(/[\u201C\u201D\u201E\u2033]/g, '"')
    .replace(/[\u2013\u2014\u2212~]/g, "-").replace(/\u00B0F/g, "F").replace(/\u00B0/g, "")
    .replace(/\u00A0/g, " ").replace(/\u2026/g, "...")
    .replace(/[\[{]/g, "(").replace(/[\]}]/g, ")").replace(/[|\\]/g, "/").replace(/\^/g, "")
    .normalize("NFD").replace(/[\u0300-\u036F]/g, "")
    .replace(/[^A-Za-z0-9 \n!"#$%&'()*+,\-./:;<=>?@_]/g, "");
}

/** Standard texts carry 160 characters, or 153 per part when split. */
function wdSmsParts(text) {
  const len = String(text).length;
  return len <= 160 ? 1 : Math.ceil(len / 153);
}

/** "57-62F, gusts to 18 mph" for the hours the crew works. */
function wdStatsText(st) {
  if (!st) return "";
  const parts = [];
  if (st.lo != null && st.hi != null) parts.push(st.hi - st.lo >= 4 ? `${st.lo}-${st.hi}F` : `${st.hi}F`);
  if (st.gust != null) parts.push(st.gust < 10 ? "light wind" : `gusts to ${st.gust} mph`);
  return parts.join(", ");
}

/**
 * Spans of one kind and level, said once (Oct. 9, 2026): "Gusts to 34 mph until 8 AM, 11 AM-1 PM,
 * and after 3 PM", not "gusts to" three times over. Only kinds measured by a limit of their own
 * group (gusts, wind, cold, heat, dew ...); rain and storms keep their own chances. A group keeps
 * its spans in `parts`, in time order, and takes the highest peak and lowest low.
 */
function wdGroupSpans(list) {
  // Rain, snow, and storms group only when they'd read the same ("Chance of rain 7-8 AM and
  // noon-1 PM (47%)"); a likely rain and a chance of rain stay apart.
  const chance = (s) => (s.type === "thunder" ? (s.peak >= 55 ? "likely" : "chance") : wdChanceWord(s.peak || 0, s.precip || ""));
  const key = (s) => (WD_SPLIT_TYPES.indexOf(s.type) >= 0 ? `${s.type}|${s.level}`
    : ["rain", "winter", "thunder"].indexOf(s.type) >= 0 ? `${s.type}|${s.level}|${s.precip || ""}|${chance(s)}` : "");
  const out = [];
  list.forEach((s) => {
    if (!key(s)) { out.push(s); return; }
    const g = out.find((x) => x.parts && x.groupKey === key(s));
    if (!g) { out.push(Object.assign({}, s, { parts: [s], groupKey: key(s) })); return; }
    g.parts.push(s);
    g.parts.sort((a, b) => a.from - b.from);
    g.from = g.parts[0].from;
    g.to = new Date(Math.max(...g.parts.map((p) => p.to.getTime())));
    if (s.peak != null) g.peak = g.peak == null ? s.peak : Math.max(g.peak, s.peak);
    if (s.low != null) g.low = g.low == null ? s.low : Math.min(g.low, s.low);
    g.hits = g.hits.concat(s.hits);
  });
  return out.map((x) => (x.parts && x.parts.length === 1 ? x.parts[0] : x));
}

/** "until 8 AM, after 3 PM" as a key: two spans or groups over the very same hours. */
function wdHoursKey(s) {
  return (s.parts || [s]).map((p) => `${p.from.getTime()}-${p.to.getTime()}`).join(",");
}

/**
 * Winds and gusts over the same hours are one reason (Oct. 9, 2026): "Winds to 21 mph, gusts to
 * 31 mph after 3 PM", not two sentences with the same hours.
 */
function wdMergeWind(list) {
  const out = [];
  list.forEach((x) => {
    const twin = (type) => list.find((y) => y.type === type && y.level === x.level && wdHoursKey(y) === wdHoursKey(x));
    if (x.type === "wind" && twin("gust")) return;
    const w = x.type === "gust" ? twin("wind") : null;
    out.push(w ? Object.assign({}, x, { windPeak: w.peak, hits: x.hits.concat(w.hits) }) : x);
  });
  return out;
}

/**
 * A STOP with several stretches of bad weather (Oct. 9, 2026): the (up to 3) reasons that cover
 * the most of the day, each kind said once (wdGroupSpans) and none already inside another, in time
 * order, so the reader sees the day. Fresh work (or hay that won't cure) and the rain it can't
 * take are one reason ({ x: cure, wet: the rain }), each rain is said once, and the trade's words
 * for it ("fresh paint needs 4 dry hours") go with the first such reason only ({ why: true }).
 * Null when one stretch covers the whole day.
 */
function wdStopList(r) {
  const raw = r.reasons.filter((x) => x.level === "stop");
  if (raw.length < 2 || raw.some((x) => x.from <= r.window.from && x.to >= r.window.to)) return null;
  const spans = wdMergeWind(wdGroupSpans(raw));
  const partsOf = (x) => x.parts || [x];
  const hoursOf = (x) => partsOf(x).reduce((n, p) => n + (p.to - p.from), 0);
  const inside = (x, list) => partsOf(x).every((p) => list.some((c) => partsOf(c).some((q) => q.from <= p.from && q.to >= p.to)));
  const picked = [];
  spans.slice().sort((a, b) => (hoursOf(b) - hoursOf(a)) || (wdPriority(a) - wdPriority(b))).forEach((x) => {
    if (picked.length < 3 && !inside(x, picked)) picked.push(x);
  });
  picked.sort((a, b) => (a.from - b.from) || (wdPriority(a) - wdPriority(b)));
  const items = [];
  let why = false;
  // Each stretch of rain is said once (Oct. 9, 2026 review: two fresh-work spans before one group
  // of showers said the showers twice). A rain already in the list takes the fresh work's words.
  const holder = (wet) => items.find((it) => it.x === wet || it.wet === wet);
  // Hay that won't cure pairs with its rain the same way (Oct. 9, 2026).
  picked.forEach((x) => {
    if (x.type !== "cure" && x.type !== "nocure") { if (!holder(x)) items.push({ x }); return; }
    const at = x.hits.map((y) => y.rainAt).filter(Boolean).sort((a, b) => a - b)[0] || null;
    const wet = at ? spans.find((y) => WD_PRECIP_TYPES.indexOf(y.type) >= 0 && partsOf(y).some((p) => p.from.getTime() === at.getTime())) : null;
    const had = wet ? holder(wet) : null;
    if (had) {
      if (!had.wet) { had.x = x; had.wet = wet; had.why = !why; why = true; }
      return;
    }
    items.push({ x, wet: wet || null, why: !why });
    why = true;
  });
  return items;
}

/** The reasons a text should mention, most important first, for any call. */
function wdSmsReasons(r) {
  const rawStops = r.reasons.filter((x) => x.level === "stop");
  const stops = wdMergeWind(wdGroupSpans(rawStops));
  const byImportance = (a, b) => (wdPriority(a) - wdPriority(b)) || (a.from - b.from);
  const hoursOf = (x) => (x.parts || [x]).reduce((n, p) => n + (p.to - p.from), 0) / WD_HOUR;
  const alerts = r.reasons.filter((x) => x.type === "alert").sort((a, b) => WD_LEVEL[b.level] - WD_LEVEL[a.level]);
  // Past the season's last day, that's the whole story (Oct. 9, 2026).
  const season = stops.find((x) => x.type === "season");
  if (season) return { lead: [season], extra: alerts.filter((a) => a.level === "stop"), heads: [] };
  // Heads-ups for the hours being worked (an official alert always makes the text).
  const inWork = (x) => !r.best || (x.from < r.best.to && x.to > r.best.from);
  const watches = wdMergeWind(wdGroupSpans(r.reasons.filter((x) => x.level === "watch" && inWork(x))));
  let lead = [];
  if (r.call === "stop") {
    // Hay that won't cure already names the rain that stops it; the same rain isn't said twice.
    const nc = rawStops.find((x) => x.type === "nocure");
    const ncAt = nc ? nc.hits.map((y) => y.rainAt).filter(Boolean).sort((a, b) => a - b)[0] : null;
    const pool = ncAt ? wdMergeWind(wdGroupSpans(rawStops.filter((x) => !(WD_PRECIP_TYPES.indexOf(x.type) >= 0 && x.from.getTime() >= ncAt.getTime())))) : stops;
    lead = pool.slice().sort((a, b) => (b.type === "alert") - (a.type === "alert") || (hoursOf(b) - hoursOf(a)) || byImportance(a, b)).slice(0, 2);
  } else if (r.call === "delay") {
    lead = stops.filter((x) => x.from < r.startAt).sort(byImportance).slice(0, 2);
    // The reason for the wrap time: any stop still going at that time (Oct. 5, 2026; a span that
    // starts as a heads-up before the wrap used to be left out).
    if (r.until) lead = lead.concat(stops.filter((x) => x.to > r.until && !lead.includes(x)).sort((a, b) => a.from - b.from).slice(0, 1));
  } else if (r.until) {
    lead = stops.filter((x) => x.to > r.until).sort(byImportance).slice(0, 2);
  }
  // A wind heads-up next to a wind stop says what the text's own "gusts to" already says, so it's
  // left out.
  const windy = (x) => x.type === "gust" || x.type === "wind";
  const heads = watches.filter((x) => !(windy(x) && lead.some(windy))).sort(byImportance);
  const extra = [];
  alerts.forEach((a) => { if (!lead.includes(a) && !extra.includes(a)) extra.push(a); });
  heads.forEach((x) => { if (extra.length < 2 && !extra.includes(x) && !lead.includes(x)) extra.push(x); });
  return { lead, extra, heads };
}

/** One site's line in the morning text. `compact` keeps just the call and its main reason. */
function wdSmsLine(siteName, r, compact) {
  const name = wdPlain(siteName).trim() || "Job site";
  if (r.over) return `${name}: workday over.`;
  if (r.call === "unknown") return r.cureGap ? `${name}: NO CALL YET. The NWS forecast doesn't cover all ${(r.tradeObj || {}).cureDays || 3} days hay needs to cure yet.`
    : `${name}: NO CALL YET. The NWS forecast doesn't cover these hours yet.`;
  const trade = r.tradeObj || wdTrade(r.tradeKey);
  const say = (x) => wdPlain(wdReasonText(x, trade, r.tz, r.window.from, r.window.to, "-"));
  const { lead, extra, heads } = wdSmsReasons(r);
  if (compact) {
    const first = lead[0] || extra[0];
    const alert = lead.concat(extra).find((x) => x.type === "alert");
    const bits = [first, alert && alert !== first ? alert : null].filter(Boolean).map((x) => say(x).split(": ")[0]);
    return `${name}: ${r.label}${bits.length ? " - " + bits.join("; ") : ""}`;
  }
  const precipHead = heads.some((x) => WD_PRECIP_TYPES.includes(x.type));
  const dry = r.stats && r.stats.pop != null && r.stats.pop < 25 && !precipHead;
  const statsTxt = wdStatsText(r.stats);
  // Notes that matter before anything else (heavy rain before work) lead the line (Oct. 9, 2026).
  const parts = (r.notes || []).filter((nt) => nt.first).map((nt) => wdPlain(nt.text));
  if (r.call === "stop") {
    const list = wdStopList(r);
    const oneCovers = r.reasons.some((x) => x.level === "stop" && x.from <= r.window.from && x.to >= r.window.to);
    // The longest workable stretch, when there is one: "Only 10 AM-noon is workable, and the
    // job needs 4 hours" (Oct. 9, 2026; it used to say "No 4-hour workable stretch").
    const lg = !oneCovers && r.longest && r.longest.len > 0 ? r.longest : null;
    const need = r.need > 1 ? `, and the job needs ${r.need} hours` : "";
    const windowTxt = !lg ? "" : lg.runs > 1 ? `The longest workable stretch is ${wdRangeText(lg.from, lg.to, r.tz, "-")}${need}`
      : `Only ${wdRangeText(lg.from, lg.to, r.tz, "-")} is workable${need}`;
    if (list) {
      // Several stretches of bad weather, briefly and in order (wdStopList).
      const lower = (t) => (/^NWS /.test(t) ? t : t.charAt(0).toLowerCase() + t.slice(1));
      const head = (x) => say(x).split(": ")[0];
      const why = (trade.words && trade.words.cure) || `fresh work needs ${trade.cureHours} dry hours`;
      // Hay's rain keeps its reason too: "rain likely from Wed noon (60%), so not 3 dry days for hay
      // to cure" (Oct. 9, 2026: a morning shower can now come first in the list).
      const tail = (it) => (!it.why ? "" : it.x.type === "nocure" ? `, so not ${trade.cureDays || 3} dry days for hay to cure` : `, and ${why}`);
      const short = list.map((it) => lower(it.x.type === "cure" || it.x.type === "nocure" ? `${head(it.wet || it.x)}${tail(it)}` : head(it.x)));
      parts.push(`${windowTxt || (r.restOfDay ? "No workable hours left" : "No workable hours")}: ${short.join("; ")}`);
    } else {
      parts.push(lead.map(say).join(". "));
      if (windowTxt) parts.push(windowTxt);
    }
    extra.filter((x) => x.type === "alert" && !parts.join(" ").includes(x.hits[0].event)).forEach((x) => parts.push(say(x)));
  } else if (r.call === "delay") {
    lead.forEach((x) => parts.push(say(x)));
    if (r.shortBefore && r.need > 1) parts.push(`Before that, only ${wdRangeText(r.shortBefore.from, r.shortBefore.to, r.tz, "-")} is workable, and the job needs ${r.need} hours`);
    // A delay with a wrap time: the window itself, so "then dry" never follows the wrap's reason.
    if (statsTxt) parts.push(r.until ? `Window ${wdRangeText(r.startAt, r.until, r.tz, "-")}: ${dry ? "dry, " : ""}${statsTxt}` : `Then ${dry ? "dry, " : ""}${statsTxt}`);
    extra.forEach((x) => parts.push(say(x)));
  } else if (r.until) {
    lead.forEach((x) => parts.push(say(x)));
    if (statsTxt) parts.push(dry ? `Dry till then, ${statsTxt}` : `Till then: ${statsTxt}`);
    extra.forEach((x) => parts.push(say(x)));
  } else {
    extra.forEach((x) => parts.push(say(x)));
    const pop = r.dayStats && r.dayStats.pop != null ? r.dayStats.pop : 0;
    const lead2 = precipHead ? "" : pop < 20 ? "Dry" : `Mostly dry (${pop}% rain chance)`;
    parts.push([lead2, statsTxt].filter(Boolean).join(", "));
  }
  (r.notes || []).filter((nt) => !nt.first).slice(0, 2).forEach((nt) => parts.push(wdPlain(nt.text)));
  return `${name}: ${r.label}. ${wdOnceEach(parts).join(". ")}.`.replace(/\.\./g, ".");
}

/**
 * The trade's words after a reason are said once per line (Oct. 9, 2026): "Winds to 19 mph all
 * day: drift risk, check your label's wind limits. Gusts to 35 mph at times 7 AM-7 PM" (the
 * second "drift risk ..." left off).
 */
function wdOnceEach(parts) {
  const said = new Set();
  return parts.filter(Boolean).map((p) => {
    const i = p.indexOf(": ");
    if (i < 0) return p;
    const tail = p.slice(i + 2);
    if (said.has(tail)) return p.slice(0, i);
    said.add(tail);
    return p;
  });
}

/**
 * The morning text for one phone. One or two sites get full lines; three or more get one
 * short line each; if that still runs past 4 parts, a summary lists only the sites that
 * aren't a plain GO.
 */
function wdMorningSms(sites, ymd) {
  const head = `Hard Hat Weather - ${weekdayOfYmd(ymd, "short")} ${Number(ymd.slice(5, 7))}/${Number(ymd.slice(8, 10))}`;
  const foot = "Reply STOP to opt out";
  const build = (lines) => [head].concat(lines).concat([foot]).join("\n");
  if (sites.length <= 2) return build(sites.map((s) => wdSmsLine(s.name, s.result)));
  const compact = build(sites.map((s) => wdSmsLine(s.name, s.result, true)));
  if (compact.length <= 612) return compact;
  // Too long: group the sites by their call ("STOP: Oak St, Main St"), plain GOs last.
  const count = (c) => sites.filter((s) => !s.result.over && s.result.call === c).length;
  const tally = [["go", "GO"], ["delay", "DELAY"], ["stop", "STOP"], ["unknown", "NO CALL"]].filter(([c]) => count(c)).map(([c, w]) => `${count(c)} ${w}`).join(", ");
  const groups = new Map();
  const order = { stop: 0, unknown: 1, delay: 2, go: 3 };
  sites.slice().sort((a, b) => (order[a.result.call] - order[b.result.call])).forEach((s) => {
    if (s.result.over) return;
    const key = s.result.call === "go" && !s.result.until ? "GO" : s.result.label;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(wdPlain(s.name).trim() || "Job site");
  });
  // Official alerts always make the text: "NWS Tornado Watch: Oak St, Main St".
  const alertSites = new Map();
  sites.forEach((s) => (s.result.reasons || []).filter((x) => x.type === "alert").forEach((x) => {
    const ev = x.hits[0].event;
    if (!alertSites.has(ev)) alertSites.set(ev, []);
    const nm = wdPlain(s.name).trim() || "Job site";
    if (!alertSites.get(ev).includes(nm)) alertSites.get(ev).push(nm);
  }));
  const alertLines = [...alertSites].slice(0, 3).map(([ev, names]) => wdPlain(`NWS ${ev}: ${names.join(", ")}`));
  const groupLines = [];
  groups.forEach((names, label) => { if (label !== "GO") groupLines.push(`${label}: ${names.join(", ")}`); });
  const goLine = groups.has("GO") ? [groups.size > 1 ? "All other sites: GO." : "All sites: GO."] : [];
  const assemble = (extra) => build([`${sites.length} sites: ${tally}`].concat(alertLines, groupLines, goLine, extra || []));
  let text = assemble();
  // Still too long (lots of long names): drop call lines from the end, keep the counts and alerts.
  while (text.length > 612 && groupLines.length) {
    groupLines.pop();
    text = assemble(["Details on your dashboard."]);
  }
  return text;
}

/** A warning text when the NWS issues a warning that covers a site. */
function wdWarningSms(siteName, alertProps, tz) {
  const p = alertProps || {};
  const until = typeof alertUntilText === "function" ? alertUntilText(p, tz) : "";
  const params = p.parameters || {};
  const extra = [];
  const gust = params.maxWindGust && String(params.maxWindGust[0] || "").match(/\d+/);
  if (gust) extra.push(`Gusts to ${gust[0]} mph possible`);
  const hail = params.maxHailSize && String(params.maxHailSize[0] || "").match(/[\d.]+/);
  if (hail && Number(hail[0]) > 0) extra.push(`hail up to ${Number(hail[0])} ${Number(hail[0]) === 1 ? "inch" : "inches"}`);
  const tornado = params.tornadoDetection && String(params.tornadoDetection[0] || "");
  if (tornado) extra.push(`Tornado ${tornado.toLowerCase()}`);
  return [
    `Hard Hat Weather WARNING - ${wdPlain(siteName)}`,
    `NWS ${wdPlain(p.event || "warning")}${until ? " " + wdPlain(until) : ""}.${extra.length ? " " + wdPlain(extra.join(", ")) + "." : ""} Follow your crew's safety plan.`,
    "Reply STOP to opt out",
  ].join("\n");
}

const WD_SMS_CONFIRM = "Hard Hat Weather from La Porte Weather Now: you're signed up for job-site weather calls. Usually 1-3 msgs per workday. Msg & data rates may apply. Reply HELP for help, STOP to cancel.";

/* ---------- Loading a job site ---------- */

const wdCache = new Map();

async function wdGetWithRetry(url, tries, ms) {
  let last;
  for (let i = 0; i < (tries || 3); i++) {
    try { return await nwsGet(url, ms || 20000); } catch (e) {
      last = e;
      if (e.status === 404 || e.status === 400) break;   // NWS has no data there; retrying won't help
      await new Promise((r) => setTimeout(r, 700 * (i + 1)));
    }
  }
  throw last;
}

/**
 * Everything the engine needs for one spot: time zone, NWS grid, and active alerts.
 * Cached for 10 minutes so switching trades or days doesn't ask NWS again.
 */
async function wdLoadPoint(lat, lon) {
  const key = `${lat.toFixed(4)},${lon.toFixed(4)}`;
  const hit = wdCache.get(key);
  if (hit && Date.now() - hit.at < 600000) return hit.promise;
  const promise = (async () => {
    const point = await wdGetWithRetry(`${NWS_BASE}/points/${key}`, 2, 15000);
    const props = point.properties || {};
    if (!props.forecastGridData) { const e = new Error("No NWS forecast grid here"); e.status = 404; throw e; }
    const [gridR, alertsR] = await Promise.allSettled([
      wdGetWithRetry(props.forecastGridData, 3, 25000),
      nwsGet(`${NWS_BASE}/alerts/active?point=${key}`, 12000),
    ]);
    if (gridR.status !== "fulfilled") throw gridR.reason;
    const rel = props.relativeLocation && props.relativeLocation.properties;
    return {
      lat, lon,
      tz: nwsPointTimeZone(props) || "America/Chicago",
      state: wdZoneState(props),
      place: rel ? `${rel.city}, ${rel.state}` : "",
      office: props.gridId || props.cwa || "",
      grid: wdParseGrid(gridR.value),
      alerts: alertsR.status === "fulfilled" ? sortAlerts(liveAlerts(alertsR.value.features)) : null,
      loadedAt: new Date(),
    };
  })();
  wdCache.set(key, { at: Date.now(), promise });
  promise.catch(() => wdCache.delete(key));
  return promise;
}

/**
 * A spot's state from its NWS forecast or county zone ("INZ103" -> "IN"), which follows state
 * lines (a nearby city's state can be across the line). "" when the NWS doesn't say.
 */
function wdZoneState(props) {
  const p = props || {};
  const m = /\/([A-Z]{2})[ZC]\d{3}$/.exec(String(p.forecastZone || p.county || ""));
  return m ? m[1] : "";
}

/** The call for a site on a given day ("today", "tomorrow", or "YYYY-MM-DD"). */
function wdCallFor(point, tradeKey, day, opts) {
  const o = opts || {};
  const now = o.now || new Date();
  const today = ymdInZone(now, point.tz);
  const ymd = day === "tomorrow" ? addDaysYmd(today, 1) : day === "today" || !day ? today : day;
  return wdDecideDay(point.grid, tradeKey, ymd, Object.assign({ tz: point.tz, now, alerts: point.alerts || [], lat: point.lat, lon: point.lon, state: point.state || "" }, o));
}

/** Before 11 AM at the site, today's call matters most; after that, tomorrow's. */
function wdDefaultDay(tz, now) {
  return wdLocalHour(now || new Date(), tz) < 11 ? "today" : "tomorrow";
}

/* ---------- Sunrise and sunset, label rules, livestock (Oct. 5, 2026) ---------- */

/**
 * Sunrise and sunset on a date at a spot ({ rise, set } as Dates), from the standard sunrise
 * equation (good to a minute or two), or null when the sun doesn't rise or set that day.
 */
function wdSunTimes(lat, lon, ymd) {
  const rad = Math.PI / 180;
  const noonJ = ymdToUTCDate(ymd).getTime() / 86400000 + 2440587.5;   // ymdToUTCDate is noon UTC
  const n = Math.round(noonJ - 2451545.0 + 0.0008);
  const jStar = n - lon / 360;
  const M = (357.5291 + 0.98560028 * jStar) % 360;
  const C = 1.9148 * Math.sin(M * rad) + 0.02 * Math.sin(2 * M * rad) + 0.0003 * Math.sin(3 * M * rad);
  const L = (M + C + 180 + 102.9372) % 360;
  const transit = 2451545.0 + jStar + 0.0053 * Math.sin(M * rad) - 0.0069 * Math.sin(2 * L * rad);
  const sinD = Math.sin(L * rad) * Math.sin(23.4397 * rad);
  const cosD = Math.cos(Math.asin(sinD));
  const cosW = (Math.sin(-0.833 * rad) - Math.sin(lat * rad) * sinD) / (Math.cos(lat * rad) * cosD);
  if (cosW > 1 || cosW < -1) return null;
  const w = Math.acos(cosW) / rad;
  const ms = (j) => new Date(Math.round((j - 2440587.5) * 86400000));
  return { rise: ms(transit - w / 360), set: ms(transit + w / 360) };
}

/** A label's time-of-day window on a date: { from, to (Dates), fromH, toH (whole local hours inside it), text }. */
function wdSunWindow(lat, lon, ymd, tz, sw) {
  const sun = wdSunTimes(lat, lon, ymd);
  if (!sun) return null;
  const from = new Date(sun.rise.getTime() + (sw.afterRise || 0) * WD_HOUR), to = new Date(sun.set.getTime() - (sw.beforeSet || 0) * WD_HOUR);
  const local = (d) => { const t = new Date(d.getTime() + tzOffsetMinutes(d, tz) * 60000); return t.getUTCHours() + t.getUTCMinutes() / 60; };
  const clock = (d) => fmtInZone(d, tz, { hour: "numeric", minute: "2-digit" });
  return { from, to, rise: sun.rise, set: sun.set, fromH: Math.ceil(local(from) - 1e-9), toH: Math.floor(local(to) + 1e-9), text: `${clock(from)}-${clock(to)}` };
}

/** The day's forecast high (from the hours the grid has, at least 6 of them), or null. */
function wdDayHigh(grid, ymd, tz) {
  let hi = null, n = 0;
  for (let h = 0; h < 24; h++) {
    const x = grid.hours.get(Math.floor(zonedDateTime(ymd, h, tz).getTime() / WD_HOUR) * WD_HOUR);
    if (x && x.tempF != null) { n++; hi = hi == null ? x.tempF : Math.max(hi, x.tempF); }
  }
  return n >= 6 ? hi : null;
}

/** "3 PM" on the same day as `ref`, "Wed 3 PM" on another day. */
function wdDayTimeText(d, tz, ref) {
  const day = ymdInZone(d, tz);
  return ref && ymdInZone(ref, tz) === day ? wdTimeText(d, tz) : `${weekdayOfYmd(day, "short")} ${wdTimeText(d, tz)}`;
}

/**
 * Label rules that look past one hour (dicamba): past the season's last day, every hour stops;
 * a forecast high at or past dayHigh.stop today or tomorrow stops the day (dayHigh.watch: a
 * heads-up); rain in the forecast within rainAhead.hours of an hour stops that hour.
 */
function wdLabelRules(grid, trade, ymd, tz, hours, refYmd) {
  const add = (slot, hit) => { slot.hits.push(hit); slot.level = wdTopLevel(slot.hits); };
  if (trade.lastDay && ymd.slice(5) > trade.lastDay) hours.forEach((slot) => add(slot, { type: "season", level: "stop" }));
  if (trade.dayHigh) {
    const dh = trade.dayHigh;
    let worst = null, missing = null;
    for (let i = 0; i < (dh.days || 2); i++) {
      const v = wdDayHigh(grid, addDaysYmd(ymd, i), tz);
      if (v == null) { if (missing == null) missing = i; continue; }
      if (!worst || v > worst.value) worst = { value: v, day: i };
    }
    // Each hit knows its day and the day the text is read, for "today", "tomorrow" (Oct. 9, 2026).
    const ref = { callYmd: ymd, refYmd: refYmd || ymd };
    if (worst && worst.value >= dh.stop) hours.forEach((slot) => add(slot, Object.assign({ type: "dayhigh", level: "stop", value: worst.value, day: worst.day }, ref)));
    else if (worst && worst.value >= dh.watch) hours.forEach((slot) => add(slot, Object.assign({ type: "dayhigh", level: "watch", value: worst.value, day: worst.day }, ref)));
    else if (missing != null) hours.forEach((slot) => add(slot, Object.assign({ type: "dayhigh", level: "watch", missing: true, day: missing }, ref)));
  }
  if (trade.rainAhead) {
    const ra = trade.rainAhead;
    hours.forEach((slot) => {
      const t0 = Math.floor(slot.t.getTime() / WD_HOUR) * WD_HOUR;
      let missing = false;
      for (let k = 1; k <= ra.hours; k++) {
        const h = grid.hours.get(t0 + k * WD_HOUR);
        if (!h || h.pop == null) { missing = true; continue; }
        if (h.pop >= ra.pop || (h.qpfIn || 0) > WD_TRACE) {
          add(slot, { type: "rainahead", level: "stop", value: h.pop, rainAt: new Date(t0 + k * WD_HOUR) });
          return;
        }
      }
      if (missing) add(slot, { type: "rainahead", level: "watch", missing: true });
    });
  }
}

/** Notes for a label's trade: the day's time-of-day window, and the season's end coming up. */
function wdLabelNotes(trade, ymd, sunNote, refYmd) {
  const notes = [];
  if (sunNote) notes.push(sunNote);
  const md = ymd.slice(5);
  if (trade.lastDay && trade.lastDayNoteFrom && md >= trade.lastDayNoteFrom && md <= trade.lastDay) {
    // Days left, counted from the day the text is read (the day before, for the day-before text).
    const left = wdDaysBetween(refYmd || ymd, `${ymd.slice(0, 4)}-${trade.lastDay}`);
    const leftText = left <= 0 ? "today is the last day" : left === 1 ? "tomorrow is the last day" : `${left} days left`;
    if (trade.lastDayWho) {
      // A state's own cutoff (Indiana: June 12), Oct. 9, 2026.
      notes.push({ type: "season", level: "watch", who: trade.lastDayWho, day: trade.lastDay, left, text: `${trade.lastDayWho}'s cutoff is ${trade.lastDayText} (${leftText}), and the label's crop-stage limit still applies: check your crop stage` });
    } else {
      const others = Object.keys(trade.stateLastDay || {}).map((k) => `${trade.stateLastDay[k].text} in ${trade.stateLastDay[k].who}`);
      notes.push({ type: "season", level: "watch", day: trade.lastDay, left, others: Object.keys(trade.stateLastDay || {}).map((k) => trade.stateLastDay[k]), text: `No spraying after ${trade.lastDayText || trade.lastDay} or the R1 stage, whichever comes first${others.length ? ` (${others.join(", ")})` : ""}: check your crop stage` });
    }
  }
  return notes;
}

/** The temperature-humidity index for livestock (NRC 1971; °F and relative humidity). */
function wdThi(tempF, rh) {
  return tempF - (0.55 - 0.0055 * rh) * (tempF - 58);
}

/**
 * Heat and cold stress for livestock over [from, to), from the NWS hour-by-hour grid:
 * { heat: { level, peak, from, to }, cold: { level, low, from, to, wet }, relief, missing }.
 * Levels: "" (none), "alert", "danger", "emergency". Heat goes by the temperature-humidity
 * index; cold by the wind chill, and cold rain with wind (wet animals chill fast) is an alert.
 * `relief`: after the heat peaks, the coolest index in the next 18 hours ({ min, ok }).
 * The spans (from, to) cover the hours at the top level reached.
 */
function wdLivestock(grid, from, to, tz, limits) {
  const t = limits || WD_TRADES.livestock;
  const H = t.heat, C = t.cold;
  const rank = { "": 0, alert: 1, danger: 2, emergency: 3 };
  const heatLevel = (v) => (v >= H.emergency ? "emergency" : v >= H.danger ? "danger" : v >= H.alert ? "alert" : "");
  const coldLevel = (v) => (v <= C.emergency ? "emergency" : v <= C.danger ? "danger" : v <= C.alert ? "alert" : "");
  const out = { heat: { level: "", peak: null, from: null, to: null }, cold: { level: "", low: null, from: null, to: null, wet: null }, relief: null, missing: false, tz };
  const list = [];
  let n = 0;
  for (let ms = Math.floor(from.getTime() / WD_HOUR) * WD_HOUR; ms < to.getTime(); ms += WD_HOUR) {
    n++;
    const h = grid.hours.get(ms);
    if (!h || h.tempF == null) continue;
    const thi = h.rh != null ? wdThi(h.tempF, h.rh) : null;
    const wc = h.chillF != null ? h.chillF : h.tempF;
    list.push({ ms, thi, wc, hl: thi == null ? "" : heatLevel(thi), cl: coldLevel(wc) });
    if (thi != null && (out.heat.peak == null || thi > out.heat.peak)) { out.heat.peak = thi; out.heat.peakAt = ms; }
    if (out.cold.low == null || wc < out.cold.low) out.cold.low = wc;
    const wind = h.windMph || 0, gust = Math.max(h.gustMph || 0, wind);
    if (h.liquid && !h.snowy && (h.pop || 0) >= 50 && h.tempF <= C.wetBelow && (wind >= C.wetWind || gust >= C.wetWind + 5)) {
      const w = out.cold.wet;
      if (!w) out.cold.wet = { from: ms, to: ms + WD_HOUR, temp: h.tempF, gust };
      else { w.to = ms + WD_HOUR; w.temp = Math.min(w.temp, h.tempF); w.gust = Math.max(w.gust, gust); }
    }
  }
  out.missing = !n || list.length < n * 0.75;
  const top = (key) => list.reduce((m, x) => (rank[x[key]] > rank[m] ? x[key] : m), "");
  const span = (key, level) => {
    const at = list.filter((x) => rank[x[key]] >= rank[level]);
    return at.length ? { from: at[0].ms, to: at[at.length - 1].ms + WD_HOUR } : { from: null, to: null };
  };
  out.heat.level = top("hl");
  if (out.heat.level) {
    Object.assign(out.heat, span("hl", out.heat.level));
    // When the heat first reaches the alert level, for "(THI up to 82; 68+ from 10 AM)" (Oct. 9, 2026).
    const firstAlert = list.find((x) => rank[x.hl] >= 1);
    out.heat.start = firstAlert ? firstAlert.ms : null;
    out.heat.alertAt = H.alert;
  }
  out.cold.level = top("cl");
  if (out.cold.level) Object.assign(out.cold, span("cl", out.cold.level));
  else if (out.cold.wet) out.cold.level = "alert";
  if (out.heat.level && out.heat.peakAt != null) {
    let min = null, have = 0;
    for (let k = 1; k <= 18; k++) {
      const h = grid.hours.get(out.heat.peakAt + k * WD_HOUR);
      if (!h || h.tempF == null || h.rh == null) continue;
      have++;
      const v = wdThi(h.tempF, h.rh);
      min = min == null ? v : Math.min(min, v);
    }
    if (have >= 12) out.relief = { min, ok: min < H.relief };
  }
  return out;
}

/* ---------- Finding a job site ---------- */
// Addresses, towns, and ZIP codes are looked up with OpenStreetMap's Nominatim, only when
// someone asks (never as they type), which its usage policy allows. Results are
// \u00A9 OpenStreetMap contributors; the pages that search say so.

const WD_OSM_CREDIT = 'Address search by <a href="https://nominatim.openstreetmap.org/" target="_blank" rel="noopener">Nominatim</a>, &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap contributors</a>';

async function wdFindPlace(q) {
  const s = String(q || "").trim();
  if (s.length < 2) return [];
  const zip = /^\d{5}(?:-\d{4})?$/.test(s);
  const query = zip ? `postalcode=${encodeURIComponent(s.slice(0, 5))}` : `q=${encodeURIComponent(s)}`;
  const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&countrycodes=us&limit=5&addressdetails=1&${query}`;
  const data = await fetchJson(url, { headers: { Accept: "application/json" } }, 12000);
  const seen = new Set();
  return (Array.isArray(data) ? data : []).map((r) => {
    const a = r.address || {};
    const town = a.city || a.town || a.village || a.hamlet || a.township || a.municipality || a.county || "";
    const st = String(a["ISO3166-2-lvl4"] || "").replace(/^US-/, "") || (typeof stateAbbrev === "function" ? stateAbbrev(a.state || "") : a.state || "");
    const street = [a.house_number, a.road].filter(Boolean).join(" ");
    let name = [street, town, st].filter(Boolean).join(", ");
    if (zip && a.postcode) name = `${[town, st].filter(Boolean).join(", ")} ${a.postcode}`.trim();
    if (!name) name = String(r.display_name || "").split(",").slice(0, 3).join(",").trim();
    return { name: name.slice(0, 80), lat: Math.round(Number(r.lat) * 1e4) / 1e4, lon: Math.round(Number(r.lon) * 1e4) / 1e4 };
  }).filter((r) => isFinite(r.lat) && isFinite(r.lon) && r.name && !seen.has(r.name) && seen.add(r.name));
}

const WD_QUICK_PLACES = [
  { name: "La Porte, IN", lat: 41.6081, lon: -86.7189 },
  { name: "Michigan City, IN", lat: 41.7075, lon: -86.8950 },
  { name: "Valparaiso, IN", lat: 41.4731, lon: -87.0611 },
  { name: "South Bend, IN", lat: 41.6764, lon: -86.2520 },
];

/* ---------- Drawing a result (shared by the product page and the dashboard) ---------- */

const WD_CALL_CLASS = { go: "wd-go", delay: "wd-delay", stop: "wd-stop", unknown: "wd-unknown" };

function wdDayTitle(ymd, now, tz) {
  const today = ymdInZone(now || new Date(), tz);
  const rel = ymd === today ? "Today" : ymd === addDaysYmd(today, 1) ? "Tomorrow" : weekdayOfYmd(ymd, "long");
  return `${rel}, ${weekdayOfYmd(ymd, "short")} ${monthDayOfYmd(ymd)}`;
}

/** What the call means for the crew, in one line under the big call (the reasons are listed below it). */
function wdHeadline(r) {
  if (r.over) return "Today's work hours are over. Check tomorrow's call.";
  if (r.call === "unknown") return r.cureGap ? `The National Weather Service forecast doesn't cover all ${(r.tradeObj || {}).cureDays || 3} days hay needs to cure yet, so there's no call.`
    : "The National Weather Service forecast doesn't cover all of these hours yet, so there's no call.";
  const tz = r.tz;
  const cond = r.stats ? wdStatsText(r.stats).replace(/(\d)-(\d)/g, "$1\u2013$2").replace(/(\d)F\b/g, "$1\u00B0F") : "";
  if (r.call === "stop") {
    if (r.restOfDay) return `No workable hours left before ${wdHourWord(wdLocalHour(r.window.to, tz), true)}.`;
    return `No ${r.need}-hour stretch of workable weather between ${wdHourWord(wdLocalHour(r.window.from, tz), true)} and ${wdHourWord(wdLocalHour(r.window.to, tz), true)}.`;
  }
  if (r.call === "delay") return `Start at ${wdTimeText(r.startAt, tz)}. Workable ${wdRangeText(r.startAt, r.best.to, tz)}${cond ? ": " + cond : ""}.`;
  if (r.until) return `${r.restOfDay ? "Work now" : "Start on time"} and wrap by ${wdTimeText(r.until, tz)}. Workable ${wdRangeText(r.window.from, r.until, tz)}${cond ? ": " + cond : ""}.`;
  const heads = r.reasons.filter((x) => x.level === "watch");
  const count = heads.length + (r.notes || []).length;
  const precip = heads.some((x) => WD_PRECIP_TYPES.includes(x.type));
  const pop = r.dayStats && r.dayStats.pop != null ? r.dayStats.pop : 0;
  const dry = precip ? "" : pop < 20 ? "dry" : "mostly dry";
  const lead = r.restOfDay ? "Workable for the rest of the workday" : "Workable all day";
  const body = [dry, cond].filter(Boolean).join(", ");
  const extra = count === 1 ? " One heads-up below." : count > 1 ? " A few heads-ups below." : "";
  return `${lead}${body ? ": " + body : ""}.${extra}`;
}

/** The hour-by-hour strip. */
function wdHourStripHtml(r) {
  const tz = r.tz;
  const cells = r.hours.map((x) => {
    const h = x.h;
    const lvl = x.level;
    const pop = h && h.pop != null ? Math.round(h.pop) : null;
    const gust = h ? Math.round(Math.max(h.gustMph || 0, h.windMph || 0)) : null;
    const temp = h && h.tempF != null ? Math.round(h.tempF) : null;
    const word = lvl === "stop" ? "stop" : lvl === "watch" ? "caution" : lvl === "nodata" ? "no forecast" : "workable";
    const why = x.hits.filter((y) => y.level === lvl).map((y) => y.type === "alert" ? y.event : y.type).filter((v, i, a) => a.indexOf(v) === i).join(", ");
    return `<li class="wd-hr wd-hr-${lvl}">
      <span class="wd-hr-time">${escapeHtml(wdHourWord(wdLocalHour(x.t, tz), true).replace(/^noon$/, "Noon").replace(/^midnight$/, "12 AM").replace(" ", "\u00A0"))}</span>
      <span class="wd-hr-bar" aria-hidden="true"></span>
      <span class="wd-hr-pop">${pop == null ? "&ndash;" : pop + "%"}</span>
      <span class="wd-hr-gust">${gust == null ? "&ndash;" : gust}</span>
      <span class="wd-hr-temp">${temp == null ? "&ndash;" : temp + "&deg;"}</span>
      <span class="visually-hidden">${escapeHtml(word)}${why ? " (" + escapeHtml(why) + ")" : ""}; rain chance ${pop == null ? "unknown" : pop + " percent"}, gusts ${gust == null ? "unknown" : gust + " miles per hour"}, ${temp == null ? "" : temp + " degrees"}</span>
    </li>`;
  }).join("");
  return `<div class="wd-strip-wrap">
    <div class="wd-strip-legend" aria-hidden="true"><span>Hour</span><span></span><span>Rain</span><span>Gust</span><span>Temp</span></div>
    <ol class="wd-strip" aria-label="Hour by hour">${cells}</ol>
  </div>
  <ul class="wd-strip-key" aria-hidden="true"><li><span><i style="background:var(--go)"></i>Workable</span></li><li><span><i style="background:var(--delay)"></i>Heads-up</span></li><li><span><i style="background:var(--stop)"></i>Stop</span></li><li>Gusts in mph</li></ul>`;
}

function wdReasonsHtml(r) {
  const items = r.reasons.map((x) => `<li class="wd-reason wd-reason-${x.level}"><span class="wd-dot" aria-hidden="true"></span><span><span class="visually-hidden">${x.level === "stop" ? "Stops work: " : "Caution: "}</span>${escapeHtml(x.text)}</span></li>`)
    .concat((r.notes || []).map((n) => `<li class="wd-reason wd-reason-watch"><span class="wd-dot" aria-hidden="true"></span><span><span class="visually-hidden">Caution: </span>${escapeHtml(n.text)}</span></li>`));
  if (!items.length) items.push(`<li class="wd-reason wd-reason-ok"><span class="wd-dot" aria-hidden="true"></span><span>Nothing in the forecast crosses your limits.</span></li>`);
  return `<ul class="wd-reasons">${items.join("")}</ul>`;
}

function wdPillHtml(r, big) {
  return `<span class="wd-pill ${WD_CALL_CLASS[r.call] || "wd-unknown"}${big ? " wd-pill-big" : ""}">${escapeHtml(r.label)}</span>`;
}

function wdSmsBubbleHtml(text) {
  return `<div class="wd-sms"><div class="wd-sms-from">Hard Hat Weather</div><p class="wd-sms-bubble">${escapeHtml(text).replace(/\n/g, "<br>")}</p></div>`;
}

function wdSourceLine(point, r) {
  const upd = point.grid.updated ? `${fmtInZone(point.grid.updated, point.tz, { weekday: "short", hour: "numeric", minute: "2-digit" })} ${zoneAbbrev(point.grid.updated, point.tz)}` : "";
  return `From the National Weather Service forecast${upd ? ` updated ${escapeHtml(upd)}` : ""}${point.office ? ` (NWS ${escapeHtml(point.office)} office)` : ""}. <a href="${nwsPointPageUrl(point.lat, point.lon)}" target="_blank" rel="noopener">See it at weather.gov<span class="visually-hidden"> (opens in a new tab)</span> &#8599;</a>`;
}

/** Full result card body (used by the live check). */
function wdResultHtml(point, r, siteName, now) {
  const alertsNote = point.alerts === null ? `<p class="wd-note">We couldn't check NWS alerts just now, so this call is from the forecast only. <a href="${nwsPointPageUrl(point.lat, point.lon)}" target="_blank" rel="noopener">Check weather.gov<span class="visually-hidden"> (opens in a new tab)</span></a>.</p>` : "";
  const hours = `Work hours ${escapeHtml(wdHourWord(r.start, true))}&ndash;${escapeHtml(wdHourWord(r.end, true))}`;
  return `<div class="wd-result-head">
      <div>
        <div class="wd-result-day">${escapeHtml(wdDayTitle(r.ymd, now, r.tz))}</div>
        <div class="wd-result-meta">${escapeHtml(r.trade)} &middot; ${hours}</div>
      </div>
      ${wdPillHtml(r, true)}
    </div>
    <p class="wd-headline">${escapeHtml(wdHeadline(r))}</p>
    ${alertsNote}
    ${r.over || r.call === "unknown" ? "" : wdReasonsHtml(r)}
    ${r.over || r.call === "unknown" ? "" : wdHourStripHtml(r)}
    ${r.over || r.call === "unknown" ? "" : `<div class="wd-result-sms"><div class="wd-label">The text your crew gets</div>${wdSmsBubbleHtml(wdMorningSms([{ name: siteName, result: r }], r.ymd))}</div>`}
    <p class="wd-source">${wdSourceLine(point, r)}</p>`;
}
