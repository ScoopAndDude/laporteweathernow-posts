// Free watch & warning alerts for the counties people choose, sent as phone/browser
// notifications through OneSignal. OneSignal's code loads only after someone adds a county
// (or already has alerts on), so everyone else's visit never touches it. Any element with
// data-alerts-open opens the panel. Our sender (a Google Apps Script) checks the National
// Weather Service every 5 minutes and notifies each county's followers by the tag c<SAME code>.
(function () {
  const APP_ID = "e3d08aa5-308d-4d97-90c3-ca1268377da2";
  // The alert sender's web address; it only ever receives a county code, never anyone's location.
  const SENDER_URL = "https://script.google.com/macros/s/AKfycbzpr7vLkvMUT_PqKBrr_fwXQkiXqbicN2Qlimz7-IbqaMKQuw01QkBFkVqe_8Rx6oTW/exec";
  const MAX = 5;   // OneSignal's free plan allows 6 tags per person: 5 counties, plus one for the daily verse (faith.js)
  const KEY = "lpwn_alert_counties";
  // State FIPS numbers, for the county's NOAA code (0 + state + county), which NWS alerts carry.
  const FIPS = { AL: "01", AK: "02", AZ: "04", AR: "05", CA: "06", CO: "08", CT: "09", DE: "10", DC: "11", FL: "12", GA: "13", HI: "15", ID: "16", IL: "17", IN: "18", IA: "19", KS: "20", KY: "21", LA: "22", ME: "23", MD: "24", MA: "25", MI: "26", MN: "27", MS: "28", MO: "29", MT: "30", NE: "31", NV: "32", NH: "33", NJ: "34", NM: "35", NY: "36", NC: "37", ND: "38", OH: "39", OK: "40", OR: "41", PA: "42", RI: "44", SC: "45", SD: "46", TN: "47", TX: "48", UT: "49", VT: "50", VA: "51", WA: "53", WV: "54", WI: "55", WY: "56", PR: "72" };

  const saved = () => { try { const v = JSON.parse(localStorage.getItem(KEY) || "[]"); return Array.isArray(v) ? v : []; } catch (e) { return []; } };
  const save = (list) => { try { if (list.length) localStorage.setItem(KEY, JSON.stringify(list)); else localStorage.removeItem(KEY); } catch (e) { /* private mode */ } };
  const esc = (s) => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const isApp = window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  const supported = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;

  let sdk = null;
  function loadSdk() {
    if (sdk) return sdk;
    sdk = new Promise((resolve, reject) => {
      window.OneSignalDeferred = window.OneSignalDeferred || [];
      window.OneSignalDeferred.push(async (OneSignal) => {
        try {
          // One service worker per site: sw.js keeps the offline Emergency page and also imports OneSignal's.
          await OneSignal.init({ appId: APP_ID, serviceWorkerPath: "sw.js", serviceWorkerParam: { scope: "/" } });
          resolve(OneSignal);
        } catch (e) { reject(e); }
      });
      const s = document.createElement("script");
      s.src = "https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js";
      s.defer = true;
      s.onerror = () => reject(new Error("The alert service didn't load."));
      document.head.appendChild(s);
    });
    sdk.catch(() => { sdk = null; });
    return sdk;
  }

  async function getJson(url) {
    const res = await fetch(url, { headers: { Accept: "application/geo+json" } });
    if (!res.ok) throw new Error(String(res.status));
    return res.json();
  }
  // "La Porte" -> "La Porte County, IN"; parishes in Louisiana; cities and boroughs keep their names.
  function countyLabel(name, st) {
    const base = String(name).replace(/\s*\(.*\)$/, "");
    const hasKind = /(County|Parish|Borough|City|Census Area|Municipality|Region)$/i.test(base) || /^City of /i.test(base);
    const label = hasKind || ["AK", "DC", "PR"].includes(st)
      ? name
      : String(name).replace(/^(.*?)(\s*\(.*\))?$/, (m, a, b) => `${a} ${st === "LA" ? "Parish" : "County"}${b || ""}`);
    return st === "DC" ? label : `${label}, ${st}`;
  }
  // A town's county, from the NWS: { code: "018091", zone: "INC091", label: "La Porte County, IN" }.
  async function countyFor(lat, lon) {
    const pt = await getJson(`https://api.weather.gov/points/${Number(lat).toFixed(4)},${Number(lon).toFixed(4)}`);
    const zone = (String(pt.properties.county || "").match(/([A-Z]{2})C(\d{3})$/) || []);
    if (!zone[0] || !FIPS[zone[1]]) throw new Error("no county");
    let name = zone[0];
    try { name = (await getJson(pt.properties.county)).properties.name || name; } catch (e) { /* keep the code */ }
    return { code: `0${FIPS[zone[1]]}${zone[2]}`, zone: zone[0], label: countyLabel(name, zone[1]) };
  }
  // Tell our sender a county has followers. no-cors: the reply doesn't matter, and nothing personal is sent.
  function register(c) {
    if (!/^https:\/\/script\.google\.com\//.test(SENDER_URL)) return;
    fetch(SENDER_URL, { method: "POST", mode: "no-cors", headers: { "Content-Type": "text/plain" },
      body: JSON.stringify({ code: c.code, zone: c.zone, label: c.label }) }).catch(() => {});
  }

  function buttonLabel(list) {
    if (!list.length) return "&#128276; Get free watch &amp; warning alerts";
    const first = esc(list[0].label.replace(/, [A-Z]{2}$/, ""));
    return `&#128276; Alerts on: ${first}${list.length > 1 ? ` + ${list.length - 1} more` : ""}`;
  }
  function refreshButtons() {
    document.querySelectorAll("[data-alerts-open]").forEach((b) => { b.innerHTML = buttonLabel(saved()); });
  }

  function dialog() {
    let d = document.getElementById("alertsDialog");
    if (d) return d;
    d = document.createElement("dialog");
    d.id = "alertsDialog";
    d.className = "install-dialog alerts-dialog";
    d.setAttribute("aria-labelledby", "alertsDialogTitle");
    const blocked = !supported || (isIOS && !isApp);
    const note = isIOS && !isApp
      ? `<p class="alerts-note"><strong>On iPhone or iPad:</strong> alerts only work from the Home Screen app. Tap <strong>Download App</strong> at the top of the page, add it to your Home Screen, open it from there, and turn alerts on.</p>`
      : !supported ? `<p class="alerts-note">This browser can't show notifications. Try Chrome, Edge, Firefox or Safari.</p>` : "";
    d.innerHTML = `
      <h2 id="alertsDialogTitle">&#128276; Free watch &amp; warning alerts</h2>
      <p>Get a notification on this phone or computer when the National Weather Service issues a watch or warning for your county, anywhere in the U.S. Free, with no account and no email address. Follow up to ${MAX} counties: home, work, family.</p>
      ${note}
      <fieldset class="alerts-areas"><legend>Your counties</legend><div class="alerts-list"></div></fieldset>
      <div class="alerts-add"${blocked ? " hidden" : ""}>
        <button type="button" class="btn btn-amber alerts-here" hidden></button>
        <div class="location-search alerts-search">
          <label for="alertsTown">Add another county: type a town</label>
          <div style="position:relative;">
            <input type="text" id="alertsTown" placeholder="e.g. Canton, GA" autocomplete="off" />
            <div id="alertsTownResults" class="search-results"></div>
          </div>
        </div>
      </div>
      <div class="alerts-actions"><button type="button" class="btn btn-outline" data-alerts-off hidden>Turn off all alerts</button></div>
      <p class="alerts-status" role="status" aria-live="polite"></p>
      <p class="alerts-fine">Alerts usually arrive within about 5 minutes of the NWS. Your phone's own emergency alerts are faster, so keep those on too. Notifications come through OneSignal; see our <a href="/privacy#alerts">privacy page</a>.</p>
      <button type="button" class="btn btn-outline install-dialog-close">Close</button>`;
    document.body.appendChild(d);
    const status = d.querySelector(".alerts-status");
    const listEl = d.querySelector(".alerts-list");
    const hereBtn = d.querySelector(".alerts-here");
    const offBtn = d.querySelector("[data-alerts-off]");
    const say = (msg) => { status.textContent = msg; };
    let busy = false;

    const render = () => {
      const list = saved();
      listEl.innerHTML = list.length
        ? list.map((c) => `<div class="alerts-county"><span>${esc(c.label)}</span><button type="button" class="btn btn-plain" data-remove="${esc(c.code)}">Remove</button></div>`).join("")
        : `<p class="alerts-empty">None yet. Add your county below.</p>`;
      offBtn.hidden = !list.length;
      const full = list.length >= MAX;
      d.querySelector(".alerts-search").hidden = full;
      if (full) say(`You're following ${MAX} counties, the most we can send to one device. Remove one to add another.`);
    };

    // Offer the town this visitor already picked on the site, if its county isn't followed yet.
    const offerHere = async () => {
      hereBtn.hidden = true;
      const loc = typeof getCurrentLocation === "function" ? getCurrentLocation() : null;
      if (!loc || blocked || saved().length >= MAX) return;
      try {
        const c = await countyFor(loc.lat, loc.lon);
        if (saved().some((x) => x.code === c.code)) return;
        hereBtn.textContent = `Add ${c.label}`;
        hereBtn.onclick = () => add(c);
        hereBtn.hidden = false;
      } catch (e) { /* no county here (outside the U.S. or over water); the search still works */ }
    };

    async function add(c) {
      if (busy) return;
      const list = saved();
      if (list.some((x) => x.code === c.code)) { say(`You're already following ${c.label}.`); return; }
      if (list.length >= MAX) { render(); return; }
      busy = true;
      say("Asking your browser for permission…");
      try {
        const OneSignal = await loadSdk();
        if (!OneSignal.Notifications.permission) await OneSignal.Notifications.requestPermission();
        if (!OneSignal.Notifications.permission) {
          say("Notifications are blocked for this site. Allow them in your browser or phone settings for laporteweathernow.com, then try again.");
          return;
        }
        await OneSignal.User.PushSubscription.optIn();
        await OneSignal.User.addTag(`c${c.code}`, "1");
        save(list.concat([{ code: c.code, zone: c.zone, label: c.label }]));
        register(c);
        refreshButtons(); render(); offerHere();
        say(`Alerts are on for ${c.label}.`);
        if (typeof lpwnTrack === "function") lpwnTrack("alerts-on", c.zone);
      } catch (e) {
        say("That didn't work. Check your connection and try again.");
      } finally { busy = false; }
    }

    async function remove(code) {
      if (busy) return;
      busy = true;
      const list = saved();
      const c = list.find((x) => x.code === code);
      try {
        const OneSignal = await loadSdk();
        await OneSignal.User.removeTag(`c${code}`);
        const rest = list.filter((x) => x.code !== code);
        if (!rest.length) await OneSignal.User.PushSubscription.optOut();
        save(rest);
        refreshButtons(); render(); offerHere();
        say(`Removed ${c ? c.label : "that county"}.`);
      } catch (e) {
        say("That didn't work. Check your connection and try again.");
      } finally { busy = false; }
    }

    listEl.addEventListener("click", (e) => { const b = e.target.closest("[data-remove]"); if (b) remove(b.dataset.remove); });
    offBtn.addEventListener("click", async () => {
      if (busy) return;
      busy = true;
      say("Turning alerts off…");
      try {
        const OneSignal = await loadSdk();
        await OneSignal.User.removeTags(saved().map((c) => `c${c.code}`));
        await OneSignal.User.PushSubscription.optOut();
        save([]);
        refreshButtons(); render(); offerHere();
        say("Alerts are off. You won't get any more notifications from us.");
        if (typeof lpwnTrack === "function") lpwnTrack("alerts-off", location.pathname);
      } catch (e) {
        say("That didn't work. Check your connection and try again.");
      } finally { busy = false; }
    });

    if (typeof wireLocationSearch === "function") {
      wireLocationSearch(d.querySelector("#alertsTown"), d.querySelector("#alertsTownResults"), async (picked) => {
        d.querySelector("#alertsTown").value = "";
        say(`Finding the county for ${picked.name}…`);
        try { await add(await countyFor(picked.lat, picked.lon)); }
        catch (e) { say(`We couldn't find a U.S. county for ${picked.name}. Try a nearby town.`); }
      });
    } else {
      d.querySelector(".alerts-search").hidden = true;
    }

    d.querySelector(".install-dialog-close").addEventListener("click", () => d.close());
    d.addEventListener("click", (e) => { if (e.target === d) d.close(); });
    d.addEventListener("alerts:open", () => { say(""); render(); offerHere(); });
    return d;
  }

  function open() {
    const d = dialog();
    d.dispatchEvent(new Event("alerts:open"));
    if (typeof d.showModal === "function") d.showModal(); else d.setAttribute("open", "");
  }

  function wire() {
    document.querySelectorAll("[data-alerts-open]").forEach((b) => b.addEventListener("click", open));
    refreshButtons();
    // Already signed up: load OneSignal so it can keep this device's subscription current.
    if (saved().length && supported) setTimeout(() => { loadSdk().catch(() => {}); }, 3000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", wire); else wire();
})();
