if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}

let deferredInstallPrompt = null;

function isRunningAsApp() {
  return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
}

function isIOS() {
  return /iphone|ipad|ipod/i.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
}

function showInstallHelp() {
  let dialog = document.getElementById("installHelp");
  if (!dialog) {
    const iosSteps = `
      <h3>iPhone / iPad</h3>
      <ol>
        <li>Open this site in <strong>Safari</strong></li>
        <li>Tap the <strong>Share</strong> button (square with an up arrow)</li>
        <li>Tap <strong>Add to Home Screen</strong>, then <strong>Add</strong></li>
      </ol>`;
    const otherSteps = `
      <h3>Android &amp; computers (Chrome or Edge)</h3>
      <ol>
        <li>Open the browser menu (<strong>&#8942;</strong>)</li>
        <li>Tap <strong>Install app</strong> or <strong>Add to Home screen</strong></li>
      </ol>`;
    dialog = document.createElement("dialog");
    dialog.id = "installHelp";
    dialog.className = "install-dialog";
    dialog.setAttribute("aria-labelledby", "installHelpTitle");
    dialog.innerHTML = `
      <h2 id="installHelpTitle">&#128242; Get the La Porte Weather Now app</h2>
      <p>Free, no app store needed. It opens full-screen from your home screen and always shows the latest forecast.</p>
      ${isIOS() ? iosSteps + otherSteps : otherSteps + iosSteps}
      <button type="button" class="btn btn-amber install-dialog-close">Got it</button>`;
    document.body.appendChild(dialog);
    dialog.querySelector(".install-dialog-close").addEventListener("click", () => dialog.close());
    dialog.addEventListener("click", (e) => { if (e.target === dialog) dialog.close(); });
  }
  if (typeof dialog.showModal === "function") dialog.showModal();
  else dialog.setAttribute("open", "");
}

const installBtn = document.getElementById("installAppBtn");

if (installBtn) {
  if (isRunningAsApp()) {
    installBtn.remove();
  } else {
    installBtn.addEventListener("click", async () => {
      if (deferredInstallPrompt) {
        deferredInstallPrompt.prompt();
        await deferredInstallPrompt.userChoice;
        deferredInstallPrompt = null;
      } else {
        showInstallHelp();
      }
    });
  }
}

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
});

window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  if (installBtn) installBtn.remove();
});

// Back-to-top button: shows up once the visitor is well down a long page.
(function () {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "to-top";
  btn.setAttribute("aria-label", "Back to the top of the page");
  btn.innerHTML = '<span class="arrow" aria-hidden="true">&#8593;</span>Top';
  btn.tabIndex = -1;
  btn.addEventListener("click", () => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" });
    const skip = document.querySelector(".brand, h1");
    if (skip && typeof skip.focus === "function") { if (!skip.hasAttribute("tabindex") && skip.tagName === "H1") skip.setAttribute("tabindex", "-1"); skip.focus({ preventScroll: true }); }
  });
  const place = () => { if (!btn.isConnected && document.body) document.body.appendChild(btn); };
  let shown = false;
  const update = () => {
    const show = window.scrollY > window.innerHeight * 1.2;
    if (show !== shown) {
      shown = show;
      btn.classList.toggle("show", show);
      btn.tabIndex = show ? 0 : -1;
    }
  };
  if (document.body) place(); else document.addEventListener("DOMContentLoaded", place);
  window.addEventListener("scroll", update, { passive: true });
  window.addEventListener("load", update);
})();
