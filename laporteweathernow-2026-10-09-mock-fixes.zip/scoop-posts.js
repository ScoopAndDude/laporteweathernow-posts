/*
  THE DAILY SCOOP: BACKUP COPY

  Posts now live on GitHub, so publishing a Scoop never needs a Netlify publish
  (each Netlify publish costs credits):
    https://github.com/ScoopAndDude/laporteweathernow-posts/blob/main/scoop-posts.json

  To write, publish, or correct a post, open laporteweathernow.com/scoop-draft.
  It drafts the post from the National Weather Service, builds the updated posts
  file, and links you to the GitHub page where you paste it in.

  This file is only a fallback: the site shows these posts if GitHub can't be
  reached and the visitor's browser has no saved copy. It doesn't need to be kept
  up to date. When you do publish the site to Netlify for some other reason, you
  can refresh it by copying the "posts" list from the GitHub file into it.

  Post format (the draft helper writes this for you):
    type        "daily" or "weekly"
    date        the La Porte date the post is for (weekly: the Monday the week starts)
    posted      when the post went live. Never changed after that.
    updated     when it last changed (a new correction counts)
    title, summary, body (a list of paragraphs), sources (label + url), author
    forecasts   daily posts only: [{ date, high, low, rain }] for the next days.
                high = that day's high, low = that morning's low (°F; a range like
                [47, 49] is scored from its middle), rain = chance of rain or snow (%).
                Never changed after posting. The Track Record checks them.
    corrections [{ date, text }] dated notes when something turned out wrong.
*/
window.SCOOP_POSTS = [
  {
    type: "daily",
    date: "2026-09-26",
    posted: "2026-09-26T05:50:00-05:00",
    updated: "2026-09-26T05:50:00-05:00",
    title: "Sunny and dry through Tuesday — rain chances return midweek and may linger",
    summary: "Sunny today with a high near 69 and a chilly night; dry through Tuesday, then showers and storms become possible Wednesday into next weekend.",
    body: [
      "Today (Saturday): sunny, with a high near 69 and a light east wind around 5 mph. Tonight: mostly clear and chilly, with a low around 45. If you're camping or out early Sunday, bring a warm layer.",
      "Sunday: mostly sunny, high near 68. Sunday night: partly cloudy, low around 49. Monday: sunny, high near 71. The dry stretch holds through Tuesday, with a high near 73.",
      "What changed since yesterday's Scoop: NWS has slowed the midweek rain and spread it out. Wednesday is now about a 50% chance of showers and thunderstorms (yesterday it was about 60%), and the best odds, near 60%, have moved to Wednesday night and Thursday. Showers stay in the forecast for Friday. NWS Northern Indiana forecasters say a front could stall over the area and keep showers going into next weekend, and that it's still uncertain how much heavy rain or thunder we'll get. If any day brings stronger storms, their early pick is next Saturday. That's a week out, so expect changes.",
      "Right now there are no watches, warnings, or advisories for La Porte County, and the Storm Prediction Center has no thunderstorm risk outlined for La Porte today through Monday. The Flood Warning we mentioned yesterday for the St. Marys River near Decatur is no longer in effect."
    ],
    sources: [
      { label: "NWS forecast for La Porte, IN", url: "https://forecast.weather.gov/MapClick.php?lat=41.6081&lon=-86.7189" },
      { label: "NWS Northern Indiana forecast discussion (we used the 6:07 AM EDT Sept. 26 issue; the link opens the newest one)", url: "https://forecast.weather.gov/product.php?site=IWX&issuedby=IWX&product=AFD" },
      { label: "Storm Prediction Center convective outlooks", url: "https://www.spc.noaa.gov/products/outlook/" },
      { label: "NWS Northern Indiana current hazards", url: "https://www.weather.gov/iwx/" }
    ],
    author: "La Porte Weather Now",
    forecasts: [
      { date: "2026-09-27", high: 68, low: 45, rain: 0 },
      { date: "2026-09-28", high: 71, low: 49, rain: 0 }
    ],
    corrections: []
  },
  {
    type: "daily",
    date: "2026-09-25",
    updated: "2026-09-25T19:45:00-05:00",
    title: "A dry, crisp weekend — next storm chance arrives Wednesday",
    summary: "Sunny, cool weekend with highs near 69; a cold front brings showers and storms midweek.",
    body: [
      "Quiet weather rules the weekend in La Porte. High pressure keeps skies mostly sunny with no rain in the forecast. Expect lows in the upper 40s tonight and Saturday night, highs near 69 on Saturday and Sunday, and low 70s on Monday and Tuesday.",
      "The next change arrives midweek. A cold front brings a chance of showers late Tuesday night, then showers and thunderstorms are likely on Wednesday, with about a 60% chance of rain. NWS Northern Indiana forecasters say an isolated strong storm is possible, depending on when the front arrives. If you're traveling or camping Wednesday, that's the day to keep an eye on.",
      "Right now there are no watches, warnings, or advisories for La Porte County, and the Storm Prediction Center has no thunderstorm risk outlined for our area through Sunday.",
      "Travel note: this is great camping weather, but mornings in the 40s call for a warm layer. If you're headed to northeast Indiana, NWS has a Flood Warning out for the St. Marys River near Decatur (Adams and Allen counties) through Saturday evening."
    ],
    sources: [
      { label: "NWS forecast for La Porte, IN", url: "https://forecast.weather.gov/MapClick.php?lat=41.6081&lon=-86.7189" },
      { label: "NWS Northern Indiana forecast discussion (we used the 7:08 PM EDT Sept. 25 issue; the link opens the newest one)", url: "https://forecast.weather.gov/product.php?site=IWX&issuedby=IWX&product=AFD" },
      { label: "Storm Prediction Center convective outlooks", url: "https://www.spc.noaa.gov/products/outlook/" },
      { label: "NWS Northern Indiana current hazards", url: "https://www.weather.gov/iwx/" }
    ],
    author: "La Porte Weather Now",
    // No forecast on record for this first post: it goes live with this update,
    // after some of the days it covers had already begun. The track record starts
    // with the first Scoop posted after publishing.
    corrections: []
  },
  {
    type: "weekly",
    date: "2026-09-28",
    posted: "2026-09-26T05:50:00-05:00",
    updated: "2026-09-26T05:50:00-05:00",
    title: "Week ahead: dry and mild start, then a wetter, unsettled second half",
    summary: "Dry through Tuesday with highs in the low 70s; showers and storms become possible Wednesday and may linger into next weekend.",
    body: [
      "Early week (Mon–Tue): quiet. NWS expects sunshine and dry weather in La Porte through Tuesday, with highs near 71 on Monday and 73 on Tuesday and cool nights in the upper 40s. It's a good window for outdoor work and travel.",
      "Midweek (Wed–Thu): rain chances return. Showers and thunderstorms become possible late Tuesday night, with about a 50% chance on Wednesday and the best odds, near 60%, Wednesday night and Thursday. NWS Northern Indiana forecasters say it's still uncertain how much heavy rain or thunder we'll get. If you're traveling or camping midweek, plan around Wednesday night and Thursday.",
      "Late week into next weekend: showers may hang around. Forecasters say a front could stall over the area from Thursday into the weekend and keep showers going (Friday is about a 45% chance). If any day brings stronger thunderstorms, their early pick is Saturday, Oct. 3, which is still a week out.",
      "Across the Midwest: NOAA's Climate Prediction Center, in its outlook for Oct. 1–5, favors warmer-than-normal temperatures for most of the eastern U.S. and leans wetter than normal for most of the country east of the Rockies, especially the Southern Plains and the Lower Mississippi, Tennessee, and Ohio Valleys. For Oct. 3–9, it favors near-normal temperatures from the Southern Plains northeast into the Great Lakes, and wetter than normal for the central and eastern U.S.",
      "What it means for you: enjoy the quiet start, plan an indoor backup for Wednesday night and Thursday, and run your route through the Trip Planner before any travel late in the week. These outlooks are probabilities, not guarantees, so check back as the week unfolds."
    ],
    sources: [
      { label: "NWS forecast for La Porte, IN", url: "https://forecast.weather.gov/MapClick.php?lat=41.6081&lon=-86.7189" },
      { label: "NWS Northern Indiana forecast discussion (we used the 6:07 AM EDT Sept. 26 issue; the link opens the newest one)", url: "https://forecast.weather.gov/product.php?site=IWX&issuedby=IWX&product=AFD" },
      { label: "NOAA CPC 6–10 and 8–14 day outlook discussion (we used the Sept. 25, 2026 issue; the link opens the newest one)", url: "https://www.cpc.ncep.noaa.gov/products/predictions/610day/fxus06.html" },
      { label: "NOAA CPC outlook maps", url: "https://www.cpc.ncep.noaa.gov/products/predictions/610day/" }
    ],
    author: "La Porte Weather Now"
  }
];
