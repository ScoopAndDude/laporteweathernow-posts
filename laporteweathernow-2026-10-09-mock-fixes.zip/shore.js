/* ---------- The Shore Call (Oct. 6, 2026) ----------
   La Porte Weather Now's morning call for the La Porte County shore: swim, piers, small boats and, in
   winter, the lake-effect snow band. The "Shore Call" job in the posts repository (scripts/shore_call.py)
   makes it at about 5:30 a.m. by fixed rules from National Weather Service forecasts and grades it the
   next morning against the Michigan City buoy; this shows the call (#scCard on /lake-michigan) and the
   record (#scRecord there and on /track-record). The call is ours, not a warning, so when the Weather
   Service has put out a shore or lake alert since the call was made, the card says so first.
   Needs timeutil.js. */
(function () {
  const TZ = "America/Chicago";
  const URLS = ["https://scoopanddude.github.io/laporteweathernow-posts/shore.json",
                "https://raw.githubusercontent.com/ScoopAndDude/laporteweathernow-posts/main/shore.json"];
  const HISTORY = "https://github.com/ScoopAndDude/laporteweathernow-posts/commits/main/shore.json";
  const $ = (id) => document.getElementById(id);
  const TONE = { OK: "go", GO: "go", CAUTION: "caution", "STAY OFF": "stay", "STAY OUT": "stay", "STAY IN": "stay" };
  const TAG = { hit: ["hit", "Held up"], close: ["close", "Partly"], miss: ["miss", "Missed"] };
  const SHORE = /Beach Hazards|Rip Current|High Surf|Lakeshore Flood/i;
  const MARINE = /Small Craft|Gale|^Storm (Warning|Watch)|Hurricane Force|Special Marine|Freezing Spray|Dense Fog/i;
  const mph = (kt) => Math.round(Number(kt) * 1.15078);
  const withMph = (s) => String(s || "")
    .replace(/(\d+) to (\d+) knots/g, (m, a, b) => `${a} to ${b} knots (${mph(a)} to ${mph(b)} mph)`)
    .replace(/(\d+) knots(?! \()/g, (m, a) => `${a} knots (${mph(a)} mph)`);
  const today = () => ymdInZone(new Date(), TZ);
  const clock = (iso) => `${fmtClock(iso, TZ)}`;
  const dayName = (ymd) => `${weekdayOfYmd(ymd)}, ${monthDayOfYmd(ymd)}`;

  async function load() {
    const bust = Math.floor(Date.now() / 300000);
    for (const u of URLS) {
      try {
        const r = await fetch(`${u}?t=${bust}`, { cache: "no-store" });
        if (r.ok) return await r.json();
      } catch (e) { /* try the other copy */ }
    }
    throw new Error("The Shore Call file didn't load.");
  }

  /* ----- today's call ----- */
  function tile(label, part, extra) {
    const call = part && part.call;
    return `<div class="sc-tile ${TONE[call] || "none"}"><div class="sc-label">${label}</div>` +
      `<div class="sc-verdict">${call ? escapeHtml(call) : "No call"}</div>` +
      (extra ? `<div class="sc-extra">${extra}</div>` : "") +
      `<p class="sc-why">${escapeHtml(withMph(part && part.why))}</p></div>`;
  }
  function hoursBar(hours) {
    if (!hours || hours.filter((h) => h.status).length < 8) return "";
    const lab = (h) => (h === 12 ? "noon" : `${h % 12 || 12} ${h < 12 ? "a.m." : "p.m."}`);
    const word = { go: "GO", caution: "caution", stay: "stay in" };
    const cells = hours.map((h) => {
      const bits = [h.waveFt !== null && h.waveFt !== undefined ? `waves ${Math.round(h.waveFt)} ft` : "", h.windKt !== null && h.windKt !== undefined ? `wind ${h.windKt} kt` : ""].filter(Boolean).join(", ");
      return `<span class="${h.status || "none"}" title="${escapeHtml(`${lab(h.hour)}: ${word[h.status] || "no forecast"}${bits ? ` (${bits})` : ""}`)}"></span>`;
    }).join("");
    const marks = hours.map((h) => `<span>${[6, 9, 12, 15, 18].indexOf(h.hour) >= 0 ? (h.hour === 12 ? "noon" : `${h.hour % 12 || 12}${h.hour < 12 ? "a" : "p"}`) : ""}</span>`).join("");
    const summary = hours.map((h) => `${lab(h.hour)} ${word[h.status] || "no forecast"}`).join(", ");
    return `<div class="sc-hours-wrap"><div class="sc-label">Small boats, hour by hour</div>` +
      `<div class="sc-hours" role="img" aria-label="${escapeHtml(summary)}">${cells}</div><div class="sc-hours-lab" aria-hidden="true">${marks}</div>` +
      `<div class="sc-legend" aria-hidden="true"><span class="go"></span>GO <span class="caution"></span>Caution <span class="stay"></span>Stay in</div></div>`;
  }
  function bandBlock(b) {
    if (!b) return "";
    const towns = (b.towns || []).slice().sort((x, y) => y.inches - x.inches);
    const inBand = (b.districts || []).filter((d) => d.inBand).map((d) => d.district);
    return `<div class="sc-band"><div class="sc-label">Snow, 6 a.m. today to 6 a.m. tomorrow &middot; NWS forecast grid</div>` +
      `<ul class="sc-towns">${towns.map((t) => `<li class="${escapeHtml(t.group)}"><span>${escapeHtml(t.town)}</span><b>${escapeHtml(t.text)}</b></li>`).join("")}</ul>` +
      (inBand.length ? `<p><strong>School districts in the band:</strong> ${escapeHtml(inBand.join("; "))}. Only your school decides on delays and closings.</p>` : "") +
      ((b.roads || []).length ? `<p><strong>Main roads in the band:</strong> ${escapeHtml(b.roads.join(", "))}. Check <a href="https://511in.org/" target="_blank" rel="noopener">INDOT&rsquo;s road conditions &#8599;</a> before you go.</p>` : "") +
      `</div>`;
  }
  function boatsExtra(b) {
    if (!b || b.call !== "GO" || !b.windowText) return "";
    const after = b.after === "stay" ? ", then stay in" : b.after === "caution" ? ", then use caution" : "";
    return `Best hours: ${escapeHtml(b.windowText)}${after}`;
  }
  function alertsList(c) {
    if (!c.alerts || !c.alerts.length) return `<p class="sc-alerts none">No beach, lake or winter alerts from the Weather Service when we made the call.</p>`;
    return `<div class="sc-alerts"><div class="sc-label">Weather Service alerts when we made the call</div><ul>` +
      c.alerts.map((a) => `<li><strong>${escapeHtml(a.event)}</strong>${a.when ? ` ${escapeHtml(a.when)}` : ""}${a.zones && a.zones.length ? ` &middot; ${escapeHtml(a.zones.join("; "))}` : ""}</li>`).join("") + `</ul></div>`;
  }
  function madeLine(c) {
    const lake = c.nws && c.nws.lake;
    const from = lake && lake.issued ? ` from the Weather Service&rsquo;s lake forecast issued ${escapeHtml(clock(lake.issued))}` : "";
    const beach = c.nws && c.nws.beach && c.nws.beach.issued ? ` and beach forecast issued ${escapeHtml(clock(c.nws.beach.issued))}` : "";
    const late = c.counts === false ? " Made late, so it isn&rsquo;t scored." : "";
    return `Made at ${escapeHtml(clock(c.made))}${from}${beach}.${late} Saved once and never changed: <a href="${HISTORY}" target="_blank" rel="noopener">every call on GitHub &#8599;</a>`;
  }
  async function sinceCall(c) {
    // Shore and lake alerts the Weather Service has out now that weren't out when the call was made.
    try {
      const r = await fetch("https://api.weather.gov/alerts/active?zone=INZ103,LMZ046,LMZ043,LMZ745", { headers: { Accept: "application/geo+json" } });
      if (!r.ok) return;
      const d = await r.json();
      const had = new Set((c.alerts || []).map((a) => a.event));
      const fresh = [];
      (d.features || []).forEach((f) => {
        const p = f.properties || {};
        const ugc = (p.geocode && p.geocode.UGC) || [];
        const lake = ugc.some((z) => /^LMZ/.test(z));
        if (p.messageType === "Cancel" || had.has(p.event) || fresh.indexOf(p.event) >= 0) return;
        if (SHORE.test(p.event) || (lake && MARINE.test(p.event))) fresh.push(p.event);
      });
      if (!fresh.length) return;
      const box = $("scUpdate");
      box.innerHTML = `<strong>Update:</strong> since this call, the Weather Service has put out a ${escapeHtml(fresh.join(" and a "))}. Follow the alert; it comes first. <a href="#lake">See it below &darr;</a>`;
      box.hidden = false;
    } catch (e) { /* the live alerts below still load on their own */ }
  }
  function showCall(data) {
    const card = $("scCard");
    if (!card) return;
    const c = (data.calls || [])[0];
    if (!c || c.date !== today()) {
      card.innerHTML = `<p class="sc-head">Today&rsquo;s call isn&rsquo;t in yet.</p><p class="sc-why">We make it at about 5:30 each morning, after the Weather Service&rsquo;s early lake forecast. Until it&rsquo;s in, go by the Weather Service&rsquo;s forecasts and alerts just below.</p>`;
      return;
    }
    const water = c.forecast && c.forecast.waterF ? `<span class="water-temp">&#127777;&#65039; Water at Michigan City: ${escapeHtml(c.forecast.waterF)}&deg;F</span>` : "";
    card.className = "sc-card " + (["swim", "piers", "boats"].some((k) => TONE[(c[k] || {}).call] === "stay") ? "stay" : ["swim", "piers", "boats"].some((k) => TONE[(c[k] || {}).call] === "caution") ? "caution" : "go");
    card.innerHTML =
      `<div class="sc-update" id="scUpdate" hidden></div>` +
      `<div class="sc-top"><div class="sc-date">${escapeHtml(longDateOfYmd(c.date))}</div>${water}</div>` +
      `<p class="sc-head">${escapeHtml(c.headline)}</p>` +
      bandBlock(c.band) +
      `<div class="sc-tiles">` +
      (c.swim && c.swim.call ? tile("Swim", c.swim) : "") + tile("Piers &amp; breakwalls", c.piers) + tile("Small boats", c.boats, boatsExtra(c.boats)) +
      `</div>` +
      (c.swim && !c.swim.call && c.swim.why ? `<p class="sc-swim-off"><strong>Swim:</strong> ${escapeHtml(c.swim.why.replace(/^No swim forecast: the /, "no call out of season. The "))}</p>` : "") +
      hoursBar(c.hours) + alertsList(c) +
      (c.nws && c.nws.lake && c.nws.lake.tonight ? `<p class="sc-tonight"><strong>Tonight on the lake (NWS):</strong> ${escapeHtml(withMph(c.nws.lake.tonight))}</p>` : "") +
      `<p class="sc-made">${madeLine(c)}</p>`;
    sinceCall(c);
  }

  /* ----- the record ----- */
  function measuredText(g) {
    if (!g) return "Graded the morning after.";
    const bits = [];
    if (g.waves) bits.push(`Waves to ${g.waves.measuredFt} ft at the buoy (${g.waves.measured})`);
    if (g.wind) bits.push(`wind ${g.wind.measuredKt} kt (${mph(g.wind.measuredKt)} mph) at the ${g.wind.where === "Michigan City buoy" ? "buoy" : "lighthouse"} (${g.wind.measured})`);
    if (g.band && g.band.towns) bits.push(g.band.towns.map((t) => `${t.town} ${t.measuredIn}" of snow`).join(", "));
    let text = bits.join("; ");
    if (text) text = text.charAt(0).toUpperCase() + text.slice(1) + ".";
    if (g.note) text += (text ? " " : "") + g.note;
    return text || "Nothing measured that day.";
  }
  function calledText(c) {
    const f = c.forecast || {};
    const bits = [];
    if (f.waveMaxFt !== null && f.waveMaxFt !== undefined) bits.push(`waves to ${f.waveMaxFt} ft`);
    if (f.windMaxKt !== null && f.windMaxKt !== undefined) bits.push(`wind to ${f.windMaxKt} kt (${mph(f.windMaxKt)} mph)`);
    return `${escapeHtml(c.headline || "")}${bits.length ? `<span class="said-from">From the NWS forecast: ${escapeHtml(bits.join(", "))}</span>` : ""}`;
  }
  function showRecord(data, max) {
    const body = $("scRecord");
    if (!body) return;
    const t = today();
    const rows = (data.calls || []).filter((c) => c.date < t).slice(0, max);
    body.innerHTML = rows.length ? rows.map((c) => {
      const g = c.grade;
      const tag = !g ? ["pending", "Waiting"] : TAG[g.result] || ["pending", "Not scored"];
      const late = c.counts === false ? `<span class="said-from">Made late (after 9 a.m.), not scored</span>` : "";
      return `<tr><th scope="row">${escapeHtml(dayName(c.date))}${late}</th><td>${calledText(c)}</td><td>${escapeHtml(measuredText(g))}</td>` +
        `<td><span class="verdict-tag ${tag[0]}">${tag[1]}</span></td></tr>`;
    }).join("") : `<tr><td colspan="4">The first calls are graded the morning after they&rsquo;re made. Check back tomorrow.</td></tr>`;
    const s = data.score || {};
    const sum = $("scScore");
    if (sum) {
      sum.className = "sc-score";
      sum.innerHTML = s.graded
        ? `Since ${escapeHtml(longDateOfYmd(s.since))}: <strong>${s.graded} morning${s.graded === 1 ? "" : "s"} scored.</strong> ${s.hit} held up, ${s.close} partly, ${s.miss} missed.`
        : `No calls scored yet. Each call is graded the morning after it&rsquo;s made, against the Michigan City buoy.`;
    }
  }

  function start() {
    const rules = $("shore-rules");
    const openRules = () => { if (rules && location.hash === "#shore-rules") { rules.open = true; rules.scrollIntoView(); } };
    openRules();
    window.addEventListener("hashchange", openRules);
    if (!$("scCard") && !$("scRecord")) return;
    load().then((data) => {
      showCall(data);
      showRecord(data, $("scCard") ? 14 : 30);
    }, () => {
      if ($("scCard")) $("scCard").innerHTML = `<p class="sc-head">We couldn&rsquo;t load the Shore Call just now.</p><p class="sc-why">Go by the Weather Service&rsquo;s forecasts and alerts below.</p>`;
      if ($("scRecord")) $("scRecord").innerHTML = `<tr><td colspan="4">We couldn&rsquo;t load the record just now.</td></tr>`;
      if ($("scScore")) $("scScore").textContent = "";
    });
  }
  start();
})();
