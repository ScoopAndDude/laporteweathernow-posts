// Forecast track record: checks what each Daily Scoop forecast against what
// the La Porte airport weather station recorded. Shared by the Track Record
// page and the Scoop drafting helper.
//
// The rules, in plain words (also shown on the Track Record page):
// - A day is scored against the most recent Scoop that went live (its `posted`
//   time) BEFORE that day began in La Porte. Posts from the day itself don't count.
// - High = the highest temperature of that calendar day, low = the lowest.
// - A temperature forecast "held up" if the reading was within 3°F of it. A range
//   like "upper 40s" (47-49) is scored from its middle, so vague forecasts get no
//   extra room.
// - Rain: when we gave a 50% or higher chance, it should have rained (0.01 in
//   or more); at 20% or lower it should have stayed dry. 21-49% isn't scored.
// - Days the station has no data for aren't scored.
// - We never edit a forecast after it's posted. Mistakes get a dated correction.

const SCORE_TZ = "America/Chicago";   // La Porte's clock decides what "a day" is
const OBS_STATION = { id: "PPO", network: "IN_ASOS", name: "La Porte Municipal Airport (KPPO)" };
const OBS_NEIGHBORS = [
  { id: "SBN", network: "IN_ASOS", name: "South Bend airport" },
  { id: "VPZ", network: "IN_ASOS", name: "Valparaiso airport" },
];
const TEMP_TOLERANCE = 3;

/** [low, high] for a forecast value that may be a number (69) or a range ([47, 49]). */
function fcRange(v) {
  if (Array.isArray(v) && v.length === 2 && isFinite(v[0]) && isFinite(v[1])) return [Math.min(v[0], v[1]), Math.max(v[0], v[1])];
  if (v !== null && v !== undefined && v !== "" && isFinite(v)) return [Number(v), Number(v)];
  return null;
}
function fcText(v) {
  const r = fcRange(v);
  if (!r) return "";
  return r[0] === r[1] ? `${r[0]}°` : `${r[0]}–${r[1]}°`;
}

/** When a post went live, in ms (its `posted` time). Posts without one never count. */
function postedMs(p) {
  const t = p && p.posted ? Date.parse(p.posted) : NaN;
  return isFinite(t) ? t : null;
}

/**
 * Every forecast in the posts, with the one that counts for each date: the
 * most recent daily Scoop that went live before that day began in La Porte.
 * Returns [{date, high, low, rain, post, leadDays}] sorted newest first.
 */
function collectForecasts(posts) {
  const best = new Map();
  (posts || []).filter((p) => p && p.type !== "weekly" && Array.isArray(p.forecasts)).forEach((p) => {
    const posted = postedMs(p);
    if (posted === null) return;
    p.forecasts.forEach((f) => {
      if (!f || !/^\d{4}-\d{2}-\d{2}$/.test(f.date || "")) return;
      if (!(posted < zonedDateTime(f.date, 0, SCORE_TZ).getTime())) return;   // must be public before the day starts
      const cur = best.get(f.date);
      if (!cur || posted > postedMs(cur.post)) {
        best.set(f.date, {
          date: f.date, high: f.high, low: f.low, rain: f.rain,
          post: p, leadDays: Math.round((ymdToUTCDate(f.date) - ymdToUTCDate(ymdInZone(new Date(posted), SCORE_TZ))) / 864e5),
        });
      }
    });
  });
  return [...best.values()].sort((a, b) => b.date.localeCompare(a.date));
}

/** All corrections in the posts, newest first: [{date, text, post}] */
function collectCorrections(posts) {
  const out = [];
  (posts || []).forEach((p) => (p && Array.isArray(p.corrections) ? p.corrections : []).forEach((c) => {
    if (c && c.text) out.push({ date: c.date || p.date, text: c.text, post: p });
  }));
  return out.sort((a, b) => String(b.date).localeCompare(String(a.date)));
}

function monthsBetween(firstYmd, lastYmd) {
  const out = [];
  let [y, m] = firstYmd.split("-").map(Number);
  const [ly, lm] = lastYmd.split("-").map(Number);
  while (y < ly || (y === ly && m <= lm)) {
    out.push([y, m]);
    m += 1; if (m > 12) { m = 1; y += 1; }
  }
  return out;
}

/** Daily summaries from the Iowa Environmental Mesonet archive of airport observations: {"YYYY-MM-DD": row} */
async function fetchStationDays(station, months) {
  const days = {};
  const results = await Promise.all(months.map(([y, m]) =>
    fetchJson(`https://mesonet.agron.iastate.edu/api/1/daily.json?station=${station.id}&network=${station.network}&year=${y}&month=${m}`, {}, 15000)));
  results.forEach((r) => (r && r.data ? r.data : []).forEach((row) => { if (row && row.date) days[row.date] = row; }));
  return days;
}

/** Observations for the dates we need. Neighbors are only used to double-check rain. */
async function fetchObservations(dates) {
  if (!dates.length) return { main: {}, neighbors: [] };
  const sorted = dates.slice().sort();
  const months = monthsBetween(sorted[0], sorted[sorted.length - 1]);
  const [main, ...neighbors] = await Promise.all([OBS_STATION, ...OBS_NEIGHBORS].map((s) => fetchStationDays(s, months).catch(() => null)));
  if (!main) throw new Error("Couldn't load the La Porte airport observations");
  // A failed neighbor stays in the list as null, so its missing data is never mistaken for "dry".
  return { main, neighbors };
}

/** What happened on a date, from the La Porte airport. */
function observedOn(date, obs) {
  const row = obs.main[date];
  const hasTemps = row && row.max_tmpf !== null && row.max_tmpf !== undefined && row.min_tmpf !== null && row.min_tmpf !== undefined;
  if (!hasTemps) return { missing: true };
  const out = { missing: false, high: Math.round(row.max_tmpf), low: Math.round(row.min_tmpf) };
  // The airport's gauge only reports on days it measures rain; no report means dry,
  // but only if both neighbors have data for that day and at least one of them
  // stayed under 0.10 in. Otherwise we can't be sure, so rain isn't scored.
  if (row.precip !== null && row.precip !== undefined && row.precip >= 0.01) {
    out.rained = true; out.rainText = `${Number(row.precip).toFixed(2)} in of rain`;
  } else if (row.precip !== null && row.precip !== undefined) {
    out.rained = false; out.rainText = "no measurable rain";
  } else {
    const amounts = obs.neighbors.map((n) => (n && n[date] && n[date].precip !== null && n[date].precip !== undefined ? Number(n[date].precip) : null));
    if (amounts.length < OBS_NEIGHBORS.length || amounts.some((a) => a === null)) {
      out.rained = null; out.rainText = "no rain report, couldn't double-check (not scored)";
    } else if (amounts.every((a) => a >= 0.10)) {
      out.rained = null; out.rainText = "rain nearby, none reported at La Porte (not scored)";
    } else {
      out.rained = false; out.rainText = "no rain recorded";
    }
  }
  return out;
}

/** Temperature check. A range ("upper 40s" = 47-49) is scored from its middle, like a single number. */
function tempCheck(forecast, observed) {
  const r = fcRange(forecast);
  if (!r || observed === null || observed === undefined) return null;
  const off = Math.round(Math.abs(observed - (r[0] + r[1]) / 2) * 10) / 10;
  return { off, hit: off <= TEMP_TOLERANCE };
}

function rainCheck(chance, rained) {
  if (chance === null || chance === undefined || chance === "" || !isFinite(chance) || rained === null || rained === undefined) return null;
  const c = Number(chance);
  if (c >= 50) return { hit: rained === true, kind: "likely" };
  if (c <= 20) return { hit: rained === false, kind: "dry" };
  return { hit: null, kind: "tossup" };
}

/** Score one forecast. status: "pending" | "nodata" | "scored". */
function scoreForecast(f, obs, todayYmd) {
  if (f.date >= todayYmd) return { status: "pending" };
  const o = observedOn(f.date, obs);
  if (o.missing) return { status: "nodata" };
  const high = tempCheck(f.high, o.high);
  const low = tempCheck(f.low, o.low);
  const rain = rainCheck(f.rain, o.rained);
  const parts = [high, low, rain && rain.hit !== null ? rain : null].filter(Boolean);
  const misses = parts.filter((p) => !p.hit).length;
  const verdict = !parts.length ? "none" : misses === 0 ? "hit" : misses === parts.length ? "miss" : "close";
  return { status: "scored", observed: o, high, low, rain, verdict, anyScored: parts.length > 0 };
}

/** Summary numbers for a set of scored rows. */
function summarize(rows) {
  const s = { days: 0, highs: [0, 0], lows: [0, 0], highErr: [], lowErr: [], likely: [0, 0], dry: [0, 0] };
  rows.forEach((r) => {
    if (!r.score || r.score.status !== "scored" || !r.score.anyScored) return;
    s.days += 1;
    if (r.score.high) { s.highs[1] += 1; if (r.score.high.hit) s.highs[0] += 1; s.highErr.push(r.score.high.off); }
    if (r.score.low) { s.lows[1] += 1; if (r.score.low.hit) s.lows[0] += 1; s.lowErr.push(r.score.low.off); }
    if (r.score.rain && r.score.rain.kind === "likely") { s.likely[1] += 1; if (r.score.rain.hit) s.likely[0] += 1; }
    if (r.score.rain && r.score.rain.kind === "dry") { s.dry[1] += 1; if (r.score.rain.hit) s.dry[0] += 1; }
  });
  const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
  s.highAvgOff = avg(s.highErr);
  s.lowAvgOff = avg(s.lowErr);
  return s;
}
