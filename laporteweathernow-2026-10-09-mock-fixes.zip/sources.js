// Our data sources: checks each free public source live, from this visitor's browser, and says whether it answered.
(function () {
  const rows = document.querySelectorAll("[data-check]");
  if (!rows.length) return;
  const fmt = (d) => d.toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit", timeZoneName: "short" });
  // What each check reads from the answer, to show how fresh the source's data is.
  const FRESH = {
    nws: (j) => (j && j.properties && j.properties.forecastOffice ? "Forecast office: NWS Northern Indiana (" + String(j.properties.cwa || "") + ")" : ""),
    obs: (j) => (j && j.properties && j.properties.timestamp ? "Latest La Porte airport reading: " + fmt(new Date(j.properties.timestamp)) : ""),
    spc: (j) => (j && (j.mapName || j.layers) ? "Storm outlook maps online" : ""),
    iem: (j) => (j && Array.isArray(j.data) ? `${j.data.length} days of La Porte readings this month` : ""),
    meteo: (j) => (j && j.current && j.current.time ? "Latest model hour: " + j.current.time.replace("T", " ") + " UTC" : ""),
    gdacs: (j) => (j && Array.isArray(j.features) ? `${j.features.length} current events tracked` : ""),
    usgs: (j) => (j && j.metadata ? `${j.metadata.count} quakes of magnitude 4.5+ in the last day, as of ${fmt(new Date(j.metadata.generated))}` : ""),
    eonet: (j) => (j && Array.isArray(j.events) ? `${j.events.length} volcanoes in ongoing eruption` : ""),
    usgsv: (j) => (Array.isArray(j) ? `${j.length} U.S. volcano${j.length === 1 ? "" : "es"} at an elevated alert level` : ""),
    bls: (j) => { const s = j && j.series && j.series.lp; const d = s && Array.isArray(s.data) && s.data[0]; return d ? `La Porte County unemployment: ${d.value}% (${d.periodName} ${d.year}); numbers saved ${String(j.updated || "").slice(0, 10)}` : ""; },
    watch: (j) => (j && j.updated ? `El Niño numbers last updated ${j.updated}${j.enso && j.enso.nextUpdate ? "; next NOAA update " + j.enso.nextUpdate : ""}` : ""),
    scoop: (j) => (j && Array.isArray(j.posts) && j.posts.length ? `Latest Daily Scoop: ${j.posts[0].date}` : Array.isArray(j) && j.length ? `Latest Daily Scoop: ${j[0].date}` : ""),
  };
  async function check(row) {
    const now = new Date();
    const url = row.dataset.url.replace("{Y}", now.getFullYear()).replace("{M}", now.getMonth() + 1);
    const kind = row.dataset.check;
    const out = row.querySelector(".src-status");
    const t0 = performance.now();
    const ctl = typeof AbortController === "function" ? new AbortController() : null;
    const timer = setTimeout(() => ctl && ctl.abort(), 15000);
    try {
      const res = await fetch(url, { cache: "no-store", signal: ctl ? ctl.signal : undefined, headers: kind === "nws" || kind === "obs" ? { Accept: "application/geo+json" } : {} });
      if (!res.ok) throw new Error("answered " + res.status);
      const j = await res.json();
      const ms = Math.round(performance.now() - t0);
      const note = (FRESH[kind] && FRESH[kind](j)) || "";
      out.className = "src-status ok";
      out.innerHTML = `<strong>Working</strong> (answered in ${ms < 1000 ? ms + " ms" : (ms / 1000).toFixed(1) + " s"})${note ? "<br><span>" + note.replace(/[<>&]/g, "") + "</span>" : ""}`;
    } catch (e) {
      out.className = "src-status bad";
      out.innerHTML = "<strong>Didn't answer just now.</strong><br><span>Pages that use it show their last saved data or a note, and try again.</span>";
    } finally {
      clearTimeout(timer);
    }
  }
  rows.forEach((r) => check(r));
  const when = document.getElementById("srcChecked");
  if (when) when.textContent = "Checked from your browser at " + fmt(new Date()) + ".";
})();
