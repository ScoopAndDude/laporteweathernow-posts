// Trip Planner: official NWS forecasts at checkpoints along a route, for the hour
// the traveler is expected at each one, plus alerts, SPC severe-storm outlooks,
// camping and safety links at the destination.
(function () {
  const AVG_MPH = 55;          // average driving speed, breaks not included
  const ROAD_FACTOR = 1.2;     // road miles are typically ~20% longer than straight-line miles
  const MAX_CHECKPOINTS = 14;
  const MAX_VIAS = 3;
  const $ = (id) => document.getElementById(id);
  const RAD = Math.PI / 180;

  const places = { from: null, to: null };
  const vias = []; // [{id, place}]
  let tripMap = null;
  let lastTrip = null;

  // ---------------- geometry ----------------
  function milesBetween(a, b) {
    const dLat = (b.lat - a.lat) * RAD, dLon = (b.lon - a.lon) * RAD;
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * RAD) * Math.cos(b.lat * RAD) * Math.sin(dLon / 2) ** 2;
    return 2 * 3958.8 * Math.asin(Math.sqrt(h));
  }
  function interpolate(a, b, f) {
    const p1 = a.lat * RAD, l1 = a.lon * RAD, p2 = b.lat * RAD, l2 = b.lon * RAD;
    const d = 2 * Math.asin(Math.sqrt(Math.sin((p2 - p1) / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin((l2 - l1) / 2) ** 2));
    if (!d) return { lat: a.lat, lon: a.lon };
    const A = Math.sin((1 - f) * d) / Math.sin(d), B = Math.sin(f * d) / Math.sin(d);
    const x = A * Math.cos(p1) * Math.cos(l1) + B * Math.cos(p2) * Math.cos(l2);
    const y = A * Math.cos(p1) * Math.sin(l1) + B * Math.cos(p2) * Math.sin(l2);
    const z = A * Math.sin(p1) + B * Math.sin(p2);
    return { lat: Math.atan2(z, Math.sqrt(x * x + y * y)) / RAD, lon: Math.atan2(y, x) / RAD };
  }

  function buildCheckpoints(waypoints) {
    const legs = [];
    let total = 0;
    for (let i = 0; i < waypoints.length - 1; i++) {
      const miles = milesBetween(waypoints[i], waypoints[i + 1]) * ROAD_FACTOR;
      legs.push({ a: waypoints[i], b: waypoints[i + 1], miles });
      total += miles;
    }
    const spacing = Math.min(90, Math.max(35, total / 10));
    let cps = [];
    let cum = 0;
    legs.forEach((leg, li) => {
      if (li === 0) cps.push({ lat: leg.a.lat, lon: leg.a.lon, roadMiles: 0, kind: "start", label: leg.a.name, place: leg.a });
      const n = Math.max(1, Math.round(leg.miles / spacing));
      for (let k = 1; k < n; k++) {
        const pt = interpolate(leg.a, leg.b, k / n);
        cps.push({ lat: pt.lat, lon: pt.lon, roadMiles: cum + (leg.miles * k) / n, kind: "along" });
      }
      cum += leg.miles;
      const last = li === legs.length - 1;
      cps.push({ lat: leg.b.lat, lon: leg.b.lon, roadMiles: cum, kind: last ? "end" : "via", label: leg.b.name, place: leg.b });
    });
    while (cps.length > MAX_CHECKPOINTS) {
      let idx = -1, best = Infinity;
      for (let i = 1; i < cps.length - 1; i++) {
        if (cps[i].kind !== "along") continue;
        const gap = cps[i + 1].roadMiles - cps[i - 1].roadMiles;
        if (gap < best) { best = gap; idx = i; }
      }
      if (idx < 0) break;
      cps = cps.slice(0, idx).concat(cps.slice(idx + 1));
    }
    return { checkpoints: cps, totalMiles: total };
  }

  // ---------------- data ----------------
  async function mapLimit(items, limit, fn) {
    const out = new Array(items.length);
    let next = 0;
    async function worker() {
      while (next < items.length) {
        const i = next++;
        try { out[i] = await fn(items[i], i); } catch (e) { out[i] = { error: e }; }
      }
    }
    await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
    return out;
  }

  // Forecasts are reused for 10 minutes, so re-checking a route in a tab that's
  // been open for hours still gets fresh data.
  const jsonCache = new Map();
  const CACHE_MS = 10 * 60 * 1000;
  function cachedNws(url) {
    const hit = jsonCache.get(url);
    if (hit && Date.now() - hit.at < CACHE_MS) return hit.promise;
    const promise = nwsGet(url).catch((e) => { jsonCache.delete(url); throw e; });
    jsonCache.set(url, { at: Date.now(), promise });
    return promise;
  }

  function periodAt(periods, when) {
    const t = when.getTime();
    return (periods || []).find((p) => new Date(p.startTime).getTime() <= t && t < new Date(p.endTime).getTime()) || null;
  }

  // SPC day 1-3 categorical outlooks: fetch polygons once, test each checkpoint locally.
  function spcWindows(now) {
    const d = new Date(now);
    const start = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 12);
    const day1 = d.getUTCHours() >= 6 ? start : start - 864e5;
    return [1, 2, 3].map((day) => [new Date(day1 + (day - 1) * 864e5), new Date(day1 + day * 864e5)]);
  }
  function parseSpcTime(s) {
    const m = String(s || "").match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})$/);
    return m ? new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5])) : null;
  }
  async function loadSpc() {
    const windows = spcWindows(Date.now());
    return Promise.all([1, 2, 3].map(async (day, i) => {
      const url = `${SPC_MAPSERVER}/${SPC_CATEGORICAL_LAYERS[day]}/query?where=1%3D1&outFields=dn,valid,expire&returnGeometry=true&outSR=4326&f=geojson`;
      try {
        const gj = await fetchJson(url, {}, 15000);
        const feats = gj.features || [];
        let win = windows[i];
        const f0 = feats[0] && feats[0].properties;
        if (f0 && parseSpcTime(f0.valid) && parseSpcTime(f0.expire)) win = [parseSpcTime(f0.valid), parseSpcTime(f0.expire)];
        return { day, window: win, features: feats };
      } catch (e) {
        return { day, window: windows[i], features: null };
      }
    }));
  }
  function inRing(x, y, ring) {
    let inside = false;
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1];
      if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
    }
    return inside;
  }
  function inGeometry(lon, lat, g) {
    if (!g) return false;
    const polys = g.type === "Polygon" ? [g.coordinates] : g.type === "MultiPolygon" ? g.coordinates : [];
    return polys.some((rings) => inRing(lon, lat, rings[0]) && !rings.slice(1).some((h) => inRing(lon, lat, h)));
  }
  function spcAt(spcDays, cp, when) {
    for (const d of spcDays || []) {
      if (!(when >= d.window[0] && when < d.window[1])) continue;
      if (d.features === null) return { day: d.day, unknown: true };
      let top = 0;
      d.features.forEach((f) => { if (inGeometry(cp.lon, cp.lat, f.geometry)) top = Math.max(top, (f.properties && f.properties.dn) || 0); });
      const t = SPC_RISK_TEXT[top] || { short: "None", long: "No thunderstorm risk outlined", level: -1 };
      return Object.assign({ day: d.day, dn: top }, t);
    }
    return null;
  }

  /**
   * Forecast and alerts for one checkpoint. The two are separate requests, so
   * one failing never hides the other, and every failure is recorded:
   *   forecastStatus: "ok" | "beyond" (past the NWS forecast range)
   *                   | "nocoverage" (NWS has no forecast point here) | "error"
   *   alertsChecked:  false when the alert request failed
   */
  async function checkpointData(cp, eta) {
    const alertsP = fetchAlertsForPoint(cp.lat, cp.lon).then((list) => ({ ok: true, list }), () => ({ ok: false, list: [] }));
    const out = { place: null, state: null, period: null, periodKind: "none", alerts: [], alertsChecked: false, forecastStatus: "ok" };
    try {
      const pt = await cachedNws(`${NWS_BASE}/points/${cp.lat.toFixed(4)},${cp.lon.toFixed(4)}`);
      const p = pt.properties;
      const rel = p.relativeLocation && p.relativeLocation.properties;
      out.place = rel ? `${rel.city}, ${rel.state}` : null;
      out.state = rel ? rel.state : null;
      try {
        const hourly = await cachedNws(p.forecastHourly);
        out.period = periodAt(hourly.properties.periods, eta);
        if (out.period) out.periodKind = "hourly";
      } catch (e) { /* try the 12-hour forecast below */ }
      if (!out.period) {
        let dailyOk = false;
        try {
          const daily = await cachedNws(p.forecast);
          dailyOk = true;
          out.period = periodAt(daily.properties.periods, eta);
          if (out.period) out.periodKind = "12-hour";
        } catch (e) { /* recorded below */ }
        if (!out.period) out.forecastStatus = dailyOk ? "beyond" : "error";
      }
    } catch (e) {
      out.forecastStatus = e && e.status === 404 ? "nocoverage" : "error";
    }
    const a = await alertsP;
    out.alertsChecked = a.ok;
    const t = eta.getTime();
    out.alerts = a.list.filter((al) => {
      const ap = al.properties;
      const start = new Date(ap.onset || ap.effective || 0).getTime();
      return start <= t + 2 * 3600e3 && alertEndMs(ap) >= t - 3600e3;
    });
    return out;
  }

  /** Which checklist item an official alert calls for. */
  function alertKind(ev) {
    if (/tornado/i.test(ev)) return "tornado";
    if (/hurricane|tropical storm|extreme wind|storm surge/i.test(ev)) return "tropical";
    if (/thunderstorm/i.test(ev)) return "thunder";
    if (/flood/i.test(ev)) return "rain";
    if (/winter|blizzard|ice storm|snow|sleet|freezing (rain|drizzle)|lake effect/i.test(ev)) return "winter";
    if (/heat/i.test(ev)) return "heat";
    if (/dust/i.test(ev)) return "dust";
    if (/cold|chill|freeze|frost/i.test(ev)) return "cold";   // before "wind", so Wind Chill alerts count as cold
    if (/wind/i.test(ev)) return "wind";
    if (/fog|smoke/i.test(ev)) return "fog";
    return "alert";
  }

  // ---------------- hazards (our guidance) ----------------
  const DRIVING_WARNINGS = /tornado|severe thunderstorm|flash flood|flood|blizzard|winter storm|ice storm|high wind|extreme wind|dust storm|snow squall|hurricane|tropical storm|extreme cold|excessive heat|extreme heat/i;
  function evaluate(d, vehicle) {
    const flags = [];
    const period = d.period;
    if (period) {
      const f = (period.shortForecast || "").toLowerCase();
      const pop = (period.probabilityOfPrecipitation && period.probabilityOfPrecipitation.value) || 0;
      const wind = windMphFromText(period.windSpeed);
      const temp = period.temperature;
      if (/thunder|t-storm/.test(f)) flags.push({ level: 1, kind: "thunder", text: "Thunderstorms" });
      if (/blizzard|freezing rain|freezing drizzle|ice|sleet|heavy snow/.test(f)) flags.push({ level: 2, kind: "winter", text: "Snow or ice" });
      else if (/snow|flurr|wintry/.test(f)) flags.push({ level: 1, kind: "winter", text: "Snow" });
      if (/rain|shower|drizzle/.test(f) && !/thunder/.test(f) && pop >= 70) flags.push({ level: 1, kind: "rain", text: `Rain likely (${pop}%)` });
      const windCaution = vehicle === "van" ? 20 : 30, windStop = vehicle === "van" ? 35 : 45;
      if (wind >= windStop) flags.push({ level: 2, kind: "wind", text: `Strong wind (${wind} mph)` });
      else if (wind >= windCaution) flags.push({ level: 1, kind: "wind", text: `Windy (${wind} mph)` });
      if (/fog|smoke|haze/.test(f)) flags.push({ level: 1, kind: "fog", text: "Low visibility" });
      if (temp >= 95) flags.push({ level: 1, kind: "heat", text: `Hot (${temp}°F)` });
      if (temp <= 10) flags.push({ level: 1, kind: "cold", text: `Very cold (${temp}°F)` });
    }
    d.alerts.forEach((a) => {
      const ev = a.properties.event || "Alert";
      const serious = /warning/i.test(ev) && DRIVING_WARNINGS.test(ev);
      flags.push({ level: serious ? 2 : 1, kind: "alert", text: ev, official: true });
    });
    if (d.spc && d.spc.level >= 3) flags.push({ level: 2, kind: "spc", text: `${d.spc.short} severe-storm risk (SPC)` });
    else if (d.spc && d.spc.level >= 1) flags.push({ level: 1, kind: "spc", text: `${d.spc.short} severe-storm risk (SPC)` });
    const level = d.period ? flags.reduce((m, f) => Math.max(m, f.level), 0) : (flags.length ? Math.max(...flags.map((f) => f.level)) : -1);
    return { flags, level };
  }

  // ---------------- form helpers ----------------
  // "Use my location" spots are rounded to about a kilometer in shareable links.
  function placeParam(p) { const d = p.approx ? 2 : 4; return [p.lat.toFixed(d), p.lon.toFixed(d), p.tz || "", p.name].join(","); }
  function parsePlace(s) {
    if (!s) return null;
    const parts = s.split(",");
    const lat = Number(parts[0]), lon = Number(parts[1]);
    if (!isFinite(lat) || !isFinite(lon)) return null;
    return { lat, lon, tz: validTimeZone(parts[2]) || undefined, name: parts.slice(3).join(",").trim() || "Selected place" };
  }

  function startTz() { return (places.from && validTimeZone(places.from.tz)) || LOCAL_TZ; }

  /** Fill in a missing time zone (older saved towns, links without one). */
  async function ensureTz(place) {
    if (!place || validTimeZone(place.tz)) return place;
    const tz = await lookupTimeZone(place.lat, place.lon);
    if (tz) place.tz = tz;
    return place;
  }

  function fillDateOptions(keep) {
    const tz = startTz();
    const today = ymdInZone(new Date(), tz);
    const sel = $("dateSelect");
    const prev = keep || sel.value;
    sel.innerHTML = Array.from({ length: 7 }, (_, i) => {
      const ymd = addDaysYmd(today, i);
      const label = i === 0 ? `Today (${weekdayOfYmd(ymd)} ${monthDayOfYmd(ymd)})` : i === 1 ? `Tomorrow (${weekdayOfYmd(ymd)} ${monthDayOfYmd(ymd)})` : `${weekdayOfYmd(ymd, "long")} ${monthDayOfYmd(ymd)}`;
      return `<option value="${ymd}">${label}</option>`;
    }).join("");
    if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
    const hs = $("hourSelect");
    if (!hs.options.length) {
      hs.innerHTML = Array.from({ length: 24 }, (_, h) => `<option value="${h}">${h === 0 ? "12 AM" : h < 12 ? h + " AM" : h === 12 ? "12 PM" : h - 12 + " PM"}</option>`).join("");
      const nowHour = Number(fmtInZone(new Date(), tz, { hour: "numeric", hourCycle: "h23" }));
      hs.value = String(Math.min(23, (isFinite(nowHour) ? nowHour : 7) + 1));
    }
    $("tzHint").textContent = places.from ? `Departure time is ${places.from.name} time (${zoneAbbrev(new Date(), tz)}).` : "";
  }

  function setPlace(which, place) {
    places[which] = place;
    const el = $(which + "Picked");
    el.textContent = place ? `✓ ${place.name}` : "";
    const input = $(which + "Input");
    if (place) input.value = place.name;
    if (which === "from") fillDateOptions();
  }

  function addViaRow(place) {
    if (vias.length >= MAX_VIAS) return;
    const id = "via" + Math.random().toString(36).slice(2, 8);
    const row = document.createElement("div");
    row.className = "via-row";
    row.innerHTML = `<div class="field search-wrap" style="margin:0;">
        <label class="visually-hidden" for="${id}Input">Stop along the way</label>
        <input type="text" id="${id}Input" placeholder="A town on your route" />
        <div id="${id}Results" class="search-results"></div>
        <div class="picked" id="${id}Picked"></div>
      </div>
      <button type="button" class="link-btn" data-remove="${id}" style="margin-top:12px;">Remove</button>`;
    $("viaList").appendChild(row);
    const entry = { id, place: place || null, row };
    vias.push(entry);
    wireLocationSearch($(id + "Input"), $(id + "Results"), (p) => { entry.place = p; $(id + "Input").value = p.name; $(id + "Picked").textContent = `✓ ${p.name}`; });
    if (place) { $(id + "Input").value = place.name; $(id + "Picked").textContent = `✓ ${place.name}`; }
    row.querySelector("[data-remove]").addEventListener("click", () => {
      row.remove();
      vias.splice(vias.indexOf(entry), 1);
      $("addVia").hidden = vias.length >= MAX_VIAS;
    });
    $("addVia").hidden = vias.length >= MAX_VIAS;
  }

  async function resolveTyped(inputEl, current) {
    const typed = inputEl.value.trim();
    if (current && typed === current.name) return current;
    if (!typed) return null;
    const matches = await searchUSLocations(typed);
    return matches[0] || null;
  }

  // ---------------- run ----------------
  function fmtTrip(when, tz) {
    return `${fmtInZone(when, tz, { weekday: "short", hour: "numeric", minute: "2-digit" })}`;
  }
  function hoursText(h) {
    const total = Math.max(1, Math.round(h * 60));
    const hh = Math.floor(total / 60), mm = total % 60;
    if (!hh) return `${mm} min`;
    return mm ? `${hh} h ${mm} min` : `${hh} h`;
  }

  async function run(opts) {
    const err = $("formError");
    err.textContent = "";
    const out = $("tripResults");
    try {
      const from = await resolveTyped($("fromInput"), places.from);
      const to = await resolveTyped($("toInput"), places.to);
      if (!from) { err.textContent = "Pick where you're starting from."; return; }
      if (!to) { err.textContent = "Pick where you're headed."; return; }
      await Promise.all([ensureTz(from), ensureTz(to)]);
      setPlace("from", from); setPlace("to", to);
      const viaPlaces = [];
      for (const v of vias) {
        const p = await resolveTyped($(v.id + "Input"), v.place);
        if (p) { v.place = p; viaPlaces.push(p); }
      }
      const waypoints = [from, ...viaPlaces, to];
      if (milesBetween(from, to) < 5 && !viaPlaces.length) { err.textContent = "Your start and destination are the same place. Pick a different destination."; return; }

      const tz = startTz();
      fillDateOptions();
      const ymd = $("dateSelect").value;
      const hour = Number($("hourSelect").value);
      let depart = zonedDateTime(ymd, hour, tz);
      let departNote = "";
      if (depart.getTime() < Date.now() - 15 * 60000) { depart = new Date(); departNote = "That time has already passed, so we're using right now."; }
      if (opts && opts.note) departNote = [opts.note, departNote].filter(Boolean).join(" ");
      const vehicle = $("vehicleSelect").value;

      const { checkpoints, totalMiles } = buildCheckpoints(waypoints);
      const driveHours = totalMiles / AVG_MPH;
      const arrive = new Date(depart.getTime() + driveHours * 3600e3);
      $("goBtn").disabled = true;
      out.innerHTML = `<div class="notice info" style="margin-top:20px;">Checking the NWS forecast at ${checkpoints.length} points along about ${Math.round(totalMiles)} road miles&hellip; <span id="tripProgress">0</span>/${checkpoints.length}</div>`;
      $("tripStatus").textContent = `Checking the forecast at ${checkpoints.length} points along your route.`;

      const spcP = loadSpc();   // severe-storm outlooks load alongside the forecasts
      let done = 0;
      const etaOf = (cp) => new Date(depart.getTime() + (cp.roadMiles / AVG_MPH) * 3600e3);
      const results = await mapLimit(checkpoints, 4, async (cp) => {
        const d = await checkpointData(cp, etaOf(cp));
        done++;
        const pe = $("tripProgress"); if (pe) pe.textContent = String(done);
        return Object.assign({ cp, eta: etaOf(cp) }, d);
      });
      results.forEach((r, i) => {
        if (!r || r.error) {
          const cp = checkpoints[i];
          results[i] = { cp, eta: etaOf(cp), place: null, state: null, period: null, periodKind: "none", alerts: [], alertsChecked: false, forecastStatus: "error" };
        }
      });
      const spcDays = await spcP;
      results.forEach((r) => {
        r.spc = spcAt(spcDays, r.cp, r.eta);
        Object.assign(r, evaluate(r, vehicle));
        r.checkFailed = r.forecastStatus === "error" || !r.alertsChecked;
      });

      lastTrip = { from, to, vias: viaPlaces, date: ymd, hour, vehicle, depart, arrive, totalMiles, driveHours, results, departNote, quiet: !!(opts && opts.fromUrl) };
      render(lastTrip);
      if (typeof lpwnTrack === "function") lpwnTrack("trip-planned", totalMiles < 100 ? "under 100 mi" : totalMiles < 300 ? "100-300 mi" : "300+ mi");
      if (!opts || !opts.fromUrl) {
        const url = new URL(location.href);
        url.search = tripQuery(lastTrip);
        history.replaceState(null, "", url);
      }
    } catch (e) {
      console.error(e);
      out.innerHTML = `<div class="notice" style="margin-top:20px;">Something went wrong checking this route. Please try again in a minute.</div>`;
    } finally {
      $("goBtn").disabled = false;
    }
  }

  function tripQuery(t) {
    const q = new URLSearchParams();
    q.set("from", placeParam(t.from));
    q.set("to", placeParam(t.to));
    t.vias.forEach((v) => q.append("via", placeParam(v)));
    q.set("date", t.date); q.set("hour", String(t.hour)); q.set("v", t.vehicle);
    return "?" + q.toString();
  }

  const SHOP = {
    thunder: ["Severe Thunderstorm Planner", "https://www.etsy.com/listing/4581780096/severe-thunderstorm-planner-printable"],
    spc: ["Severe Thunderstorm Planner", "https://www.etsy.com/listing/4581780096/severe-thunderstorm-planner-printable"],
    tornado: ["Tornado Survival Planner", "https://www.etsy.com/listing/4581772468/tornado-survival-planner-12-page"],
    winter: ["Winter Storm Preparedness Planner", "https://www.etsy.com/listing/4581776504/winter-storm-preparedness-planner"],
    rain: ["Flood Survival Planner", "https://www.etsy.com/listing/4581774312/flood-survival-planner-12-page-printable"],
    heat: ["Extreme Heat Safety Planner", "https://www.etsy.com/listing/4581764949/extreme-heat-preparedness-planner"],
    base: ["Survival Prep Planner", "https://www.etsy.com/listing/4581498059/survival-prep-planner-printable"],
  };

  function render(t) {
    const tz = startTz();
    const zone = zoneAbbrev(t.depart, tz);
    const n = t.results.length;
    const known = t.results.filter((r) => r.level >= 0);
    const worst = known.reduce((m, r) => Math.max(m, r.level), known.length ? 0 : -1);
    const failed = t.results.filter((r) => r.checkFailed);
    const beyond = t.results.filter((r) => !r.period && r.forecastStatus === "beyond").length;
    const noCoverage = t.results.filter((r) => !r.period && r.forecastStatus === "nocoverage").length;
    const noForecastErr = t.results.filter((r) => r.forecastStatus === "error").length;
    const unchecked = beyond + noCoverage;
    const spcGap = t.results.filter((r) => r.spc && r.spc.unknown).length;  // outlook failed for a time we'd be driving

    const reasons = [];
    t.results.forEach((r) => {
      const top = r.flags.filter((f) => f.level === Math.max(1, worst));
      if (!top.length || reasons.length >= 4) return;
      const where = r.cp.label || r.place || "along the way";
      reasons.push(`${top.map((f) => f.text).join(", ")} near ${where} around ${fmtTrip(r.eta, tz)}`);
    });

    // Never say "good to go" on incomplete data.
    let verdict;
    if (worst >= 2) verdict = { cls: "stop", title: "Reconsider or re-time this trip", sub: "Serious weather is forecast or official warnings are active along your route at the times you'd be there." };
    else if (failed.length === n) verdict = { cls: "caution", title: "Couldn't reach the National Weather Service", sub: "We couldn't check this route just now. Try again in a few minutes, and check official alerts before you leave." };
    else if (failed.length || spcGap) {
      const gaps = [];
      if (failed.length) gaps.push(`we couldn't reach NWS for ${failed.length} of ${n} checkpoints (marked below)`);
      if (spcGap) gaps.push("the Storm Prediction Center's severe-storm outlook didn't load");
      const said = gaps.join(", and ");
      verdict = { cls: "caution", title: "Couldn't check everything", sub: `${said.charAt(0).toUpperCase() + said.slice(1)}, so this isn't the full picture.${worst === 1 ? " Where we could check, there's some weather worth planning around." : ""} Try again in a few minutes, and check official alerts before you leave.` };
    }
    else if (!known.length) verdict = { cls: "caution", title: "Too far out to call yet", sub: "There's no detailed NWS forecast for your travel times yet. Check back within 6 days of leaving." };
    else if (worst === 1) verdict = { cls: "caution", title: "Go, with caution", sub: "Some weather worth planning around along the way." };
    else if (unchecked) verdict = { cls: "go", title: "Looks good where we could check", sub: `No flags at the ${n - unchecked} checkpoint${n - unchecked === 1 ? "" : "s"} we could check. ${unchecked} more ${unchecked === 1 ? "is" : "are"} too far out or outside NWS coverage, so check again closer to your trip.` };
    else verdict = { cls: "go", title: "Looks good to go", sub: "No flags at your checkpoints for the times you'd be there. Conditions can change, so check again before you leave." };

    const missingParts = [
      beyond ? `${beyond} too far out for the NWS forecast` : "",
      noCoverage ? `${noCoverage} outside NWS coverage (over water or outside the US)` : "",
      noForecastErr ? `${noForecastErr} we couldn't reach NWS for` : "",
    ].filter(Boolean);
    const alertGaps = t.results.filter((r) => !r.alertsChecked).length;

    const toTz = t.to.tz || tz;
    const arriveLocal = toTz !== tz ? ` (${fmtClock(t.arrive, toTz)} ${zoneAbbrev(t.arrive, toTz)} local)` : "";
    const kinds = new Set();
    t.results.forEach((r) => r.flags.forEach((f) => kinds.add(f.kind === "alert" ? alertKind(f.text) : f.kind)));

    const shownLevel = (r) => (r.checkFailed && r.level < 1 ? -1 : r.level);
    const rows = t.results.map((r) => {
      const lv = shownLevel(r);
      const cls = lv >= 2 ? "stop" : lv === 1 ? "caution" : lv === 0 ? "" : "unknown";
      const name = r.cp.label ? escapeHtml(r.cp.label) : r.place ? `Near ${escapeHtml(r.place)}` : "Along the way";
      const p = r.period;
      const pop = p && p.probabilityOfPrecipitation && p.probabilityOfPrecipitation.value;
      const wx = p ? `${conditionIcon(p.shortForecast, p.isDaytime)} ${p.temperature}&deg;F &middot; ${escapeHtml(p.shortForecast)}${pop != null ? ` &middot; ${pop}% rain` : ""} &middot; wind ${escapeHtml(p.windSpeed || "calm")}${r.periodKind === "12-hour" ? " <em>(12-hour forecast)</em>" : ""}`
        : r.forecastStatus === "error" ? "<strong>Couldn't reach NWS for this spot.</strong> Try again in a few minutes."
        : r.forecastStatus === "nocoverage" ? "No NWS forecast for this spot (it may be over water or outside the US)."
        : "Beyond the NWS forecast range for this time.";
      const flags = r.flags.map((f) => `<span class="pill ${f.level >= 2 ? "bad" : "warn"}">${f.official ? "&#9888;&#65039; NWS: " : ""}${escapeHtml(f.text)}</span>`).join("");
      const em = `/emergency?lat=${r.cp.lat.toFixed(4)}&lon=${r.cp.lon.toFixed(4)}&name=${encodeURIComponent(r.cp.label || (r.place ? "Near " + r.place : "Checkpoint"))}`;
      return `<div class="checkpoint ${cls}">
        <div class="cp-when">${fmtTrip(r.eta, tz)}<small>${zone} &middot; ${Math.round(r.cp.roadMiles)} mi</small><small class="cp-status">${lv >= 2 ? "Serious" : lv === 1 ? "Caution" : lv === 0 ? "No flags" : r.checkFailed ? "Not checked" : "No forecast"}</small></div>
        <div>
          <div class="cp-place">${name}</div>
          <div class="cp-wx">${wx}</div>
          ${flags ? `<div class="cp-flags">${flags}</div>` : ""}
          ${!r.alertsChecked ? `<div class="cp-wx" style="color:var(--bad); font-weight:700; margin-top:4px;">Couldn't check official alerts here.</div>` : ""}
          ${r.alerts.length ? `<div style="margin-top:6px;"><a href="${em}" style="color:var(--forest); font-weight:700; font-size:13.5px;">Official alert details for this spot &rarr;</a></div>` : ""}
        </div>
      </div>`;
    }).join("");

    const dest = t.results[t.results.length - 1];
    const campUrl = `/camp-map?lat=${t.to.lat.toFixed(4)}&lon=${t.to.lon.toFixed(4)}&name=${encodeURIComponent(t.to.name)}`;
    const emUrl = `/emergency?lat=${t.to.lat.toFixed(4)}&lon=${t.to.lon.toFixed(4)}&name=${encodeURIComponent(t.to.name)}${t.to.tz ? "&tz=" + encodeURIComponent(t.to.tz) : ""}`;

    const checklist = [
      `Turn on emergency alerts on your phone, and bring a second way to get warnings, like a NOAA Weather Radio. <a href="/emergency#warnings">Why two?</a>`,
      `Check official alerts before you leave and at stops: <a href="${emUrl}">Emergency view for ${escapeHtml(t.to.name)}</a>.`,
    ];
    if (kinds.has("thunder") || kinds.has("spc") || kinds.has("tornado")) checklist.push("Storms possible: know where you'd shelter (a sturdy building, not a tent or van), and check the Storm Prediction Center outlook the morning you leave.");
    if (kinds.has("winter")) checklist.push("Winter weather: pack a winter kit (blankets, water, snacks, a small shovel), keep your tank at least half full, and check state road reports.");
    if (kinds.has("tropical")) checklist.push("Tropical storm, hurricane, or extreme wind alerts: follow local officials' orders, and don't drive into the storm.");
    if (kinds.has("wind")) checklist.push("Strong wind: tall vehicles and trailers are hard to control. Slow down, or leave at a calmer hour.");
    if (kinds.has("dust")) checklist.push("Blowing dust: don't drive into it. If it reaches you, pull fully off the road, turn off all your lights, and take your foot off the brake.");
    if (kinds.has("rain")) checklist.push("Heavy rain: never drive into water over the road. Turn around, don't drown.");
    if (kinds.has("fog")) checklist.push("Low visibility: slow down, use your low beams, and leave extra room.");
    if (kinds.has("heat")) checklist.push("Heat: carry extra water, and never leave pets or people in a parked vehicle.");
    if (kinds.has("cold")) checklist.push("Cold: dress in layers, keep blankets in the vehicle, and never run a generator, grill, or camp stove inside a van or tent.");

    const shopKeys = ["tornado", "thunder", "spc", "winter", "rain", "heat"].filter((k) => kinds.has(k));
    const picks = [];
    shopKeys.forEach((k) => { if (picks.length < 2 && !picks.some((p) => p[0] === SHOP[k][0])) picks.push(SHOP[k]); });
    if (!picks.length) picks.push(SHOP.base);

    const destP = dest && dest.period;
    $("tripResults").innerHTML = `
      <div class="verdict ${verdict.cls}" id="tripVerdict" tabindex="-1">
        <div class="v-title">${verdict.title}</div>
        <div class="v-sub">${verdict.sub}</div>
        ${reasons.length && worst >= 1 ? `<ul style="margin:10px 0 0; padding-left:20px;">${reasons.map((x) => `<li>${escapeHtml(x)}</li>`).join("")}</ul>` : ""}
        <div class="v-sub" style="margin-top:8px; opacity:0.85;">Automated guidance from NWS data, not an official warning.</div>
      </div>
      <p class="summary-line"><strong>${escapeHtml(t.from.name)} &rarr; ${t.vias.map((v) => escapeHtml(v.name) + " &rarr; ").join("")}${escapeHtml(t.to.name)}</strong> &middot; about ${Math.round(t.totalMiles)} road miles &middot; ~${hoursText(t.driveHours)} of driving &middot; leave ${fmtTrip(t.depart, tz)} ${zone}, arrive around ${fmtTrip(t.arrive, tz)} ${zone}${arriveLocal}.</p>
      ${t.departNote ? `<p class="summary-line">${t.departNote}</p>` : ""}
      ${missingParts.length ? `<p class="summary-line">No forecast at ${missingParts.join("; ")}.</p>` : ""}
      ${alertGaps ? `<p class="summary-line"><strong>We couldn't check official alerts at ${alertGaps} checkpoint${alertGaps === 1 ? "" : "s"}.</strong> Check the Emergency view before you go.</p>` : ""}
      ${spcGap ? `<p class="summary-line">The Storm Prediction Center's severe-storm outlook didn't load, so storm risk from it isn't included. <a href="https://www.spc.noaa.gov/products/outlook/" target="_blank" rel="noopener">View it on spc.noaa.gov &#8599;</a></p>` : ""}
      <div id="tripMap" role="region" aria-label="Route map"></div>
      <h3 style="font-family:var(--serif); font-size:22px; margin:26px 0 10px;">Checkpoints <span style="font-size:14px; color:var(--ink-soft); font-family:var(--sans);">(times on your starting clock, ${zone})</span></h3>
      <div class="checkpoints">${rows}</div>

      <div class="dest-grid">
        <div class="auto-card">
          <div class="label">Arriving in ${escapeHtml(t.to.name)}</div>
          <p>${destP ? `${conditionIcon(destP.shortForecast, destP.isDaytime)} ${destP.temperature}&deg;F, ${escapeHtml(destP.shortForecast)} around ${fmtTrip(t.arrive, toTz)} ${zoneAbbrev(t.arrive, toTz)}.` : "No forecast yet for your arrival time."}</p>
          <ul class="link-list" style="margin-top:10px;">
            <li><a href="${campUrl}" data-track="trip-open-camping">Free camping near ${escapeHtml(t.to.name)} &rarr;</a></li>
            <li><a href="${emUrl}">Emergency view: alerts, radar, roads &rarr;</a></li>
            <li><a href="${nwsPointPageUrl(t.to.lat, t.to.lon)}" target="_blank" rel="noopener">Official NWS forecast &#8599;</a></li>
          </ul>
        </div>
        <div class="guidance-panel">
          <div class="panel-kicker">Before you go &middot; our checklist</div>
          <ul class="checklist">${checklist.map((c) => `<li>${c}</li>`).join("")}</ul>
        </div>
        <div class="auto-card">
          <div class="label">From our shop</div>
          <p style="font-size:14px;">Printable planners for the weather on this route:</p>
          <ul class="link-list" style="margin-top:6px;">${picks.map((p) => `<li><a href="${p[1]}" target="_blank" rel="noopener">${p[0]} on Etsy &#8599;</a></li>`).join("")}</ul>
        </div>
      </div>

      <div class="trip-actions">
        <button type="button" class="btn btn-dark" id="saveTrip">&#11088; Save this trip</button>
        <button type="button" class="btn btn-dark" id="copyTrip">&#128279; Copy link to this trip</button>
        <a class="btn btn-amber" href="#newsletter" id="emailTrip">&#9993;&#65039; Email me about this trip</a>
      </div>
      <p class="small-print" id="tripActionNote"></p>`;

    try { drawMap(t, tz); } catch (e) { console.warn("Map unavailable", e); const m = $("tripMap"); if (m) m.style.display = "none"; }
    wireActions(t);
    // Tell screen readers the result, and move keyboard focus to it.
    $("tripStatus").textContent = `${verdict.title}. ${n} checkpoints checked; details follow.`;
    if (!t.quiet) { const v = $("tripVerdict"); if (v) v.focus({ preventScroll: false }); }
  }

  function drawMap(t, tz) {
    if (!window.L) return;
    if (tripMap) { tripMap.remove(); tripMap = null; }
    tripMap = L.map("tripMap", { scrollWheelZoom: false });
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "&copy; OpenStreetMap contributors", maxZoom: 18 }).addTo(tripMap);
    const pts = [t.from, ...t.vias, t.to].map((p) => [p.lat, p.lon]);
    const line = L.polyline(pts, { color: "#1a1a1a", weight: 3, dashArray: "6 6" }).addTo(tripMap);
    const color = (lv) => (lv >= 2 ? "#b23a2f" : lv === 1 ? "#e8963d" : lv === 0 ? "#2f7d4f" : "#8a8a8a");
    t.results.forEach((r) => {
      const lv = r.checkFailed && r.level < 1 ? -1 : r.level;
      L.circleMarker([r.cp.lat, r.cp.lon], { radius: r.cp.kind === "along" ? 7 : 10, color: "#fff", weight: 2, fillColor: color(lv), fillOpacity: 0.95 })
        .bindPopup(`<strong>${escapeHtml(r.cp.label || (r.place ? "Near " + r.place : "Checkpoint"))}</strong><br/>${fmtTrip(r.eta, tz)}<br/>${r.period ? escapeHtml(r.period.shortForecast) + ", " + r.period.temperature + "&deg;F" : "No forecast"}`)
        .addTo(tripMap);
    });
    tripMap.fitBounds(line.getBounds().pad(0.15));
  }

  function wireActions(t) {
    const note = $("tripActionNote");
    $("saveTrip").addEventListener("click", () => {
      try {
        localStorage.setItem("lpwn_saved_trip", JSON.stringify({ from: t.from, to: t.to, vias: t.vias, date: t.date, hour: t.hour, vehicle: t.vehicle, savedAt: new Date().toISOString() }));
        note.textContent = "Saved on this device. You'll see it on the homepage under \"Planning a trip.\"";
        if (typeof lpwnTrack === "function") lpwnTrack("trip-saved");
      } catch (e) { note.textContent = "Couldn't save on this device (private browsing may block it). Use \"Copy link\" instead."; }
    });
    $("copyTrip").addEventListener("click", async () => {
      const url = location.origin + location.pathname + tripQuery(t);
      try { await navigator.clipboard.writeText(url); note.textContent = "Link copied. It reopens this trip with fresh forecasts."; }
      catch (e) { note.textContent = url; }
      if (typeof lpwnTrack === "function") lpwnTrack("trip-share");
    });
    $("emailTrip").addEventListener("click", () => {
      const box = $("tripOptIn");
      if (box) { box.checked = true; box.dispatchEvent(new Event("change")); }
    });
    // Offer the trip in the newsletter form (opt-in only).
    const form = document.querySelector("form[data-newsletter]");
    if (form && !$("tripOptIn")) {
      const wrap = document.createElement("label");
      wrap.className = "fineprint";
      wrap.style.cssText = "display:flex; gap:8px; align-items:flex-start; cursor:pointer;";
      wrap.innerHTML = `<input type="checkbox" id="tripOptIn" style="margin-top:2px;" /> <span id="tripOptInText"></span>`;
      form.insertBefore(wrap, form.querySelector(".newsletter-status"));
      $("tripOptIn").addEventListener("change", syncTripField);
    }
    const txt = $("tripOptInText");
    if (txt) txt.textContent = `Include my trip (${t.from.name} → ${t.to.name}, ${weekdayOfYmd(t.date)} ${monthDayOfYmd(t.date)}) so updates can cover it.`;
    syncTripField();
  }
  function syncTripField() {
    const form = document.querySelector("form[data-newsletter]");
    const box = $("tripOptIn");
    if (!form || !box) return;
    const field = form.querySelector('[name="trip"]');
    if (field) field.value = box.checked && lastTrip ? `${lastTrip.from.name} → ${lastTrip.vias.map((v) => v.name + " → ").join("")}${lastTrip.to.name} · leave ${lastTrip.date} ${lastTrip.hour}:00 (${startTz()}) · ${lastTrip.vehicle}` : "";
  }

  // ---------------- init ----------------
  function init() {
    wireLocationSearch($("fromInput"), $("fromResults"), (p) => setPlace("from", p));
    wireLocationSearch($("toInput"), $("toResults"), (p) => setPlace("to", p));
    $("fromInput").addEventListener("input", () => { if (places.from && $("fromInput").value !== places.from.name) $("fromPicked").textContent = ""; });
    $("toInput").addEventListener("input", () => { if (places.to && $("toInput").value !== places.to.name) $("toPicked").textContent = ""; });
    $("addVia").addEventListener("click", () => addViaRow());
    $("fromMyLocation").addEventListener("click", () => {
      if (!navigator.geolocation) return;
      $("fromMyLocation").textContent = "Finding you…";
      navigator.geolocation.getCurrentPosition(async (pos) => {
        const lat = pos.coords.latitude, lon = pos.coords.longitude;
        let name = "My location";
        try {
          const pt = await nwsGet(`${NWS_BASE}/points/${lat.toFixed(4)},${lon.toFixed(4)}`);
          const rel = pt.properties.relativeLocation && pt.properties.relativeLocation.properties;
          if (rel) name = `Near ${rel.city}, ${rel.state}`;
        } catch (e) { /* keep generic */ }
        $("fromMyLocation").innerHTML = "&#128205; Use my location";
        setPlace("from", { name, lat, lon, tz: LOCAL_TZ, approx: true });
      }, () => { $("fromMyLocation").innerHTML = "&#128205; Use my location"; $("formError").textContent = "We couldn't get your location. Type your town instead."; }, { timeout: 10000, maximumAge: 300000 });
    });
    $("tripForm").addEventListener("submit", (e) => { e.preventDefault(); run(); });

    // Starting values: a shared link, a saved trip, or the visitor's town.
    const q = new URLSearchParams(location.search);
    let auto = false;
    let date = null, hour = null, vehicle = null;
    if (q.get("from") && q.get("to")) {
      const f = parsePlace(q.get("from")), t = parsePlace(q.get("to"));
      if (f && t) {
        setPlace("from", f); setPlace("to", t);
        q.getAll("via").map(parsePlace).filter(Boolean).slice(0, MAX_VIAS).forEach((v) => addViaRow(v));
        date = q.get("date"); hour = q.get("hour"); vehicle = q.get("v");
        auto = true;
      }
    } else if (q.get("saved")) {
      const s = getSavedTrip();
      if (s) {
        setPlace("from", s.from); setPlace("to", s.to);
        (s.vias || []).slice(0, MAX_VIAS).forEach((v) => addViaRow(v));
        date = s.date; hour = s.hour; vehicle = s.vehicle;
        auto = true;
      }
    }
    if (!places.from) {
      const cur = getCurrentLocation();
      setPlace("from", { name: cur.name, lat: cur.lat, lon: cur.lon, tz: cur.tz });
    }
    // Towns saved on the older site have no time zone; look it up so departure
    // times are the start town's clock, not the visitor's.
    if (!validTimeZone(places.from.tz) && !auto) {
      const f = places.from;
      ensureTz(f).then(() => { if (places.from === f && f.tz) fillDateOptions(); });
    }
    fillDateOptions(date || undefined);
    if (hour != null && hour !== "" && isFinite(Number(hour))) $("hourSelect").value = String(Number(hour));
    if (vehicle === "van" || vehicle === "car") $("vehicleSelect").value = vehicle;
    let note = "";
    if (date && $("dateSelect").value !== date) note = "That trip's original date has passed or is more than 6 days out, so we checked the soonest day we can forecast.";
    if (auto) run({ fromUrl: true, note });
  }
  init();
})();
