// Lightweight seasonal theming, date-based, no config needed: a short prefix in the top bar, and on
// the home page this month's Etsy item as one card under "Go deeper". No floating decorations: on a
// weather and safety site they covered headings and the bottom menu (removed Oct. 1, 2026).
function getSeasonalInfo() {
  // Keep the emergency view plain: no seasonal jokes or decorations there.
  if (/^\/emergency/.test(location.pathname)) return null;
  const month = new Date().getMonth(); // 0 = Jan
  if (month === 8 || month === 9) { // September (lead-up) & October
    return {
      topbarPrefix: "🎃 SPOOKY SEASON · ",
      // October only: trick-or-treat hours, first thing in the top bar.
      topbarLink: month === 9 ? { text: "🎃 Trick-or-treat hours →", url: "/trick-or-treat" } : null,
      heroLine: "🎃 Storm season meets spooky season — same free, reliable forecast, just a little creepier out there.",
      promo: { text: "Throwing a Halloween party? Get our Haunted Happy Hour kit →", url: "https://www.etsy.com/listing/4582748412/halloween-party-kit-20-cocktail-recipes" },
    };
  }
  if (month === 10) { // November
    return {
      topbarPrefix: "🦃 HARVEST SEASON · ",
      heroLine: "🦃 Giving thanks for reliable weather data, free public sources, and safe travels this season.",
    };
  }
  if (month === 11) { // December
    return {
      topbarPrefix: "❄️ WINTER WATCH · ",
      heroLine: "❄️ Winter storm season is here — check road and travel conditions before you head out.",
    };
  }
  return null;
}

function applySeasonalTopbar() {
  const info = getSeasonalInfo();
  if (!info) return;
  const topbarSpan = document.querySelector(".topbar .wrap span");
  if (topbarSpan && !topbarSpan.dataset.seasonal) {
    topbarSpan.dataset.seasonal = "true";
    if (info.topbarLink && location.pathname.replace(/\/$/, "") !== info.topbarLink.url) {
      const a = document.createElement("a");
      a.href = info.topbarLink.url;
      a.textContent = info.topbarLink.text;
      a.style.cssText = "color:inherit; font-weight:800; text-decoration:underline; text-underline-offset:3px;";
      topbarSpan.textContent = " \u00b7 " + topbarSpan.textContent;
      topbarSpan.insertBefore(a, topbarSpan.firstChild);
    } else {
      topbarSpan.textContent = info.topbarPrefix + topbarSpan.textContent;
    }
  }
}

function applySeasonalHeroLine(targetId) {
  const info = getSeasonalInfo();
  if (!info) return;
  const el = document.getElementById(targetId);
  if (el) {
    el.textContent = info.heroLine;
    if (info.promo) {
      const link = document.createElement("a");
      link.href = info.promo.url;
      link.target = "_blank";
      link.rel = "noopener";
      link.textContent = info.promo.text;
      link.style.cssText = "display:block; margin-top:6px; color:#fff; text-decoration:underline; text-underline-offset:3px;";
      el.appendChild(link);
    }
    el.style.display = "block";
  }
}

applySeasonalTopbar();
