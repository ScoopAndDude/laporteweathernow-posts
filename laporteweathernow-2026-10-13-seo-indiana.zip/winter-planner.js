// The winter planner page, /winter-planner (added Oct. 11, 2026; Scoop: "do all of these").
//
//  1. Storm mode. When the National Weather Service has a winter watch, warning or advisory out
//     for La Porte County, the matching list from the planner moves to the top of the page. The
//     alerts shown are the Weather Service's own (name, area, times); the lists are the planner's.
//     If the Weather Service can't be reached, the page says so. It never says "none" without a
//     successful check.
//  2. The Winter Ready checklist: 20 steps from the planner, saved on this device only.
//  3. The Winter Ready Household certificate: shows once all 20 are checked, prints on one sheet.
//
// Uses timeutil.js (fmtInZone, zoneAbbrev, escapeHtml), locations.js (HOME_LOCATION) and
// weather.js (NWS_BASE, nwsGet, liveAlerts, sortAlerts, alertUntilText, alertEndMs, nwsPointPageUrl).
(function () {
  "use strict";

  var TZ = "America/Chicago";
  var PDF = "/la-porte-county-winter-storm-planner.pdf";
  function $(id) { return document.getElementById(id); }
  function esc(s) { return escapeHtml(String(s == null ? "" : s)); }
  function track(path, label) {
    try { if (typeof lpwnTrack === "function") lpwnTrack(path, label || ""); } catch (e) { /* never break the page */ }
  }
  function clock(d) { return fmtInZone(d, TZ, { hour: "numeric", minute: "2-digit" }) + " " + zoneAbbrev(d, TZ); }

  // Downloads: one count per click, labeled by which button or page picture it was.
  document.querySelectorAll("a[data-dl]").forEach(function (a) {
    a.addEventListener("click", function () { track(a.getAttribute("data-dl"), "/winter-planner#" + (a.getAttribute("data-where") || "")); });
  });

  /* ======================================================================= 1. Storm mode */

  // La Porte County's Weather Service zones: northern La Porte (the lakeshore), southern La Porte,
  // and the county itself (short-lived warnings like Snow Squall Warnings are drawn by county).
  // Same three as nws_snapshot.py in the posts repository.
  var ZONES = ["INZ103", "INZ203", "INC091"];
  var ALERTS_URL = NWS_BASE + "/alerts/active?zone=" + ZONES.join(",");
  var NWS_PAGE = nwsPointPageUrl(HOME_LOCATION.lat, HOME_LOCATION.lon);

  // Which planner list goes with which winter alert. Old and new Weather Service names both count:
  // in 2024 Wind Chill Warnings became Extreme Cold Warnings and Wind Chill Advisories became
  // Cold Weather Advisories.
  var KINDS = [
    { id: "act", test: /^(winter storm|blizzard|ice storm|lake effect snow|heavy snow) warning$/i },
    { id: "cold", test: /extreme cold|wind chill|cold weather advisory/i },
    { id: "drive", test: /winter weather advisory|snow squall|freezing (rain|drizzle|fog|spray)|lake effect snow advisory|blowing snow/i },
    { id: "prepare", test: /^(winter storm|blizzard|ice storm|lake effect snow|heavy snow) watch$/i },
  ];
  var STRANDED = "Stranded in snow? Stay in your car. Run the engine about 10 minutes an hour, crack a window, and keep the tailpipe clear of snow.";
  var LISTS = {
    act: { head: "Act now", page: 3, about: "the Watch vs. Warning action plan", items: [
      "Stay off the roads unless you have to go. " + STRANDED,
      "Stay in the safest, warmest room you have, away from windows and outside doors.",
      "Keep your supplies, medicines and warm layers within reach.",
      "Check on everyone at home, your pets, and neighbors who may need help.",
      "Keep following the Weather Service&rsquo;s updates and any official instructions.",
    ] },
    prepare: { head: "Get ready", page: 3, about: "the Watch vs. Warning action plan", items: [
      "Charge phones, power banks and anything else you&rsquo;ll need.",
      "Check food, water, medicines, heat and lights. Plan on at least 1 gallon of water per person per day for several days.",
      "Bring in or tie down things outside.",
      "Settle where you&rsquo;ll shelter and how your household will stay in touch.",
      "Fill the gas tank or charge the car, and plan to stay off the roads as it gets worse.",
      "Keep checking the forecast for where you&rsquo;re going. Lake-effect snow can bury Michigan City while La Porte stays dry.",
    ] },
    cold: { head: "Stay warm, safely", page: 4, about: "safe backup heat and carbon monoxide", items: [
      "<strong>Never</strong> run a generator, grill, camp stove or other fuel-burning gear inside the house or garage, and keep them away from doors, windows and vents.",
      "Test your carbon monoxide alarms. If one sounds or anyone feels sick, get everyone into fresh air and call 911.",
      "Space heaters go on a flat, steady surface, away from anything that can burn, and get turned off when you leave the room.",
      "Keep vents, chimneys and air intakes clear of snow and ice.",
      "Dress in layers, cover your head and hands, bring pets inside, and check on older neighbors.",
      "Power out or a line down? Call NIPSCO at 1-800-464-7726. For shelter, food or utility help, call 211.",
    ] },
    drive: { head: "If you have to drive", page: 6, about: "the winter car kit", items: [
      { when: /snow squall/i, html: "<strong>Snow Squall Warning:</strong> a burst of heavy snow and wind can drop visibility to near zero in seconds. Delay your trip, or get off at the next exit." },
      "Slow down, turn on your headlights and leave extra room. Don&rsquo;t slam on the brakes.",
      "Keep the winter car kit in the car: blankets, warm clothes, an ice scraper, a shovel, jumper cables, a flashlight, water, snacks and a phone charger.",
      "Keep the tank full or the car charged.",
      STRANDED,
      "Check the roads at <a href=\"https://511in.org\" target=\"_blank\" rel=\"noopener\">511in.org</a> before you go. In an emergency, call 911.",
    ] },
  };

  function kindOf(ev) {
    for (var i = 0; i < KINDS.length; i++) if (KINDS[i].test.test(ev)) return KINDS[i].id;
    return null;
  }
  function level(ev) { return /warning/i.test(ev) ? 3 : /watch/i.test(ev) ? 2 : 1; }
  function levelName(n) { return n === 3 ? "warning" : n === 2 ? "watch" : "advisory"; }

  // One line per kind of alert, even when the Weather Service sends it in pieces (one per zone).
  function groupAlerts(features) {
    var byEvent = {}, order = [];
    features.forEach(function (f) {
      var p = f.properties || {};
      var g = byEvent[p.event];
      if (!g) { g = byEvent[p.event] = { event: p.event, p: p, end: -Infinity, zones: {}, drawn: false }; order.push(g); }
      ((p.geocode && p.geocode.UGC) || []).forEach(function (z) { if (ZONES.indexOf(z) !== -1) g.zones[z] = true; });
      if (f.geometry) g.drawn = true;   // a warning drawn as a shape on the map, not a whole zone
      var end = alertEndMs(p);
      if (end > g.end) { g.end = end; g.p = p; }
    });
    return order;
  }
  function areaText(g) {
    var z = g.zones;
    if (z.INC091 && !z.INZ103 && !z.INZ203 && g.drawn) return "part of La Porte County";
    if (z.INC091 || (z.INZ103 && z.INZ203)) return "La Porte County";
    if (z.INZ103) return "northern La Porte County";
    if (z.INZ203) return "southern La Porte County";
    return "La Porte County";
  }
  function whenText(p) {
    var start = Date.parse(p.onset || p.effective || "");
    var from = start && start > Date.now() + 5 * 60000 ? "from " + fmtInZone(new Date(start), TZ, { weekday: "short", hour: "numeric", minute: "2-digit" }) + " " + zoneAbbrev(new Date(start), TZ) + " " : "";
    return from + alertUntilText(p, TZ);
  }

  var box = $("stormBox"), now = $("stormNow"), section = $("storm");
  var hero = document.querySelector(".wp-hero");
  var lastCheck = 0, checking = false;

  function badge(text) { return '<span class="wp-storm-badge">' + esc(text) + "</span> "; }

  function stormOff() {
    document.documentElement.classList.remove("wp-storm-on");
    now.hidden = true;
    now.innerHTML = "";
    // back below the hero, where it sits when all is calm
    if (hero && section.previousElementSibling !== hero) hero.parentNode.insertBefore(section, hero.nextSibling);
  }

  function showError() {
    stormOff();
    box.className = "wp-storm unknown";
    box.innerHTML = '<p class="wp-storm-line">' + badge("Storm mode") +
      "We couldn&rsquo;t reach the National Weather Service just now, so we can&rsquo;t tell whether a winter alert is out. " +
      'Check our <a href="/emergency">Alerts page</a> or <a href="' + esc(NWS_PAGE) + '" target="_blank" rel="noopener">weather.gov</a>. ' +
      '<button type="button" class="wp-retry" id="stormRetry">Try again</button></p>';
    $("stormRetry").addEventListener("click", function () { check(true); });
  }

  function show(features, at) {
    var winter = [], other = [];
    groupAlerts(features).forEach(function (g) { (kindOf(g.event) ? winter : other).push(g); });
    var otherLine = other.length
      ? '<p class="wp-storm-also">Also in effect: ' + other.map(function (g) { return "<strong>" + esc(g.event) + "</strong>"; }).join(", ") +
        '. <a href="/emergency">See them on our Alerts page</a>.</p>'
      : "";

    if (!winter.length) {
      stormOff();
      box.className = "wp-storm calm";
      box.innerHTML = '<p class="wp-storm-line">' + badge("Storm mode: off") +
        "No winter storm, snow, ice or cold alerts for La Porte County right now (checked " + esc(clock(at)) + "). " +
        "When the National Weather Service issues one, storm mode turns on here and the right checklist moves to the top.</p>" + otherLine;
      return;
    }

    var top = 0;
    winter.forEach(function (g) { top = Math.max(top, level(g.event)); });
    document.documentElement.classList.add("wp-storm-on");
    box.className = "wp-storm on " + levelName(top);
    box.innerHTML = '<p class="wp-storm-line">' + badge("Storm mode: on") +
      "From the National Weather Service, checked " + esc(clock(at)) + ":</p>" +
      '<ul class="wp-alerts">' + winter.map(function (g) {
        return '<li class="' + levelName(level(g.event)) + '"><strong>' + esc(g.event) + "</strong> for " + esc(areaText(g)) +
          (whenText(g.p) ? ", " + esc(whenText(g.p)) : "") + "</li>";
      }).join("") + "</ul>" +
      '<p class="wp-storm-more"><a href="/emergency">Read the full alert and what it means</a> &middot; ' +
      '<a href="' + esc(NWS_PAGE) + '" target="_blank" rel="noopener">NWS forecast for La Porte &#8599;</a></p>' + otherLine;

    // The planner's lists that fit, most urgent first.
    var kinds = {};
    winter.forEach(function (g) {
      var k = kindOf(g.event);
      var e = kinds[k] || (kinds[k] = { id: k, top: 0, events: [] });
      e.top = Math.max(e.top, level(g.event));
      e.events.push(g.event);
    });
    var order = KINDS.map(function (k) { return k.id; });
    var cards = Object.keys(kinds).map(function (k) { return kinds[k]; }).sort(function (a, b) {
      return (b.top - a.top) || (order.indexOf(a.id) - order.indexOf(b.id));
    });
    now.innerHTML = cards.map(function (c) {
      var list = LISTS[c.id];
      var items = list.items.filter(function (it) {
        return typeof it === "string" || c.events.some(function (ev) { return it.when.test(ev); });
      }).map(function (it) { return "<li>" + (typeof it === "string" ? it : it.html) + "</li>"; }).join("");
      return '<div class="wp-now-card ' + levelName(c.top) + '">' +
        '<div class="wp-now-kicker">' + c.events.map(esc).join(" &middot; ") + "</div>" +
        "<h3>" + esc(list.head) + "</h3>" +
        '<ul class="wp-ticks">' + items + "</ul>" +
        '<p class="wp-now-src">From page ' + list.page + " of the planner, " + esc(list.about) + '. <a href="' + PDF + "#page=" + list.page +
        '" target="_blank" rel="noopener" data-dl="planner-download" data-where="storm-' + c.id + '">Open it</a></p></div>';
    }).join("");
    now.querySelectorAll("a[data-dl]").forEach(function (a) {
      a.addEventListener("click", function () { track("planner-download", "/winter-planner#" + a.getAttribute("data-where")); });
    });
    now.hidden = false;
    // In a storm, this goes first, above the page's heading.
    if (hero && section.nextElementSibling !== hero) hero.parentNode.insertBefore(section, hero);
  }

  function check(fromButton) {
    if (checking) return;
    checking = true;
    if (fromButton) {
      box.className = "wp-storm checking";
      box.innerHTML = '<p class="wp-storm-line">' + badge("Storm mode") + '<span class="loading-text">Checking the National Weather Service&hellip;</span></p>';
    }
    nwsGet(ALERTS_URL, 15000).then(function (data) {
      if (!data || !Array.isArray(data.features)) throw new Error("no alert list");
      lastCheck = Date.now();
      show(sortAlerts(liveAlerts(data.features)), new Date());
    }).catch(function () {
      showError();
    }).then(function () { checking = false; });
  }

  check(false);
  // Keep it current while the page is open: every 10 minutes, and when someone comes back to it.
  setInterval(function () { if (!document.hidden) check(false); }, 10 * 60000);
  document.addEventListener("visibilitychange", function () {
    if (!document.hidden && Date.now() - lastCheck > 10 * 60000) check(false);
  });

  /* ======================================================================= 2. Winter Ready checklist */

  var KEY = "lpwn_winter_ready";
  var STEPS = [
    { group: "Home", items: [
      ["heat", "Furnace or heating system serviced, and the chimney or vents inspected"],
      ["alarms", "Smoke and carbon monoxide alarms tested"],
      ["pipes", "Pipes that could freeze insulated"],
      ["drafts", "Weather stripping on doors and windows checked"],
      ["roof", "Roof and gutters checked"],
      ["shovel", "Snow shovel and ice melt ready"],
    ] },
    { group: "Supplies", items: [
      ["water", "Drinking water stored: at least 1 gallon per person per day, for several days"],
      ["food", "Shelf-stable food stocked, plus baby and pet needs"],
      ["lights", "Flashlights checked, with spare batteries"],
      ["firstaid", "First-aid kit stocked"],
      ["meds", "Medicines and refills reviewed"],
      ["power", "Phones and power banks charged, and backup power checked"],
      ["pets", "A plan for pets or livestock: feed, water and shelter"],
    ] },
    { group: "Alerts and plan", items: [
      ["radio", "NOAA Weather Radio set to La Porte County, code 018091"],
      ["rave", 'Signed up for La Porte County&rsquo;s free <a href="/emergency#county-alerts">RAVE alerts</a> (Smart911)'],
      ["heatrules", "Everyone at home knows: never use a generator, grill or camp stove indoors or in the garage"],
      ["plan", "A shelter spot, an out-of-town contact and a meeting place picked"],
      ["cards", 'The <a href="' + PDF + '#page=8" target="_blank" rel="noopener">storm card</a> on the fridge, and a wallet card in each car'],
    ] },
    { group: "Car", items: [
      ["carkit", "Winter car kit packed: blankets, warm clothes, scraper, shovel, jumper cables, flashlight, water, snacks and a phone charger"],
      ["tank", "Tank kept full, or the car charged, when a storm is coming"],
    ] },
  ];
  var IDS = [];
  STEPS.forEach(function (g) { g.items.forEach(function (it) { IDS.push(it[0]); }); });
  var TOTAL = IDS.length;

  function load() {
    try {
      var s = JSON.parse(localStorage.getItem(KEY) || "null");
      if (s && s.v === 1 && s.done && typeof s.done === "object") return s;
    } catch (e) { /* private window or blocked storage: start fresh */ }
    return { v: 1, done: {}, name: "", finishedAt: 0, started: false };
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* the checks still work, just not remembered */ }
  }
  var state = load();
  function doneCount() { return IDS.filter(function (id) { return state.done[id]; }).length; }

  var list = $("readyList");
  list.innerHTML = STEPS.map(function (g) {
    return '<fieldset class="wp-group"><legend>' + esc(g.group) + "</legend>" + g.items.map(function (it) {
      var on = !!state.done[it[0]];
      return '<label class="wp-item' + (on ? " done" : "") + '"><input type="checkbox" data-step="' + it[0] + '"' + (on ? " checked" : "") + " /><span>" + it[1] + "</span></label>";
    }).join("") + "</fieldset>";
  }).join("");

  function season(ms) {
    var y = Number(fmtInZone(new Date(ms), TZ, { year: "numeric" }));
    var m = Number(fmtInZone(new Date(ms), TZ, { month: "numeric" }));
    var first = m >= 7 ? y : y - 1;
    return "La Porte County · Winter " + first + "–" + String(first + 1).slice(-2);
  }
  function updateCert(scroll) {
    var wrap = $("certWrap");
    var complete = doneCount() === TOTAL;
    if (!complete) { wrap.hidden = true; return; }
    var at = state.finishedAt || Date.now();
    $("certName").textContent = state.name || "This household";
    $("certDate").textContent = fmtInZone(new Date(at), TZ, { month: "long", day: "numeric", year: "numeric" });
    $("certSeason").textContent = season(at);
    wrap.hidden = false;
    if (scroll && wrap.scrollIntoView) wrap.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  function updateCount() {
    var n = doneCount();
    $("readyBar").style.width = Math.round(100 * n / TOTAL) + "%";
    $("readyCount").textContent = n === TOTAL ? "All " + TOTAL + " done. You're Winter Ready!" : n + " of " + TOTAL + " done";
  }

  list.addEventListener("change", function (e) {
    var input = e.target;
    if (!input || !input.getAttribute || !input.getAttribute("data-step")) return;
    var id = input.getAttribute("data-step");
    var wasComplete = doneCount() === TOTAL;
    if (input.checked) state.done[id] = true; else delete state.done[id];
    input.parentNode.classList.toggle("done", input.checked);
    if (!state.started) { state.started = true; track("winter-ready-start", "/winter-planner"); }
    var complete = doneCount() === TOTAL;
    if (complete && !wasComplete) {
      state.finishedAt = Date.now();
      track("winter-ready-complete", "/winter-planner");
    }
    if (!complete) state.finishedAt = 0;
    save();
    updateCount();
    updateCert(complete && !wasComplete);
  });

  var nameBox = $("readyName");
  nameBox.value = state.name || "";
  nameBox.addEventListener("input", function () {
    state.name = nameBox.value.replace(/\s+/g, " ").trim().slice(0, 60);
    save();
    if (doneCount() === TOTAL) $("certName").textContent = state.name || "This household";
  });

  // "Start over" asks once more on the button itself instead of a pop-up.
  var reset = $("readyReset"), armed = 0;
  reset.addEventListener("click", function () {
    if (!armed) {
      armed = setTimeout(function () { armed = 0; reset.textContent = "Start over"; }, 4000);
      reset.textContent = "Tap again to clear all " + TOTAL;
      return;
    }
    clearTimeout(armed);
    armed = 0;
    reset.textContent = "Start over";
    state.done = {};
    state.finishedAt = 0;
    save();
    list.querySelectorAll("input[data-step]").forEach(function (b) { b.checked = false; b.parentNode.classList.remove("done"); });
    updateCount();
    updateCert(false);
  });

  updateCount();
  updateCert(false);

  /* ======================================================================= 3. Printing the certificate */

  // Only the certificate prints, sideways on one sheet: every element on the way down to it is
  // marked, and the print style hides everything else.
  var printStyle = null;
  function printCleanup() {
    document.documentElement.classList.remove("wp-print-cert");
    document.querySelectorAll(".wp-cert-path").forEach(function (el) { el.classList.remove("wp-cert-path"); });
    if (printStyle && printStyle.parentNode) printStyle.parentNode.removeChild(printStyle);
    printStyle = null;
  }
  window.addEventListener("afterprint", printCleanup);
  $("certPrint").addEventListener("click", function () {
    printCleanup();
    for (var el = $("cert").parentNode; el && el !== document.documentElement; el = el.parentNode) el.classList.add("wp-cert-path");
    printStyle = document.createElement("style");
    printStyle.textContent = "@page { size: letter landscape; margin: 0.4in; }";
    document.head.appendChild(printStyle);
    document.documentElement.classList.add("wp-print-cert");
    track("winter-ready-certificate", "/winter-planner");
    window.print();
  });
})();
