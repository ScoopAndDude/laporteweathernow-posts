(function () {
  var TOWNS = [
    { name: "La Porte", lat: 41.6106, lon: -86.7226 },
    { name: "Michigan City", lat: 41.7075, lon: -86.895 },
    { name: "Valparaiso", lat: 41.4731, lon: -87.0611 },
    { name: "South Bend", lat: 41.6764, lon: -86.252 },
  ];
  var JOBS = {
    spray: { label: "Spraying", minWind: 3, maxWind: 12, maxGust: 18, maxPop: 25, minTemp: 45, maxTemp: 90 },
    // Oct. 11, 2026: past the season's cutoff, dicamba is STOP all day, the same as the 5 AM
    // calls (workday.js). Every town on this desk is in Indiana, where the Office of Indiana
    // State Chemist's cutoff is June 12; the label's own last day is June 30.
    dicamba: { label: "Dicamba", minWind: 3, maxWind: 10, maxGust: 12, maxPop: 20, minTemp: 50, maxTemp: 85, lastDay: "06-12", lastDayText: "June 12", lastDayWho: "Indiana" },
    hay: { label: "Hay", minWind: 0, maxWind: 20, maxGust: 28, maxPop: 20, minTemp: 50, maxTemp: 95 },
  };
  var state = { town: TOWNS[0], job: "spray", animal: "dairy", slots: [], zone: "America/Chicago", alerts: [] };

  function getJson(url) {
    return fetch(url, { headers: { Accept: "application/geo+json" } }).then(function (res) {
      if (!res.ok) throw new Error("Weather Service " + res.status);
      return res.json();
    });
  }

  function hourIn(iso, zone) {
    var parts = new Intl.DateTimeFormat("en-US", {
      timeZone: zone,
      hour: "numeric",
      hourCycle: "h23",
      weekday: "short",
    }).formatToParts(new Date(iso));
    var hour = 0;
    var weekday = "";
    parts.forEach(function (part) {
      if (part.type === "hour") hour = Number(part.value);
      if (part.type === "weekday") weekday = part.value;
    });
    return { hour: hour, weekday: weekday };
  }

  function hourLabel(hour) {
    var h = hour % 12 || 12;
    return h + (hour < 12 || hour === 24 ? " AM" : " PM");
  }

  function mph(value) {
    var nums = String(value || "").match(/\d+/g);
    if (!nums || !nums.length) return 0;
    return Math.max.apply(null, nums.map(Number));
  }

  function rh(tempF, dewF) {
    var c = function (f) { return ((f - 32) * 5) / 9; };
    var es = function (t) { return Math.exp((17.625 * t) / (t + 243.04)); };
    var ratio = es(c(dewF)) / es(c(tempF));
    return Math.max(5, Math.min(100, Math.round(ratio * 100)));
  }

  function thi(tempF, dewF) {
    var humidity = rh(tempF, dewF);
    return tempF - (0.55 - 0.0055 * humidity) * (tempF - 58);
  }

  function windWords(slot, gust) {
    var speed = gust ? slot.gust : slot.wind;
    var what = gust ? "Gusts" : "Wind";
    if (slot.dir) return what + " from the " + slot.dir + " at " + speed + " mph";
    return what + " " + speed + " mph";
  }

  function pastSeason(limits, dayKey) {
    return !!(limits.lastDay && dayKey && dayKey.slice(5) > limits.lastDay);
  }

  function seasonWords(limits) {
    return "Past " + limits.lastDayText + ", " + limits.lastDayWho + "'s cutoff: no more spraying this season";
  }

  function blockReason(slot, limits) {
    if (pastSeason(limits, slot.dayKey)) return seasonWords(limits);
    if (slot.hour < 6 || slot.hour >= 20) return "Outside daylight";
    if (slot.pop >= limits.maxPop) return "Rain " + slot.pop + "%";
    if (limits.minWind > 0 && slot.wind < limits.minWind) return windWords(slot) + " — still air, inversion risk";
    if (slot.wind > limits.maxWind) return windWords(slot);
    if (slot.gust > limits.maxGust) return windWords(slot, true);
    if (slot.temp < limits.minTemp) return slot.temp + "° is too cool";
    if (slot.temp > limits.maxTemp) return slot.temp + "° is too hot";
    return null;
  }

  function herdRisk(animal, slot) {
    var index = Math.round(thi(slot.temp, slot.dew));
    var chill = Math.round(slot.temp - slot.wind * 0.7);
    var wet = slot.pop >= 40;
    if (animal === "barn") {
      if (index >= 85 || (index >= 79 && slot.wind <= 5)) return { risk: "danger", note: "THI " + index + ". Wind " + slot.wind + " mph — fans and water." };
      if (index >= 72) return { risk: "warm", note: "THI " + index + ". Watch the barn." };
      if (slot.temp <= 25) return { risk: "cold", note: slot.temp + "°. Check barn heat and water lines." };
      return { risk: "fine", note: "THI " + index + "." };
    }
    if (animal === "calf") {
      if (chill <= 32 || (slot.temp <= 45 && (wet || slot.wind >= 12))) return { risk: "cold", note: slot.temp + "°, wind " + slot.wind + " mph. Dry bedding, out of the wind." };
      if (index >= 76) return { risk: "danger", note: "THI " + index + ". Shade and water for young stock." };
      if (index >= 68) return { risk: "warm", note: "THI " + index + ". Watch calves and fresh cows." };
      return { risk: "fine", note: slot.temp + "°." };
    }
    if (animal === "beef") {
      if (chill <= 5) return { risk: "cold", note: "Wind chill about " + chill + "°. Windbreaks and dry bedding." };
      if (index >= 84) return { risk: "danger", note: "THI " + index + ". Shade and water." };
      if (index >= 75) return { risk: "warm", note: "THI " + index + "." };
      return { risk: "fine", note: slot.temp + "°." };
    }
    if (index >= 79) return { risk: "danger", note: "THI " + index + ". Fans, shade, and extra water." };
    if (index >= 68) return { risk: "warm", note: "THI " + index + ". Milk drops off from here." };
    if (chill <= 15) return { risk: "cold", note: "Wind chill about " + chill + "°. Windbreaks for the herd." };
    return { risk: "fine", note: "THI " + index + "." };
  }

  function todayKey() {
    return new Intl.DateTimeFormat("en-CA", { timeZone: state.zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  }

  function todaySlots() {
    var key = todayKey();
    return state.slots.filter(function (slot) { return slot.dayKey === key && slot.hour >= 6 && slot.hour <= 20; });
  }

  function workCall(slots) {
    var limits = JOBS[state.job];
    if (pastSeason(limits, todayKey())) {
      return {
        tone: "stop",
        title: "STOP — past " + limits.lastDayWho + "'s " + limits.lastDayText + " cutoff",
        detail: seasonWords(limits) + ". (The label's own last day is June 30.)",
      };
    }
    var nowHour = hourIn(new Date().toISOString(), state.zone).hour;
    var open = null;
    var later = null;
    var run = null;
    slots.forEach(function (slot) {
      var why = blockReason(slot, limits);
      if (!why) {
        if (!run) run = { start: slot, end: slot };
        else run.end = slot;
      } else if (run) {
        if (nowHour >= run.start.hour && nowHour <= run.end.hour) open = run;
        else if (run.start.hour > nowHour && !later) later = run;
        run = null;
      }
    });
    if (run) {
      if (nowHour >= run.start.hour && nowHour <= run.end.hour) open = run;
      else if (run.start.hour > nowHour && !later) later = run;
    }
    if (open) {
      return { tone: "go", title: "GO till " + hourLabel(open.end.hour + 1), detail: "Window is open now. Plan to wrap by " + hourLabel(open.end.hour + 1) + "." };
    }
    if (later) {
      var nowSlot = slots.filter(function (slot) { return slot.hour === nowHour; })[0] || slots[0];
      var why = nowSlot ? blockReason(nowSlot, limits) : null;
      return {
        tone: "delay",
        title: "DELAY till " + later.start.hourLabel,
        detail: (why ? why + ". " : "") + "The workable stretch starts at " + later.start.hourLabel + ".",
      };
    }
    return { tone: "stop", title: "STOP — no workable window today", detail: "Limits are blown for the rest of the daylight hours." };
  }

  function herdCall(slots) {
    var marks = slots.map(function (slot) {
      var mark = herdRisk(state.animal, slot);
      return { slot: slot, risk: mark.risk, note: mark.note };
    });
    var rank = { fine: 0, warm: 1, cold: 2, danger: 3 };
    var worst = "fine";
    marks.forEach(function (mark) { if (rank[mark.risk] > rank[worst]) worst = mark.risk; });
    var word = worst === "fine" ? "Fine" : worst === "warm" ? "Warm" : worst === "danger" ? "Danger" : "Cold";
    var start = null;
    var end = null;
    var runS = null;
    var runE = null;
    var best = 0;
    marks.forEach(function (mark) {
      if (mark.risk !== worst) { runS = null; return; }
      if (!runS) runS = mark.slot;
      runE = mark.slot;
      var len = runE.hour - runS.hour;
      if (len >= best) { best = len; start = runS; end = runE; }
    });
    var names = { dairy: "Dairy cows", calf: "Calves and fresh cows", beef: "Beef cows", barn: "Hogs and poultry" };
    var title = worst === "fine" || !start ? "Fine through the day" : start === end ? word + " at " + start.hourLabel : word + " " + start.hourLabel + "–" + end.hourLabel;
    var peak = marks.filter(function (mark) { return mark.risk === worst; })[0];
    return { tone: worst, title: title, detail: names[state.animal] + ". " + (peak ? peak.note : ""), marks: marks };
  }

  function render() {
    var root = document.getElementById("desk");
    if (!root) return;
    var slots = todaySlots();
    var alertHtml = state.alerts.map(function (alert) {
      var warning = /warning/i.test(alert.event);
      return '<article class="desk-alert ' + (warning ? "is-stop" : "is-delay") + '"><p class="kicker">National Weather Service</p><h2>' + alert.event + "</h2></article>";
    }).join("");
    var call = state.job === "livestock" ? herdCall(slots) : workCall(slots);
    var hours = state.job === "livestock"
      ? herdCall(slots).marks.map(function (mark) {
          return '<div class="hour is-' + mark.risk + '" title="' + mark.note.replace(/"/g, "") + '"><div>' + mark.slot.hourLabel + "</div><strong>" + mark.slot.temp + "°</strong><div>" + (mark.risk === "fine" ? "Fine" : mark.risk === "warm" ? "Warm" : mark.risk === "danger" ? "Danger" : "Cold") + "</div></div>";
        }).join("")
      : slots.map(function (slot) {
          var why = blockReason(slot, JOBS[state.job]);
          var open = !why;
          return '<div class="hour ' + (open ? "is-fine" : "is-danger") + '" title="' + (why || slot.dir + " " + slot.wind + " mph").replace(/"/g, "") + '"><div>' + slot.hourLabel + "</div><strong>" + slot.temp + "°</strong>" + (slot.dir ? "<div>" + slot.dir + "</div>" : "") + "<div>" + (open ? "Open" : "Stop") + "</div></div>";
        }).join("");
    var animals = state.job === "livestock"
      ? '<div class="picks" id="animals">' +
        ["dairy", "calf", "beef", "barn"].map(function (id) {
          var label = { dairy: "Dairy cows", calf: "Calves and fresh cows", beef: "Beef cows", barn: "Hogs and poultry" }[id];
          return '<button type="button" data-animal="' + id + '"' + (state.animal === id ? " aria-pressed=\"true\"" : "") + ">" + label + "</button>";
        }).join("") + "</div>"
      : "";
    root.innerHTML =
      alertHtml +
      '<article class="desk-call is-' + call.tone + '"><p class="kicker">' + (state.job === "livestock" ? "Herd" : JOBS[state.job].label) + " · " + state.town.name + "</p><h2>" + call.title + "</h2><p>" + call.detail + '</p><div class="hours">' + hours + "</div></article>" +
      animals;
    bind();
  }

  function bind() {
    var animals = document.getElementById("animals");
    if (!animals) return;
    animals.addEventListener("click", function (event) {
      var button = event.target.closest("button");
      if (!button) return;
      state.animal = button.getAttribute("data-animal");
      render();
    });
  }

  function load() {
    var town = state.town;
    var root = document.getElementById("desk");
    if (root) root.innerHTML = '<p class="desk-wait">Reading the National Weather Service…</p>';
    getJson("https://api.weather.gov/points/" + town.lat.toFixed(4) + "," + town.lon.toFixed(4))
      .then(function (point) {
        var props = point.properties || {};
        state.zone = props.timeZone || "America/Chicago";
        return Promise.all([
          getJson(props.forecastHourly),
          getJson("https://api.weather.gov/alerts/active?point=" + town.lat.toFixed(4) + "," + town.lon.toFixed(4)).catch(function () { return { features: [] }; }),
        ]);
      })
      .then(function (pair) {
        var periods = ((pair[0].properties || {}).periods) || [];
        state.slots = periods.map(function (period) {
          var bag = hourIn(period.startTime, state.zone);
          var dir = String(period.windDirection || "").trim().toUpperCase();
          var wind = mph(period.windSpeed);
          var dew = period.dewpoint && typeof period.dewpoint.value === "number" ? Math.round((period.dewpoint.value * 9) / 5 + 32) : (period.temperature || 60) - 8;
          return {
            hour: bag.hour,
            hourLabel: hourLabel(bag.hour),
            dayKey: new Intl.DateTimeFormat("en-CA", { timeZone: state.zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(period.startTime)),
            temp: typeof period.temperature === "number" ? period.temperature : 60,
            wind: wind,
            gust: period.windGust ? mph(period.windGust) : wind,
            dir: !dir || dir === "VARIABLE" ? "" : dir,
            pop: (period.probabilityOfPrecipitation && period.probabilityOfPrecipitation.value) || 0,
            dew: dew,
          };
        });
        state.alerts = ((pair[1].features) || []).map(function (feature) {
          return { event: (feature.properties && feature.properties.event) || "" };
        }).filter(function (alert) { return alert.event; }).slice(0, 2);
        render();
      })
      .catch(function () {
        if (root) root.innerHTML = '<p class="desk-wait">The National Weather Service didn\'t answer. Try again in a minute.</p>';
      });
  }

  document.getElementById("jobs").addEventListener("click", function (event) {
    var button = event.target.closest("button");
    if (!button) return;
    state.job = button.getAttribute("data-job");
    document.querySelectorAll("#jobs button").forEach(function (item) {
      item.setAttribute("aria-pressed", item === button ? "true" : "false");
    });
    render();
  });
  document.getElementById("towns").addEventListener("click", function (event) {
    var button = event.target.closest("button");
    if (!button) return;
    state.town = TOWNS[Number(button.getAttribute("data-town"))];
    document.querySelectorAll("#towns button").forEach(function (item) {
      item.setAttribute("aria-pressed", item === button ? "true" : "false");
    });
    load();
  });
  load();
})();
