// Free watch & warning alerts (alerts.js) arrive through OneSignal, whose code has to run in this
// same service worker (a site gets one). If it can't load (offline, blocked), everything below
// still installs, so the offline Emergency page never depends on it.
try { importScripts("https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.sw.js"); } catch (e) { /* alerts unavailable */ }

const CACHE_NAME = "lpwn-4b8bab9d2f";
// The emergency view is cached so its safety checklists still open with no signal.
const CORE_ASSETS = [
  "/",
  "/emergency",
  "/style.css?v=1d1414fff3",
  "/seasonal.js?v=08cedbd13c",
  "/pwa.js?v=dcad0f9e29",
  "/track.js?v=0096f183bc",
  "/timeutil.js?v=6bcd3a6745",
  "/locations.js?v=c2179a9b68",
  "/weather.js?v=6e4c425e2a",
  "/manifest.json?v=65534f7b8e",
  "/icon-192.png?v=d11ca8883a",
  "/icon-512.png?v=94002f347f",
];

// If saving the offline copy fails (say, on a weak signal), the install fails too, so the
// previous version keeps running with its offline copy until a later try succeeds.
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Only the site's own files are cached. Weather APIs, radar loops and map tiles
// always go straight to the network so forecasts are never stale and the radar
// GIF (new URL every refresh) can't pile up in storage.
self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET" || new URL(req.url).origin !== self.location.origin) return;

  event.respondWith(
    fetch(req)
      .then((response) => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy)).catch(() => {});
        }
        return response;
      })
      .catch(async () => {
        // Offline: pages opened with a query (e.g. /emergency?lat=...) still get
        // their cached copy; the page reads the query itself. Scripts and styles are
        // requested as name.js?v=<version>; if this exact version isn't saved, any
        // saved version of the file is better than none.
        const cached = (await caches.match(req, { ignoreSearch: req.mode === "navigate" })) ||
          (req.mode !== "navigate" ? await caches.match(req, { ignoreSearch: true }) : undefined);
        if (cached) return cached;
        // A page never opened on this device isn't saved, so offline it opens the Emergency view.
        if (req.mode === "navigate") return (await caches.match("/emergency")) || (await caches.match("/")) || Response.error();
        return Response.error();
      })
  );
});
