// Lightweight seasonal theming — date-based, no config needed.
// Halloween (Oct) fits our black/orange palette natively; Thanksgiving/
// harvest (Nov) gets a warm callout; otherwise the site stays as-is.
function getSeasonalInfo() {
  // Keep the emergency view plain: no seasonal jokes or decorations there.
  if (/^\/emergency/.test(location.pathname)) return null;
  const month = new Date().getMonth(); // 0 = Jan
  if (month === 8 || month === 9) { // September (lead-up) & October
    return {
      topbarPrefix: "🎃 SPOOKY SEASON · ",
      heroLine: "🎃 Storm season meets spooky season — same free, reliable forecast, just a little creepier out there.",
      promo: { text: "Throwing a Halloween party? Get our Haunted Happy Hour kit →", url: "https://www.etsy.com/listing/4582748412/halloween-party-kit-20-cocktail-recipes" },
    };
  }
  if (month === 10) { // November
    return {
      topbarPrefix: "🦃 HARVEST SEASON · ",
      heroLine: "🦃 Giving thanks for reliable weather data, free public sources, and safe travels this season.",
    };
  }
  if (month === 11) { // December
    return {
      topbarPrefix: "❄️ WINTER WATCH · ",
      heroLine: "❄️ Winter storm season is here — check road and travel conditions before you head out.",
    };
  }
  return null;
}

function applySeasonalTopbar() {
  const info = getSeasonalInfo();
  if (!info) return;
  const topbarSpan = document.querySelector(".topbar .wrap span");
  if (topbarSpan && !topbarSpan.dataset.seasonal) {
    topbarSpan.textContent = info.topbarPrefix + topbarSpan.textContent;
    topbarSpan.dataset.seasonal = "true";
  }
}

function applySeasonalHeroLine(targetId) {
  const info = getSeasonalInfo();
  if (!info) return;
  const el = document.getElementById(targetId);
  if (el) {
    el.textContent = info.heroLine;
    if (info.promo) {
      const link = document.createElement("a");
      link.href = info.promo.url;
      link.target = "_blank";
      link.rel = "noopener";
      link.textContent = info.promo.text;
      link.style.cssText = "display:block; margin-top:6px; color:#fff; text-decoration:underline; text-underline-offset:3px;";
      el.appendChild(link);
    }
    el.style.display = "block";
  }
}

function injectHalloweenDecor() {
  if (/^\/emergency/.test(location.pathname)) return;
  const month = new Date().getMonth();
  if (month !== 8 && month !== 9) return; // only Sept & Oct

  const style = document.createElement("style");
  style.textContent = `
    .hw-decor { position: fixed; z-index: 50; pointer-events: none; user-select: none; filter: drop-shadow(0 6px 8px rgba(0,0,0,0.45)); }
    .hw-spider { top: 0; left: 6%; font-size: 34px; transform-origin: top center; animation: hwSwing 4s ease-in-out 1; }
    @media (prefers-reduced-motion: reduce) { .hw-spider { animation: none; } }
    .hw-spider .hw-thread { position: absolute; left: 50%; top: -60px; width: 1px; height: 60px; background: rgba(0,0,0,0.35); }
    .hw-web-left { top: 0; left: 0; font-size: 64px; opacity: 0.85; transform: rotate(0deg); }
    .hw-web-right { top: 0; right: 0; font-size: 64px; opacity: 0.85; transform: scaleX(-1); }
    .hw-pumpkin-left { bottom: 0; left: 12px; font-size: 30px; }
    .hw-pumpkin-right { bottom: 0; right: 12px; font-size: 30px; }
    @keyframes hwSwing {
      0%, 100% { transform: rotate(-6deg); }
      50% { transform: rotate(6deg); }
    }
    @media (max-width: 700px) {
      .hw-web-left, .hw-web-right { font-size: 40px; }
      .hw-spider { font-size: 24px; left: 4%; }
      .hw-pumpkin-left, .hw-pumpkin-right { font-size: 22px; }
    }
  `;
  document.head.appendChild(style);

  const decor = document.createElement("div");
  decor.setAttribute("aria-hidden", "true");   // decoration only; screen readers skip it
  decor.innerHTML = `
    <div class="hw-decor hw-web-left">🕸️</div>
    <div class="hw-decor hw-web-right">🕸️</div>
    <div class="hw-decor hw-spider"><div class="hw-thread"></div>🕷️</div>
    <div class="hw-decor hw-pumpkin-left">🎃</div>
    <div class="hw-decor hw-pumpkin-right">🎃</div>
  `;
  document.body.appendChild(decor);
}

applySeasonalTopbar();
injectHalloweenDecor();
