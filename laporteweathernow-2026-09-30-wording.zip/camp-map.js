// Camp map: free campsites, rest/service areas, and dog parks from OpenStreetMap.
// Campsites a mapper has tagged free (fee=no) always list first; every result
// links to its map source and to a place to check the overnight rules.

const OVERPASS_MIRRORS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://overpass.openstreetmap.ru/api/interpreter",
];
const PAGE_SIZE = 25;
const COLORS = { free: "#2f7d4f", unknown: "#e8963d", paid: "#8a8a8a", rest: "#3a6ea5", dogpark: "#8e44ad" };

const state = {
  center: null,          // {name, lat, lon}
  radius: 80000,
  places: [],            // normalized results for the current center/radius
  fee: "all",            // all | free | nopaid
  dog: "any",            // any | yes
  types: { camp: true, rest: true, dogpark: false, private: false },
  shown: PAGE_SIZE,
  cache: new Map(),
};

let map, markerLayer;
const markers = new Map();

function initMap(lat, lon) {
  map = L.map("campMap", { scrollWheelZoom: false }).setView([lat, lon], 8);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors",
    maxZoom: 18,
  }).addTo(map);
  markerLayer = L.layerGroup().addTo(map);
}

async function fetchOverpass(query) {
  let lastError;
  for (const endpoint of OVERPASS_MIRRORS) {
    try {
      // The query gives the server 25 s, so the browser waits a little longer than that.
      const data = await fetchJson(endpoint, { method: "POST", body: "data=" + encodeURIComponent(query), headers: { "Content-Type": "application/x-www-form-urlencoded" } }, 32000);
      // A busy server can answer "200 OK" with a timeout note and no results. That's a failure, not "nothing here".
      if (data && data.remark && /runtime error|timed out|out of memory|too many/i.test(data.remark)) throw new Error(`${endpoint}: ${data.remark}`);
      return data;
    } catch (err) {
      lastError = err;
      console.warn(`Overpass mirror failed, trying next: ${endpoint}`, err);
    }
  }
  throw lastError || new Error("All Overpass mirrors failed");
}

// ---------- helpers ----------
function distanceMiles(lat1, lon1, lat2, lon2) {
  const R = 3958.8, rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad, dLon = (lon2 - lon1) * rad;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}
function compass(lat1, lon1, lat2, lon2) {
  const rad = Math.PI / 180;
  const y = Math.sin((lon2 - lon1) * rad) * Math.cos(lat2 * rad);
  const x = Math.cos(lat1 * rad) * Math.sin(lat2 * rad) - Math.sin(lat1 * rad) * Math.cos(lat2 * rad) * Math.cos((lon2 - lon1) * rad);
  const deg = (Math.atan2(y, x) / rad + 360) % 360;
  return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][Math.round(deg / 45) % 8];
}

function classify(el, center) {
  const t = el.tags || {};
  const lat = el.lat != null ? el.lat : el.center && el.center.lat;
  const lon = el.lon != null ? el.lon : el.center && el.center.lon;
  if (lat == null || lon == null) return null;

  let type, typeLabel;
  if (t.leisure === "dog_park") { type = "dogpark"; typeLabel = "Dog park"; }
  else if (t.highway === "rest_area") { type = "rest"; typeLabel = "Rest area"; }
  else if (t.highway === "services") { type = "rest"; typeLabel = "Service plaza"; }
  else if (t.tourism === "caravan_site") { type = "camp"; typeLabel = "RV park"; }
  else { type = "camp"; typeLabel = "Campsite"; }

  const access = (t.access || "").toLowerCase();
  const isPrivate = ["private", "no"].includes(access) || t.group_only === "yes" || t.camp_site === "private";

  let fee = null; // campsites only
  if (type === "camp") {
    const f = (t.fee || "").toLowerCase().trim();
    if (f === "no" || f === "0" || f === "free") fee = "free";
    else if (f) fee = "paid";
    else fee = "unknown";
  }
  const feeDetail = t.charge || (t.fee && !/^(yes|no)$/i.test(t.fee) ? t.fee : "");

  const d = (t.dog || "").toLowerCase();
  const dogs = d === "yes" || d === "leashed" || d === "unleashed" ? "yes" : d === "no" ? "no" : "unknown";

  const miles = distanceMiles(center.lat, center.lon, lat, lon);
  return {
    id: `${el.type}/${el.id}`, osmType: el.type, osmId: el.id, lat, lon, tags: t,
    name: t.name || `Unnamed ${typeLabel.toLowerCase()}`, named: !!t.name,
    type, typeLabel, isPrivate, fee, feeDetail, dogs, dogTag: d,
    miles, dir: compass(center.lat, center.lon, lat, lon),
    website: safeUrl(t.website || t["contact:website"] || t.url || ""),
    phone: (t.phone || t["contact:phone"] || "").split(";")[0].trim(),
  };
}

function rank(p) {
  if (p.type === "camp") return p.fee === "free" ? 0 : p.fee === "unknown" ? 1 : 2;
  if (p.type === "rest") return 3;
  return 4;
}

function rulesLink(p) {
  if (p.website) return { href: p.website, label: "Check overnight rules on the official site" };
  if (!p.named) return null;
  const where = [p.tags["addr:city"], p.tags["addr:state"]].filter(Boolean).join(" ");
  const what = p.type === "rest" ? "overnight parking rules" : "camping rules fees";
  const q = `"${p.name}" ${where || (p.tags.operator || "")} ${what}`.replace(/\s+/g, " ").trim();
  return { href: `https://www.google.com/search?q=${encodeURIComponent(q)}`, label: "Check overnight rules (search)" };
}

function feePill(p) {
  if (p.type === "rest") return `<span class="pill neutral">Free to stop &middot; overnight rules vary</span>`;
  if (p.type === "dogpark") return `<span class="pill neutral">Dog park</span>`;
  if (p.fee === "free") return `<span class="pill good">&#10003; Listed free</span>`;
  if (p.fee === "paid") return `<span class="pill neutral">Paid${p.feeDetail ? " &middot; " + escapeHtml(p.feeDetail) : ""}</span>`;
  return `<span class="pill warn">Fee unknown &middot; call ahead</span>`;
}
function dogPill(p) {
  if (p.type === "dogpark") return `<span class="pill good">&#128021; Off-leash area</span>`;
  if (p.dogs === "yes") return `<span class="pill good">&#128021; Dogs ${p.dogTag === "leashed" ? "on leash" : "allowed"}</span>`;
  if (p.dogs === "no") return `<span class="pill bad">No dogs</span>`;
  return `<span class="pill neutral">Dog rules not listed</span>`;
}

// ---------- filtering + rendering ----------
function visible(p) {
  if (p.isPrivate && !state.types.private) return false;
  if (!state.types[p.type]) return false;
  if (state.fee === "free" && !(p.type === "camp" && p.fee === "free")) return false;
  if (state.fee === "nopaid" && p.type === "camp" && p.fee === "paid") return false;
  if (state.dog === "yes" && !(p.dogs === "yes" || p.type === "dogpark")) return false;
  return true;
}

function updateCounts() {
  const base = state.places.filter((p) => (!p.isPrivate || state.types.private) && state.types[p.type]);
  const camps = base.filter((p) => p.type === "camp");
  const set = (k, n) => document.querySelectorAll(`[data-count="${k}"]`).forEach((el) => { el.textContent = `(${n})`; });
  set("all", base.length);
  set("free", camps.filter((p) => p.fee === "free").length);
  set("nopaid", base.filter((p) => !(p.type === "camp" && p.fee === "paid")).length);
  set("dogs", base.filter((p) => p.dogs === "yes" || p.type === "dogpark").length);
}

function popupHtml(p) {
  const rules = rulesLink(p);
  return `<strong>${escapeHtml(p.name)}</strong><br/><em>${p.typeLabel}</em> &middot; ${p.miles.toFixed(0)} mi ${p.dir}<br/>
    ${p.type === "camp" ? (p.fee === "free" ? "Listed free on the map (fee=no)" : p.fee === "paid" ? "Paid" + (p.feeDetail ? ": " + escapeHtml(p.feeDetail) : "") : "Fee unknown &mdash; call ahead") + "<br/>" : ""}
    ${p.type === "dogpark" ? "Off-leash dog area" : p.dogs === "yes" ? "Tagged dog-friendly" : p.dogs === "no" ? "No dogs" : "No dog info on record"}<br/>
    ${rules ? `<a href="${escapeHtml(rules.href)}" target="_blank" rel="noopener">Check overnight rules &#8599;</a><br/>` : ""}
    <a href="https://www.openstreetmap.org/${p.osmType}/${p.osmId}" target="_blank" rel="noopener">Source: OpenStreetMap &#8599;</a>`;
}

function render() {
  const list = state.places.filter(visible).sort((a, b) => rank(a) - rank(b) || a.miles - b.miles);
  updateCounts();

  markerLayer.clearLayers();
  markers.clear();
  list.forEach((p) => {
    const color = p.type === "camp" ? COLORS[p.fee] : COLORS[p.type];
    const m = L.circleMarker([p.lat, p.lon], {
      radius: p.fee === "free" ? 10 : 7, color: "#ffffff", weight: 2, fillColor: color, fillOpacity: 0.95,
    }).bindPopup(popupHtml(p));
    m.addTo(markerLayer);
    markers.set(p.id, m);
  });

  const status = document.getElementById("mapStatus");
  status.classList.remove("loading-text");
  const camps = state.places.filter((p) => p.type === "camp" && (!p.isPrivate || state.types.private));
  const free = camps.filter((p) => p.fee === "free").length;
  const unknown = camps.filter((p) => p.fee === "unknown").length;
  const paid = camps.filter((p) => p.fee === "paid").length;
  const rests = state.places.filter((p) => p.type === "rest").length;
  const dogparks = state.places.filter((p) => p.type === "dogpark").length;
  const hiddenPrivate = state.types.private ? 0 : state.places.filter((p) => p.isPrivate).length;
  status.textContent = `Within ${radiusMiles()} mi of ${state.center.name}: ${camps.length} campsite${camps.length === 1 ? "" : "s"} (${free} listed free, ${unknown} fee unknown, ${paid} paid), ${rests} rest/service area${rests === 1 ? "" : "s"}, ${dogparks} dog park${dogparks === 1 ? "" : "s"}. Showing ${list.length}.` + (hiddenPrivate ? ` ${hiddenPrivate} private or group-only site${hiddenPrivate === 1 ? " is" : "s are"} hidden.` : "");

  const note = document.getElementById("freeNote");
  if (state.types.camp && free === 0 && camps.length) {
    note.innerHTML = `<div class="notice" style="margin-top:16px;"><strong>No campsites here are marked free on the map yet.</strong> That usually means nobody has recorded the fee, not that none are free. The sites below are sorted closest first. Call ahead, or check the private-host options further down.</div>`;
  } else note.innerHTML = "";

  const box = document.getElementById("resultList");
  if (!list.length) {
    box.innerHTML = `<div class="notice">Nothing matches these filters. Try "All &middot; free first", a wider radius, or turn on more place types.</div>`;
    document.getElementById("showMore").hidden = true;
    return;
  }
  box.innerHTML = list.slice(0, state.shown).map((p) => {
    const rules = rulesLink(p);
    const facts = [
      p.tags.operator ? `Run by ${escapeHtml(p.tags.operator)}` : "",
      p.tags.tents === "yes" ? "Tents OK" : "",
      p.tags.caravans === "yes" || p.tags.motorhome === "yes" ? "RVs OK" : "",
      p.tags.toilets === "yes" ? "Toilets" : "",
      p.tags.drinking_water === "yes" ? "Drinking water" : "",
      p.isPrivate ? "Private or group-only" : "",
    ].filter(Boolean).join(" &middot; ");
    return `<article class="result-card ${p.type === "camp" ? p.fee : ""}" data-id="${p.id}">
      <div class="result-head">
        <h3><button type="button" data-focus="${p.id}">${escapeHtml(p.name)}</button></h3>
        <span class="result-meta">${p.typeLabel} &middot; ${p.miles.toFixed(0)} mi ${p.dir} of ${escapeHtml(state.center.name)}</span>
      </div>
      <div class="result-badges">${feePill(p)}${dogPill(p)}</div>
      ${facts ? `<div class="result-meta">${facts}</div>` : ""}
      <div class="result-links">
        ${rules ? `<a class="rules" href="${escapeHtml(rules.href)}" target="_blank" rel="noopener" data-track="camp-open-rules">${rules.label} &#8599;</a>` : `<span class="result-meta">No name on the map &mdash; ask locally before staying.</span>`}
        ${p.phone ? `<a href="tel:${escapeHtml(p.phone.replace(/[^+\d]/g, ""))}" data-track="camp-call">Call ${escapeHtml(p.phone)}</a>` : ""}
        <a href="https://www.google.com/maps/dir/?api=1&destination=${p.lat.toFixed(5)},${p.lon.toFixed(5)}" target="_blank" rel="noopener" data-track="camp-open-directions">Directions &#8599;</a>
        <a href="https://www.openstreetmap.org/${p.osmType}/${p.osmId}" target="_blank" rel="noopener" data-track="camp-open-source">Source: OpenStreetMap &#8599;</a>
      </div>
    </article>`;
  }).join("");
  const more = document.getElementById("showMore");
  more.hidden = list.length <= state.shown;
  more.textContent = `Show more results (${list.length - state.shown} more)`;
}

/** The radius as the menu shows it (25, 50, or 100 mi). */
function radiusMiles() {
  return Math.round(state.radius / 1609.34 / 5) * 5;
}

let loadSeq = 0;
async function load() {
  const mine = ++loadSeq;   // a slow earlier search must not overwrite a newer one
  const { lat, lon, name } = state.center;
  const status = document.getElementById("mapStatus");
  status.classList.add("loading-text");
  status.textContent = `Loading places near ${name} from OpenStreetMap…`;
  document.getElementById("resultList").innerHTML = "";
  document.getElementById("freeNote").innerHTML = "";
  map.setView([lat, lon], state.radius > 100000 ? 7 : state.radius > 50000 ? 8 : 9);
  const key = `${lat.toFixed(3)},${lon.toFixed(3)},${state.radius}`;
  try {
    let elements = state.cache.get(key);
    if (!elements) {
      const R = state.radius;
      const query = `[out:json][timeout:25];
(
  nwr["tourism"="camp_site"](around:${R},${lat},${lon});
  nwr["tourism"="caravan_site"](around:${R},${lat},${lon});
  nwr["highway"="rest_area"](around:${R},${lat},${lon});
  nwr["highway"="services"](around:${R},${lat},${lon});
  nwr["leisure"="dog_park"](around:${R},${lat},${lon});
);
out tags center;`;
      const data = await fetchOverpass(query);
      if (mine !== loadSeq) return;
      elements = data.elements || [];
      state.cache.set(key, elements);
    }
    if (mine !== loadSeq) return;
    const seen = new Set();
    state.places = elements.map((el) => classify(el, state.center)).filter((p) => p && !seen.has(p.id) && seen.add(p.id));
    state.shown = PAGE_SIZE;
    render();
    const camps = state.places.filter((p) => p.type === "camp");
    if (typeof lpwnTrack === "function") lpwnTrack("camp-map-search", `${radiusMiles()} mi · ${camps.filter((p) => p.fee === "free").length ? "some listed free" : "none listed free"}`);
  } catch (err) {
    if (mine !== loadSeq) return;
    console.error(err);
    status.classList.remove("loading-text");
    status.textContent = "Couldn't load map data right now (OpenStreetMap's servers may be busy). Try again in a minute, or use the private-host links below.";
  }
}

// ---------- controls ----------
function setPressed(groupSel, attr, value) {
  document.querySelectorAll(`${groupSel} [${attr}]`).forEach((b) => b.setAttribute("aria-pressed", String(b.getAttribute(attr) === value)));
}

function wireControls() {
  document.querySelectorAll("#feeChips [data-fee]").forEach((b) => b.addEventListener("click", () => {
    state.fee = b.dataset.fee; state.shown = PAGE_SIZE; setPressed("#feeChips", "data-fee", state.fee); render();
    if (typeof lpwnTrack === "function") lpwnTrack("camp-filter-fee-" + state.fee);
  }));
  document.querySelectorAll("#dogChips [data-dog]").forEach((b) => b.addEventListener("click", () => {
    state.dog = b.dataset.dog; state.shown = PAGE_SIZE; setPressed("#dogChips", "data-dog", state.dog); render();
    if (typeof lpwnTrack === "function") lpwnTrack("camp-filter-dogs-" + state.dog);
  }));
  document.querySelectorAll("#typeChips [data-type]").forEach((b) => b.addEventListener("click", () => {
    const t = b.dataset.type;
    state.types[t] = !state.types[t];
    b.setAttribute("aria-pressed", String(state.types[t]));
    state.shown = PAGE_SIZE;
    render();
    if (typeof lpwnTrack === "function") lpwnTrack("camp-filter-type-" + t + (state.types[t] ? "-on" : "-off"));
  }));
  document.getElementById("showMore").addEventListener("click", () => { state.shown += PAGE_SIZE; render(); });
  document.getElementById("resultList").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-focus]");
    if (btn) {
      const m = markers.get(btn.dataset.focus);
      if (m) {
        map.setView(m.getLatLng(), Math.max(map.getZoom(), 11));
        m.openPopup();
        document.getElementById("campMap").scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
    const a = e.target.closest("a[data-track]");
    if (a && typeof lpwnTrack === "function") lpwnTrack(a.dataset.track);
  });
  document.getElementById("radiusSelect").addEventListener("change", (e) => { state.radius = Number(e.target.value); load(); });
  document.getElementById("mapLocationSelect").addEventListener("change", (e) => {
    const v = e.target.value;
    if (v === "__custom__") { state.center = customCenter; }
    else { const l = getLocationById(v); state.center = { name: l.name, lat: l.lat, lon: l.lon }; }
    load();
  });
  document.getElementById("nearMe").addEventListener("click", () => {
    const btn = document.getElementById("nearMe");
    if (!navigator.geolocation) { btn.textContent = "Location unavailable"; return; }
    btn.textContent = "Finding you…";
    navigator.geolocation.getCurrentPosition((pos) => {
      btn.innerHTML = "&#128205; Near me";
      customCenter = { name: "your location", lat: pos.coords.latitude, lon: pos.coords.longitude };
      addCustomOption(customCenter, "Your location");
      state.center = customCenter;
      load();
    }, () => { btn.innerHTML = "&#128205; Near me"; document.getElementById("mapStatus").textContent = "We couldn't get your location. Pick a town from the list instead."; },
    { timeout: 10000, maximumAge: 300000 });
  });
}

let customCenter = null;
function addCustomOption(center, label) {
  const sel = document.getElementById("mapLocationSelect");
  let opt = sel.querySelector('option[value="__custom__"]');
  if (!opt) { opt = document.createElement("option"); opt.value = "__custom__"; sel.insertBefore(opt, sel.firstChild); }
  opt.textContent = label || center.name;
  sel.value = "__custom__";
}

(function start() {
  const sel = document.getElementById("mapLocationSelect");
  const groups = groupLocationsByRegion();
  sel.innerHTML = Object.keys(groups).map((region) => `
    <optgroup label="${region}">
      ${groups[region].map((l) => `<option value="${l.id}">${l.name}</option>`).join("")}
    </optgroup>`).join("");

  // Where to start: ?lat=&lon=&name= (from the Trip Planner), else the visitor's town, else La Porte.
  const params = new URLSearchParams(location.search);
  const plat = Number(params.get("lat")), plon = Number(params.get("lon"));
  if (params.get("lat") && isFinite(plat) && isFinite(plon)) {
    customCenter = { name: params.get("name") || "your destination", lat: plat, lon: plon };
    addCustomOption(customCenter, customCenter.name);
    state.center = customCenter;
  } else {
    const cur = getCurrentLocation();
    if (!cur.id) {
      customCenter = { name: cur.name, lat: cur.lat, lon: cur.lon };
      addCustomOption(customCenter, `${cur.name} (your town)`);
      state.center = customCenter;
    } else {
      sel.value = cur.id;
      state.center = { name: cur.name, lat: cur.lat, lon: cur.lon };
    }
  }
  const r = Number(params.get("r"));
  if ([40000, 80000, 160000].includes(r)) { state.radius = r; document.getElementById("radiusSelect").value = String(r); }

  initMap(state.center.lat, state.center.lon);
  wireControls();
  load();
})();
