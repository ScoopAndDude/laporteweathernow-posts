// Hard Hat Weather: the GO / DELAY / STOP engine.
//
// Reads the National Weather Service's hour-by-hour forecast grid for a job site,
// checks every work hour against a trade's limits, and makes one call for the day:
//   GO                     - workable all day (with any cautions noted)
//   GO, WRAP BY 2 PM       - start on time, finish before the weather turns
//   DELAY TILL 11 AM       - bad weather early, then a long enough workable stretch
//   STOP                   - not enough workable hours to be worth starting
// Every call comes with the reasons, the hours, and the exact text a crew would get.
//
// Needs timeutil.js (time zones, fetchJson, escapeHtml) and weather.js (nwsGet, alerts).

const WD_VERSION = "2026-09-26";

/* ---------- Business details shown on the Hard Hat Weather pages ---------- */
// Leave a field empty and the pages simply don't show it.
// textingLive: false until the carriers approve texting; until then the contact lines offer email only.
// The number still shows where the pages explain how joining by text will work.
const WD_CONTACT = { email: "laporteweathernow@gmail.com", phone: "(219) 258-7121", textingLive: false };

/** Shows the contact details on a page once they're filled in above. Elements marked
 * data-wd-contact="phone", "email", or "both" get "Text ... or email ...";
 * elements marked data-wd-contact-line only show when there's something to show. */
function wdFillContact(root) {
  const r = root || document;
  const phone = String(WD_CONTACT.phone || "").trim(), email = String(WD_CONTACT.email || "").trim();
  const link = (kind, v) => {
    const a = document.createElement("a");
    a.href = kind === "email" ? `mailto:${v}` : `sms:+1${v.replace(/\D/g, "").replace(/^1(?=\d{10}$)/, "")}`;
    a.textContent = v;
    return a;
  };
  r.querySelectorAll("[data-wd-contact]").forEach((el) => {
    const kind = el.getAttribute("data-wd-contact");
    const parts = [];
    // The business number is for texting (calls aren't forwarded), so the pages say "Text".
    if ((kind === "phone" || kind === "both") && phone && WD_CONTACT.textingLive) parts.push(["Text ", link("phone", phone)]);
    if ((kind === "email" || kind === "both") && email) parts.push([parts.length ? " or email " : "Email ", link("email", email)]);
    el.textContent = "";
    parts.forEach(([t, a]) => { el.appendChild(document.createTextNode(t)); el.appendChild(a); });
    if (parts.length) el.appendChild(document.createTextNode("."));
    el.hidden = !parts.length;
  });
  r.querySelectorAll("[data-wd-contact-line]").forEach((el) => { el.hidden = !(phone || email); });
  // The number written inline ("texts JOIN to our number (219) ...") shows only when there is one.
  r.querySelectorAll("[data-wd-phone-only]").forEach((el) => { el.textContent = phone; if (el.parentNode) el.parentNode.hidden = !phone; });
}

/* ---------- Trades and their starting limits ---------- */
// "stop" limits make an hour unworkable; "watch" limits add a heads-up. Customers can
// change every number (see wdMergeTrade); these are sensible starting points for each trade.
// Freezing rain stops every trade, and so does the ice it leaves while it's 32\u00B0F or colder.
const WD_TRADES = {
  roofing: {
    label: "Roofing",
    start: 7, end: 16, minBlock: 4, dryAfterRain: 1, iceDeck: 34,
    stop: { pop: 50, thunder: 40, gust: 25, snow: true },
    watch: { pop: 30, thunder: 20, gust: 20, below: 40, heatIndex: 95 },
    words: {
      below: "shingles won't self-seal; hand-seal per the maker",
      heatIndex: "plan water, shade, and breaks on the roof",
      wet: "deck may still be wet",
      icy: "ice or snow on the deck",
    },
  },
  concrete: {
    label: "Concrete & masonry",
    start: 6, end: 15, minBlock: 4, cureHours: 4, freezeNote: "protect fresh concrete",
    stop: { pop: 50, thunder: 40, snow: true },
    watch: { pop: 30, thunder: 20, gust: 25, below: 40, above: 90, heatIndex: 100 },
    words: {
      below: "cold-weather measures needed",
      above: "hot-weather measures: fast set",
      gust: "fast drying: watch for cracking",
      cure: "fresh concrete needs 4 dry hours",
    },
  },
  painting: {
    label: "Exterior painting",
    start: 8, end: 17, minBlock: 4, cureHours: 4,
    stop: { pop: 40, thunder: 40, below: 50, snow: true },
    watch: { pop: 25, thunder: 20, gust: 20, above: 90, dewSpread: 5, humidity: 85 },
    words: {
      below: "most exterior paints need 50\u00B0F (check the can)",
      above: "paint dries too fast",
      gust: "overspray and grit: brush and roll",
      dew: "surfaces may be damp",
      humidity: "slow drying",
      cure: "fresh paint needs 4 dry hours",
    },
  },
  landscaping: {
    label: "Landscaping & lawn",
    start: 7, end: 16, minBlock: 3, freezeNote: "cover new plantings",
    stop: { pop: 60, thunder: 50, gust: 40, snow: true },
    watch: { pop: 40, thunder: 20, gust: 30, below: 32, heatIndex: 100 },
    words: { below: "frozen ground", heatIndex: "plan water and shade breaks" },
  },
  general: {
    label: "General construction",
    start: 7, end: 16, minBlock: 4,
    stop: { pop: 60, thunder: 50, gust: 28 },
    watch: { pop: 40, thunder: 20, gust: 20, heatIndex: 100, windChill: 10, snow: true },
    words: { gust: "most aerial lifts are rated to 28 mph", heatIndex: "plan water and shade breaks" },
  },
  events: {
    label: "Tents & outdoor events",
    start: 8, end: 18, minBlock: 4,
    stop: { thunder: 50, gust: 35, snow: true },
    watch: { pop: 40, thunder: 20, gust: 25, heatIndex: 100 },
    words: { thunder: "lightning: have a shelter plan", gust: "check tent anchoring" },
  },
  inflatables: {
    label: "Inflatables & party rentals",
    start: 9, end: 18, minBlock: 4,
    stop: { pop: 60, thunder: 40, gust: 20, wind: 15, snow: true },
    watch: { pop: 40, thunder: 20, gust: 15, wind: 10, heatIndex: 100 },
    words: { gust: "most inflatable makers say deflate at 15 to 20 mph", wind: "most inflatable makers say deflate at 15 to 20 mph" },
  },
};

function wdTrade(key) {
  return WD_TRADES[key] || WD_TRADES.roofing;
}

/**
 * A trade with a customer's own limits laid over it, e.g.
 * wdMergeTrade("roofing", { stop: { gust: 30 }, watch: { below: 35 }, minBlock: 3 }).
 * Only numbers (and true/false for snow) are taken; anything else is ignored.
 */
function wdMergeTrade(key, limits) {
  const base = wdTrade(key);
  if (!limits || typeof limits !== "object") return base;
  const pick = (src) => {
    const out = {};
    Object.keys(src || {}).forEach((k) => {
      const v = src[k];
      if ((typeof v === "number" && isFinite(v)) || typeof v === "boolean" || v === null) out[k] = v;
    });
    return out;
  };
  const t = Object.assign({}, base, {
    stop: Object.assign({}, base.stop, pick(limits.stop)),
    watch: Object.assign({}, base.watch, pick(limits.watch)),
  });
  const ranges = { minBlock: [1, 12], cureHours: [0, 12], dryAfterRain: [0, 6], iceDeck: [20, 40] };
  Object.keys(ranges).forEach((k) => {
    const v = limits[k], [lo, hi] = ranges[k];
    if (typeof v === "number" && isFinite(v) && v >= lo && v <= hi) t[k] = v;
    else if (k === "iceDeck" && v === null) t[k] = null;   // turn the icy-deck rule off
  });
  return t;
}

/** The limits, in words, for the "Built for your trade" cards. */
function wdTradeLimitsText(key) {
  const t = wdTrade(key);
  const s = t.stop, w = t.watch;
  const stop = [], watch = [];
  if (s.pop != null) stop.push(`${s.pop}%+ chance of rain`);
  if (s.thunder != null) stop.push(`${s.thunder}%+ chance of storms`);
  if (s.gust != null) stop.push(`gusts ${s.gust} mph+`);
  if (s.wind != null) stop.push(`winds ${s.wind} mph+`);
  if (s.below != null) stop.push(`below ${s.below}\u00B0F`);
  stop.push(s.snow ? "snow, sleet, or freezing rain" : "freezing rain");
  if (t.iceDeck) stop.push(`ice or snow on the deck at ${t.iceDeck}\u00B0F or colder`);
  if (t.cureHours) stop.push(`rain within ${t.cureHours} hours of fresh work`);
  if (w.pop != null) watch.push(`${w.pop}%+ rain chance`);
  if (w.gust != null) watch.push(`gusts ${w.gust} mph+`);
  if (w.wind != null) watch.push(`winds ${w.wind} mph+`);
  if (w.below != null) watch.push(`below ${w.below}\u00B0F`);
  if (w.above != null) watch.push(`above ${w.above}\u00B0F`);
  if (w.heatIndex != null) watch.push(`heat index ${w.heatIndex}\u00B0F+`);
  if (w.windChill != null) watch.push(`wind chill ${w.windChill}\u00B0F or colder`);
  if (w.dewSpread != null) watch.push("dew on surfaces");
  if (w.humidity != null) watch.push(`humidity ${w.humidity}%+`);
  if (w.snow && !s.snow) watch.push("snow or sleet");
  if (t.freezeNote) watch.push("a freeze that night");
  return { stop, watch };
}

/* ---------- Reading the NWS forecast grid ---------- */

const WD_HOUR = 3600000;

/** "PT3H" -> 3, "P1DT6H" -> 30, "PT30M" -> 1 (rounded up to whole hours). */
function wdDurationHours(iso) {
  const m = /^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?)?$/.exec(String(iso || ""));
  if (!m) return 1;
  const h = (Number(m[1] || 0) * 24) + Number(m[2] || 0) + Number(m[3] || 0) / 60;
  return Math.max(1, Math.ceil(h));
}

function wdConvert(value, uom) {
  if (value === null || value === undefined || typeof value !== "number" || isNaN(value)) return null;
  const u = String(uom || "");
  if (/degC$/.test(u)) return value * 9 / 5 + 32;
  if (/km_h-1$/.test(u)) return value * 0.621371;
  if (/m_s-1$/.test(u)) return value * 2.23694;
  if (/:kt$/.test(u)) return value * 1.15078;
  if (/:mm$/.test(u)) return value / 25.4;
  if (/:m$/.test(u)) return value * 39.3701;
  return value;
}

// NWS coverage words -> the range of chances they stand for (NWS: slight chance 10-24%,
// chance 25-54%, likely 55-74%). When the forecast gives no storm percentage, the storm
// chance is the rain chance held inside that range.
const WD_COVERAGE_RANGE = {
  slight_chance: [10, 24], isolated: [10, 24], chance: [25, 54], scattered: [25, 54], patchy: [25, 54], areas: [25, 54],
  likely: [55, 74], numerous: [55, 74], intermittent: [55, 100], occasional: [55, 100], periods: [75, 100],
  frequent: [75, 100], widespread: [75, 100], definitely: [75, 100],
};
const WD_COVERAGE = Object.fromEntries(Object.entries(WD_COVERAGE_RANGE).map(([k, v]) => [k, v[0]]));
const WD_ICE_TYPES = /^(freezing_rain|freezing_drizzle)$/;
const WD_SNOW_TYPES = /^(snow|snow_showers|flurries|sleet|blowing_snow|ice_pellets)$/;
const WD_LIQUID_TYPES = /^(rain|rain_showers|drizzle|thunderstorms)$/;
const WD_TRACE = 0.004; // inches: less than this in an hour doesn't count as falling

/** Hour-by-hour forecast from a gridpoints response: Map of UTC-hour -> hour record. */
function wdParseGrid(gridJson) {
  const p = (gridJson && gridJson.properties) || {};
  const hours = new Map();
  const at = (ms) => {
    let h = hours.get(ms);
    if (!h) { h = { t: new Date(ms) }; hours.set(ms, h); }
    return h;
  };
  const periods = (L, fn) => {
    if (!L || !Array.isArray(L.values)) return;
    L.values.forEach((v) => {
      const [startIso, dur] = String(v.validTime || "").split("/");
      const start = Date.parse(startIso);
      if (isNaN(start)) return;
      const n = wdDurationHours(dur);
      const first = Math.floor(start / WD_HOUR) * WD_HOUR;
      fn(v, n, first);
    });
  };
  const layer = (name, field, opts) => {
    const L = p[name];
    periods(L, (v, n, first) => {
      let val = wdConvert(v.value, L.uom);
      if (val !== null && opts && opts.spread) val = val / n; // amounts spread across the period
      else if (val !== null) val = Math.round(val);            // whole degrees, mph, and percents, as shown
      for (let i = 0; i < n; i++) at(first + i * WD_HOUR)[field] = val;
    });
  };
  layer("temperature", "tempF");
  layer("dewpoint", "dewF");
  layer("relativeHumidity", "rh");
  layer("heatIndex", "heatF");
  layer("windChill", "chillF");
  layer("windSpeed", "windMph");
  layer("windGust", "gustMph");
  layer("probabilityOfPrecipitation", "pop");
  layer("probabilityOfThunder", "thunderPct");
  layer("quantitativePrecipitation", "qpfIn", { spread: true });
  layer("snowfallAmount", "snowIn", { spread: true });
  layer("iceAccumulation", "iceIn", { spread: true });
  layer("skyCover", "sky");
  periods(p.weather, (v, n, first) => {
    const list = (Array.isArray(v.value) ? v.value : []).filter((c) => c && c.weather).map((c) => ({
      type: String(c.weather), chance: WD_COVERAGE[c.coverage] || 25, range: WD_COVERAGE_RANGE[c.coverage] || [25, 54], intensity: c.intensity || "",
    }));
    for (let i = 0; i < n; i++) at(first + i * WD_HOUR).wx = list;
  });

  hours.forEach((h) => {
    const list = h.wx || [];
    const pop = h.pop == null ? 0 : h.pop;
    const has = (re) => list.filter((c) => re.test(c.type));
    // Storms: the forecast's own storm percentage when it has one; otherwise, when storms
    // are in the forecast, the rain chance (storms are the rain), never below the coverage word.
    const storms = has(/^thunderstorms$/);
    const stormCov = storms.reduce((m, c) => Math.max(m, c.chance), 0);
    const stormFromPop = storms.reduce((m, c) => Math.max(m, Math.min(Math.max(pop, c.range[0]), c.range[1])), 0);
    h.thunder = h.thunderPct != null ? Math.max(h.thunderPct, stormCov) : stormFromPop;
    // Freezing rain, snow or sleet, and plain rain are judged separately; a mix can be all three.
    h.ice = has(WD_ICE_TYPES).length > 0 || (h.iceIn || 0) > WD_TRACE;
    h.snowy = has(WD_SNOW_TYPES).some((c) => c.chance >= 25) || (h.snowIn || 0) > WD_TRACE;
    h.liquid = has(WD_LIQUID_TYPES).length > 0 || (!h.ice && !has(WD_SNOW_TYPES).length);
    h.precipWord = wdPrecipWord(list, h);
  });
  return { hours, updated: p.updateTime || null, office: p.gridId || null };
}

function wdPrecipWord(list, h) {
  const types = list.map((c) => c.type);
  const snowWord = types.includes("sleet") || types.includes("ice_pellets") ? "sleet" : "snow";
  if (h.liquid && h.snowy && !types.includes("thunderstorms")) return `rain and ${snowWord}`;
  if (types.includes("rain")) return "rain";
  if (types.includes("rain_showers")) return "showers";
  if (types.includes("drizzle")) return "drizzle";
  if (h.snowy) return snowWord;
  return "rain";
}

/* ---------- Checking one hour against a trade's limits ---------- */

const WD_LEVEL = { ok: 0, watch: 1, stop: 2 };

/** Every limit an hour crosses, e.g. [{type:"rain", level:"stop", value:70, limit:50}]. */
function wdCheckHour(h, trade) {
  const s = trade.stop || {}, w = trade.watch || {};
  const hits = [];
  const add = (type, level, value, limit) => hits.push({ type, level, value, limit });
  const pop = h.pop == null ? 0 : h.pop;
  const falls = (amount) => (amount || 0) > WD_TRACE;
  const floor = w.pop != null ? w.pop : 30;   // below this chance, precipitation isn't worth a mention

  // Freezing rain: dangerous footing for every trade.
  if (h.ice && (pop >= floor || falls(h.iceIn))) add("ice", "stop", pop, null);
  // Rain (including the rain in a rain-and-snow mix).
  if (h.liquid) {
    if (s.pop != null && pop >= s.pop) add("rain", "stop", pop, s.pop);
    else if (w.pop != null && pop >= w.pop) add("rain", "watch", pop, w.pop);
  }
  // Snow and sleet.
  if (h.snowy && (pop >= floor || falls(h.snowIn))) {
    if (s.snow) add("winter", "stop", pop, null);
    else if (w.snow) add("winter", "watch", pop, null);
  }
  if (s.thunder != null && h.thunder >= s.thunder) add("thunder", "stop", h.thunder, s.thunder);
  else if (w.thunder != null && h.thunder >= w.thunder) add("thunder", "watch", h.thunder, w.thunder);

  const gust = Math.max(h.gustMph == null ? 0 : h.gustMph, h.windMph == null ? 0 : h.windMph);
  if (s.gust != null && gust >= s.gust) add("gust", "stop", gust, s.gust);
  else if (w.gust != null && gust >= w.gust) add("gust", "watch", gust, w.gust);
  if (h.windMph != null) {
    if (s.wind != null && h.windMph >= s.wind) add("wind", "stop", h.windMph, s.wind);
    else if (w.wind != null && h.windMph >= w.wind) add("wind", "watch", h.windMph, w.wind);
  }
  if (h.tempF != null) {
    if (s.below != null && h.tempF < s.below) add("cold", "stop", h.tempF, s.below);
    else if (w.below != null && h.tempF < w.below) add("cold", "watch", h.tempF, w.below);
    if (s.above != null && h.tempF > s.above) add("hot", "stop", h.tempF, s.above);
    else if (w.above != null && h.tempF > w.above) add("hot", "watch", h.tempF, w.above);
    const hi = h.heatF != null ? h.heatF : h.tempF;
    if (w.heatIndex != null && hi >= w.heatIndex) add("heat", "watch", hi, w.heatIndex);
    const wc = h.chillF != null ? h.chillF : h.tempF;
    if (w.windChill != null && wc <= w.windChill) add("chill", "watch", wc, w.windChill);
    if (w.dewSpread != null && h.dewF != null && h.tempF - h.dewF <= w.dewSpread) add("dew", "watch", h.tempF - h.dewF, w.dewSpread);
  }
  if (w.humidity != null && h.rh != null && h.rh >= w.humidity) add("humid", "watch", h.rh, w.humidity);
  return hits;
}

function wdTopLevel(hits) {
  return hits.reduce((m, x) => (WD_LEVEL[x.level] > WD_LEVEL[m] ? x.level : m), "ok");
}

/* ---------- NWS alerts that matter on a job site ---------- */

// Warnings that stop work while they're in effect.
const WD_ALERT_STOP = new Set([
  "Tornado Warning", "Severe Thunderstorm Warning", "Flash Flood Warning", "Blizzard Warning", "Ice Storm Warning",
  "Winter Storm Warning", "Lake Effect Snow Warning", "Snow Squall Warning", "High Wind Warning", "Extreme Wind Warning",
  "Hurricane Warning", "Tropical Storm Warning", "Typhoon Warning", "Storm Surge Warning", "Dust Storm Warning",
  "Excessive Heat Warning", "Extreme Heat Warning", "Extreme Cold Warning", "Wind Chill Warning", "Tsunami Warning",
  "Earthquake Warning", "Volcano Warning", "Avalanche Warning", "Fire Warning", "Shelter In Place Warning",
  "Evacuation Immediate", "Civil Danger Warning", "Civil Emergency Message", "Hazardous Materials Warning",
  "Nuclear Power Plant Warning", "Radiological Hazard Warning", "Law Enforcement Warning", "Local Area Emergency",
]);
// Products for boats, beaches, and other things that never affect a job site.
const WD_ALERT_IGNORE = new Set([
  "Special Marine Warning", "Marine Weather Statement", "Small Craft Advisory", "Gale Warning", "Gale Watch",
  "Storm Warning", "Storm Watch", "Hurricane Force Wind Warning", "Hurricane Force Wind Watch", "Heavy Freezing Spray Warning",
  "Heavy Freezing Spray Watch", "Freezing Spray Advisory", "Brisk Wind Advisory", "Hazardous Seas Warning", "Hazardous Seas Watch",
  "Low Water Advisory", "Beach Hazards Statement", "Rip Current Statement", "High Surf Advisory", "High Surf Warning",
  "Hydrologic Outlook", "Child Abduction Emergency", "Blue Alert", "Administrative Message", "Test Message",
]);

/** How an NWS alert affects work hours for a trade: "stop", "watch", or null (doesn't apply). */
function wdAlertLevel(event, tradeKey) {
  const e = String(event || "").trim();
  if (!e || WD_ALERT_IGNORE.has(e)) return null;
  if (WD_ALERT_STOP.has(e)) return "stop";
  if (e === "Wind Advisory") return /^(roofing|events|inflatables|general)$/.test(tradeKey) ? "stop" : "watch";
  if (/^(Winter Weather|Freezing Rain|Freezing Drizzle|Freezing Fog) Advisory$/.test(e)) return tradeKey === "roofing" ? "stop" : "watch";
  if (/^(Frost Advisory|Freeze Warning|Freeze Watch|Hard Freeze Warning|Hard Freeze Watch)$/.test(e)) return /^(concrete|landscaping|painting)$/.test(tradeKey) ? "watch" : null;
  // Other warnings for wide areas or shorelines (river floods, lakeshore floods, fire weather) get a heads-up.
  if (/^(Flood Warning|Coastal Flood Warning|Lakeshore Flood Warning|Red Flag Warning)$/.test(e)) return "watch";
  if (/Warning$/.test(e)) return "stop";   // any other warning: better safe
  if (/(Watch|Advisory|Statement|Alert|Message|Emergency)$/.test(e)) return "watch";
  return null;
}

/** Alerts with their time spans and job-site level, for one trade. */
function wdAlertSpans(alerts, tradeKey) {
  return (alerts || []).map((f) => {
    const p = (f && f.properties) || f || {};
    const level = wdAlertLevel(p.event, tradeKey);
    if (!level) return null;
    const from = Date.parse(p.onset || p.effective || p.sent || "") || 0;
    const to = typeof alertEndMs === "function" ? alertEndMs(p) : (Date.parse(p.ends || p.expires || "") || Infinity);
    return { event: String(p.event), level, from, to, props: p };
  }).filter(Boolean);
}

/* ---------- Times, in the job site's own time zone ---------- */

function wdLocalHour(d, tz) {
  const off = tzOffsetMinutes(d, tz);
  return new Date(d.getTime() + off * 60000).getUTCHours();
}

function wdHourWord(h, withSuffix) {
  const x = ((h % 24) + 24) % 24;
  if (x === 12) return "noon";
  if (x === 0) return "midnight";
  const n = x % 12 || 12;
  return withSuffix ? `${n} ${x < 12 ? "AM" : "PM"}` : String(n);
}

/** "7-11 AM", "11 AM-2 PM", "7 AM-noon". `to` is the end of the last hour. */
function wdRangeText(from, to, tz, dash) {
  const d = dash || "\u2013";
  const a = wdLocalHour(from, tz), b = wdLocalHour(to, tz);
  const special = (h) => h === 12 || h === 0;
  if (!special(a) && !special(b) && (a < 12) === (b < 12) && b > a) return `${wdHourWord(a, false)}${d}${wdHourWord(b, true)}`;
  return `${wdHourWord(a, true)}${d}${wdHourWord(b, true)}`;
}

function wdTimeText(d, tz) {
  return wdHourWord(wdLocalHour(d, tz), true);
}

/* ---------- Making the call for one day ---------- */

const WD_WET_TYPES = ["rain", "thunder", "winter", "ice"];

/**
 * The call for one job site on one day.
 * grid:  wdParseGrid() result.  tradeKey: key of WD_TRADES.  ymd: "YYYY-MM-DD" at the site.
 * opts:  { tz, start, end (hours, 24h clock), now (Date), alerts (NWS features), limits (see wdMergeTrade) }
 */
function wdDecideDay(grid, tradeKey, ymd, opts) {
  const o = opts || {};
  const trade = wdMergeTrade(tradeKey, o.limits);
  const tz = o.tz;
  const startH = o.start != null ? o.start : trade.start;
  const endH = o.end != null ? o.end : trade.end;
  const now = o.now || new Date();
  const alertSpans = wdAlertSpans(o.alerts, tradeKey);

  // The work hours still ahead (today's call skips hours already gone).
  const slots = [];
  for (let hr = startH; hr < endH; hr++) {
    const t = zonedDateTime(ymd, hr, tz);
    if (t.getTime() + WD_HOUR <= now.getTime()) continue;
    slots.push(t);
  }
  const result = {
    ymd, tradeKey, trade: trade.label, tradeObj: trade, tz, start: startH, end: endH,
    hours: [], call: "unknown", label: "NO CALL YET", startAt: null, until: null,
    reasons: [], notes: [], stats: null, over: false, restOfDay: slots.length < endH - startH,
  };
  if (!slots.length) { result.over = true; result.label = "WORKDAY OVER"; return result; }

  const rec = (t) => grid.hours.get(Math.floor(t.getTime() / WD_HOUR) * WD_HOUR);
  const usable = (h) => h && h.tempF != null && h.pop != null;
  const hours = slots.map((t) => {
    const h = rec(t);
    if (!usable(h)) return { t, level: "nodata", hits: [], h: h || null };
    const hits = wdCheckHour(h, trade);
    alertSpans.forEach((a) => {
      if (a.from < t.getTime() + WD_HOUR && a.to > t.getTime()) hits.push({ type: "alert", level: a.level, event: a.event, alert: a });
    });
    return { t, level: wdTopLevel(hits), hits, h };
  });
  result.hours = hours;
  // Any work hour the forecast doesn't cover: no call, rather than a guess.
  if (hours.some((x) => x.level === "nodata")) {
    result.window = { from: hours[0].t, to: new Date(hours[hours.length - 1].t.getTime() + WD_HOUR) };
    result.missing = true;
    return result;
  }

  const wetStop = (h) => usable(h) && wdCheckHour(h, trade).some((x) => WD_WET_TYPES.includes(x.type) && x.level === "stop");
  // Ice left behind: after freezing rain, every trade stops while it stays at or below 32\u00B0F;
  // a roof deck stays icy or snowy after ice or snow while it's at or below iceDeck. Only
  // weather that actually builds up counts (a forecast amount, or a likely chance when the
  // forecast gives no amounts), and a thaw since then clears it.
  const builds = (x, amount) => (amount != null ? amount > WD_TRACE : (x.pop || 0) >= 60);
  const icyAt = (t) => {
    const h = rec(t);
    if (!usable(h)) return false;
    const top = Math.max(32, trade.iceDeck || 0);
    let warmest = -Infinity;                         // warmest hour between then and now
    for (let k = 1; k <= 18; k++) {
      const prev = rec(new Date(t.getTime() - k * WD_HOUR));
      if (!usable(prev) || warmest > top) return false;
      let limit = -Infinity;
      if (prev.ice && builds(prev, prev.iceIn)) limit = Math.max(32, trade.iceDeck || -Infinity);
      if (prev.snowy && trade.iceDeck && builds(prev, prev.snowIn)) limit = Math.max(limit, trade.iceDeck);
      if (limit > -Infinity && h.tempF <= limit && warmest <= limit) return true;
      warmest = Math.max(warmest, prev.tempF);
    }
    return false;
  };
  hours.forEach((slot) => {
    if (slot.hits.some((x) => x.type === "ice" || x.type === "winter")) return;
    if (icyAt(slot.t)) {
      slot.hits.push({ type: "icy", level: "stop", value: slot.h.tempF });
      slot.level = "stop";
    }
  });
  // Fresh work needs dry hours after it: rain, storms, or snow in the next few hours make
  // this hour a stop for pours and paint. Looks past the end of the day too.
  if (trade.cureHours) {
    hours.forEach((slot) => {
      if (slot.level === "stop") return;
      for (let k = 1; k <= trade.cureHours; k++) {
        const t = new Date(slot.t.getTime() + k * WD_HOUR);
        const h = rec(t);
        if (wetStop(h)) {
          slot.hits.push({ type: "cure", level: "stop", value: h.pop || 0, rainAt: t });
          slot.level = "stop";
          break;
        }
      }
    });
  }
  // A roof stays wet for a while after rain.
  if (trade.dryAfterRain) {
    hours.forEach((slot) => {
      if (slot.level === "stop") return;
      for (let k = 1; k <= trade.dryAfterRain; k++) {
        const prev = rec(new Date(slot.t.getTime() - k * WD_HOUR));
        if (usable(prev) && wdCheckHour(prev, trade).some((x) => (x.type === "rain" || x.type === "thunder") && x.level === "stop")) {
          slot.hits.push({ type: "wet", level: "watch" });
          slot.level = wdTopLevel(slot.hits);
          break;
        }
      }
    });
  }

  // The longest stretch of workable (not "stop") hours decides the call.
  const n = hours.length;
  const runs = [];
  let i = 0;
  while (i < n) {
    if (hours[i].level === "stop") { i++; continue; }
    let j = i;
    while (j < n && hours[j].level !== "stop") j++;
    runs.push({ s: i, e: j, len: j - i });
    i = j;
  }
  const best = runs.reduce((b, r) => (!b || r.len > b.len ? r : b), null);
  // The morning call needs a stretch worth starting; later in the day, any workable hours left count.
  const need = result.restOfDay ? 1 : Math.min(trade.minBlock || 4, endH - startH);
  const anyStop = hours.some((x) => x.level === "stop");
  const endAt = new Date(hours[n - 1].t.getTime() + WD_HOUR);
  result.need = need;

  if (!anyStop) {
    result.call = "go";                       // nothing stops work in the hours left
  } else if (!best || best.len < need) {
    result.call = "stop";
  } else {
    const late = best.s > 0, early = best.e < n;
    result.call = late ? "delay" : "go";
    if (late) result.startAt = hours[best.s].t;
    if (early) result.until = hours[best.e].t;
  }
  result.label = wdCallLabel(result, tz);
  result.window = { from: hours[0].t, to: endAt };
  result.best = best && result.call !== "stop" ? { from: hours[best.s].t, to: best.e < n ? hours[best.e].t : endAt } : null;

  // Weather during the hours the crew would actually work (or the whole day on a stop).
  const workHours = result.best ? hours.slice(best.s, best.e) : hours;
  result.stats = wdStats(workHours.map((x) => x.h));
  result.dayStats = wdStats(hours.map((x) => x.h));
  result.reasons = wdReasons(hours, trade, tz, endAt, result.restOfDay);
  result.notes = wdNightNotes(grid, trade, endAt);
  result.alerts = alertSpans.filter((a) => a.from < endAt.getTime() && a.to > hours[0].t.getTime());
  result.sky = wdSkyWord(hours.map((x) => x.h));
  return result;
}

function wdCallLabel(r, tz) {
  if (r.call === "stop") return "STOP";
  if (r.call === "unknown") return "NO CALL YET";
  const wrap = r.until ? `WRAP BY ${wdTimeText(r.until, tz).toUpperCase()}` : "";
  if (r.call === "delay") return `DELAY TILL ${wdTimeText(r.startAt, tz).toUpperCase()}${wrap ? ", " + wrap : ""}`;
  return wrap ? `GO, ${wrap}` : "GO";
}

function wdStats(list) {
  const hs = list.filter(Boolean);
  if (!hs.length) return null;
  const nums = (f) => hs.map((h) => h[f]).filter((v) => v != null);
  const temps = nums("tempF"), gusts = hs.map((h) => Math.max(h.gustMph || 0, h.windMph || 0)), pops = nums("pop");
  return {
    lo: temps.length ? Math.round(Math.min(...temps)) : null,
    hi: temps.length ? Math.round(Math.max(...temps)) : null,
    gust: gusts.length ? Math.round(Math.max(...gusts)) : null,
    pop: pops.length ? Math.round(Math.max(...pops)) : null,
  };
}

function wdSkyWord(list) {
  const sky = list.filter(Boolean).map((h) => h.sky).filter((v) => v != null);
  if (!sky.length) return "";
  const avg = sky.reduce((a, b) => a + b, 0) / sky.length;
  if (avg < 25) return "Sunny";
  if (avg < 50) return "Mostly sunny";
  if (avg < 70) return "Partly cloudy";
  if (avg < 88) return "Mostly cloudy";
  return "Cloudy";
}

/** A freeze the night after a pour or planting. */
function wdNightNotes(grid, trade, endAt) {
  const notes = [];
  if (!trade.freezeNote) return notes;
  let low = null;
  for (let k = 0; k < 18; k++) {
    const h = grid.hours.get(Math.floor(endAt.getTime() / WD_HOUR) * WD_HOUR + k * WD_HOUR);
    if (h && h.tempF != null) low = low == null ? h.tempF : Math.min(low, h.tempF);
  }
  if (low != null && low <= 32) notes.push({ type: "freeze", level: "watch", value: Math.round(low), text: `Freeze tonight (low ${Math.round(low)}\u00B0F): ${trade.freezeNote}` });
  return notes;
}

/* ---------- Reasons, in plain words ---------- */

// What matters most comes first: official alerts, then ice, storms, snow, rain, and so on.
const WD_REASON_ORDER = ["alert", "ice", "icy", "thunder", "winter", "rain", "cure", "gust", "wind", "wet", "heat", "chill", "cold", "hot", "dew", "humid"];
// Heads-ups that mean it isn't dry (so a text never says "dry" next to them).
const WD_PRECIP_TYPES = ["ice", "thunder", "winter", "rain"];

function wdPriority(x) {
  const i = WD_REASON_ORDER.indexOf(x.type);
  return i < 0 ? 99 : i;
}

/** Groups each kind of problem into time spans: "Rain likely 7-11 AM (70%)". */
function wdReasons(hours, trade, tz, endAt, restOfDay) {
  const spans = [];
  WD_REASON_ORDER.forEach((type) => {
    let cur = null;
    const close = () => { if (cur) { spans.push(cur); cur = null; } };
    hours.forEach((slot) => {
      const hits = slot.hits.filter((x) => x.type === type);
      if (!hits.length) { close(); return; }
      const key = type === "alert" ? hits.map((x) => x.event).sort().join("|") : "";
      if (cur && cur.key !== key) close();
      if (!cur) cur = { type, key, level: "watch", from: slot.t, to: null, peak: null, low: null, hits: [], rest: !!restOfDay };
      cur.to = new Date(slot.t.getTime() + WD_HOUR);
      hits.forEach((x) => {
        if (WD_LEVEL[x.level] > WD_LEVEL[cur.level]) cur.level = x.level;
        if (typeof x.value === "number") {
          cur.peak = cur.peak == null ? x.value : Math.max(cur.peak, x.value);
          cur.low = cur.low == null ? x.value : Math.min(cur.low, x.value);
        }
        cur.hits.push(x);
      });
      cur.precip = cur.precip || (slot.h && slot.h.precipWord);
    });
    close();
  });
  // Rain inside a storm span says the same thing twice.
  const storms = spans.filter((s) => s.type === "thunder");
  const kept = spans.filter((s) => !(s.type === "rain" && storms.some((t) => t.from <= s.from && t.to >= s.to && WD_LEVEL[t.level] >= WD_LEVEL[s.level])));
  kept.forEach((s) => { s.text = wdReasonText(s, trade, tz, hours[0].t, endAt); });
  return kept.sort((a, b) => (WD_LEVEL[b.level] - WD_LEVEL[a.level]) || (a.from - b.from) || (wdPriority(a) - wdPriority(b)));
}

function wdCap(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function wdChanceWord(pct, noun) {
  const n = noun || "rain";
  if (pct >= 80) return wdCap(n);
  if (pct >= 55) return `${wdCap(n)} likely`;
  if (pct >= 25) return `Chance of ${n}`;
  return `Slight chance of ${n}`;
}

function wdWhen(s, tz, dayStart, dayEnd, dash) {
  const all = s.from.getTime() <= dayStart.getTime() && s.to.getTime() >= dayEnd.getTime();
  if (all) return s.rest ? "for the rest of the workday" : "all day";
  if (s.from.getTime() <= dayStart.getTime()) return `until ${wdTimeText(s.to, tz)}`;
  if (s.to.getTime() >= dayEnd.getTime()) return `after ${wdTimeText(s.from, tz)}`;
  return wdRangeText(s.from, s.to, tz, dash);
}

/** The hit in a span that set its level (for the limit it crossed). */
function wdTopHit(s) {
  return s.hits.reduce((m, x) => (WD_LEVEL[x.level] > WD_LEVEL[m.level] ? x : m), s.hits[0]);
}

function wdReasonText(s, trade, tz, dayStart, dayEnd, dash) {
  const when = wdWhen(s, tz, dayStart, dayEnd, dash);
  const words = trade.words || {};
  const r = (v) => Math.round(v);
  const pct = s.peak != null ? ` (${r(s.peak)}%)` : "";
  switch (s.type) {
    case "rain": return `${wdChanceWord(s.peak || 0, s.precip === "storms" || !s.precip ? "rain" : s.precip)} ${when}${pct}`;
    case "thunder": return `${s.peak >= 55 ? "Storms likely" : "Chance of storms"} ${when}${pct}${words.thunder ? `: ${words.thunder}` : ""}`;
    case "winter": return `${wdChanceWord(s.peak != null ? s.peak : 30, /sleet/.test(s.precip || "") ? "sleet" : "snow")} ${when}${pct}`;
    case "ice": return `${wdChanceWord(s.peak != null ? s.peak : 30, "freezing rain")} ${when}${pct}: icy surfaces`;
    case "icy": return `${wdCap(words.icy || "icy surfaces")} ${when} (${r(s.peak)}\u00B0F or colder)`;
    case "gust": return `Gusts to ${r(s.peak)} mph ${when}${words.gust && s.level === "stop" ? `: ${words.gust}` : ""}`;
    case "wind": return `Winds to ${r(s.peak)} mph ${when}${words.wind && s.level === "stop" ? `: ${words.wind}` : ""}`;
    case "cold": return `Below ${wdTopHit(s).limit}\u00B0F ${when}${words.below ? `: ${words.below}` : ""}`;
    case "hot": return `Above ${wdTopHit(s).limit}\u00B0F ${when} (up to ${r(s.peak)}\u00B0F)${words.above ? `: ${words.above}` : ""}`;
    case "heat": return `Heat index up to ${r(s.peak)}\u00B0F ${when}${words.heatIndex ? `: ${words.heatIndex}` : ""}`;
    case "chill": return `Wind chill down to ${r(s.low)}\u00B0F ${when}`;
    case "dew": return `Dew likely ${when}${words.dew ? `: ${words.dew}` : ""}`;
    case "humid": return `Humidity ${r(s.peak)}% ${when}${words.humidity ? `: ${words.humidity}` : ""}`;
    case "wet": return `${wdCap(words.wet || "surfaces may be wet")} ${when}`;
    case "cure": {
      const rainAt = s.hits.map((x) => x.rainAt).filter(Boolean).sort((a, b) => a - b)[0];
      return `Rain due ${rainAt ? "by " + wdTimeText(rainAt, tz) : "soon after"}: ${words.cure || `fresh work needs ${trade.cureHours} dry hours`}`;
    }
    case "alert": {
      const a = s.hits[0].alert;
      const until = a && typeof alertUntilText === "function" ? alertUntilText(a.props, tz) : "";
      return `NWS ${s.hits[0].event}${until ? " " + until : ""}`;
    }
    default: return "";
  }
}

/* ---------- Text messages ---------- */
// Texts use only the standard SMS character set (no curly quotes, dashes, degree signs,
// or accents), so each part holds 160 characters and never switches to costly "unicode" texts.

function wdPlain(s) {
  return String(s == null ? "" : s)
    .replace(/[\u2018\u2019\u201A\u2032`\u00B4]/g, "'").replace(/[\u201C\u201D\u201E\u2033]/g, '"')
    .replace(/[\u2013\u2014\u2212~]/g, "-").replace(/\u00B0F/g, "F").replace(/\u00B0/g, "")
    .replace(/\u00A0/g, " ").replace(/\u2026/g, "...")
    .replace(/[\[{]/g, "(").replace(/[\]}]/g, ")").replace(/[|\\]/g, "/").replace(/\^/g, "")
    .normalize("NFD").replace(/[\u0300-\u036F]/g, "")
    .replace(/[^A-Za-z0-9 \n!"#$%&'()*+,\-./:;<=>?@_]/g, "");
}

/** Standard texts carry 160 characters, or 153 per part when split. */
function wdSmsParts(text) {
  const len = String(text).length;
  return len <= 160 ? 1 : Math.ceil(len / 153);
}

/** "57-62F, gusts to 18 mph" for the hours the crew works. */
function wdStatsText(st) {
  if (!st) return "";
  const parts = [];
  if (st.lo != null && st.hi != null) parts.push(st.hi - st.lo >= 4 ? `${st.lo}-${st.hi}F` : `${st.hi}F`);
  if (st.gust != null) parts.push(st.gust < 10 ? "light wind" : `gusts to ${st.gust} mph`);
  return parts.join(", ");
}

/** The reasons a text should mention, most important first, for any call. */
function wdSmsReasons(r) {
  const stops = r.reasons.filter((x) => x.level === "stop");
  const watches = r.reasons.filter((x) => x.level === "watch");
  const byImportance = (a, b) => (wdPriority(a) - wdPriority(b)) || (a.from - b.from);
  const hoursOf = (x) => (x.to - x.from) / WD_HOUR;
  const alerts = r.reasons.filter((x) => x.type === "alert").sort((a, b) => WD_LEVEL[b.level] - WD_LEVEL[a.level]);
  let lead = [];
  if (r.call === "stop") {
    lead = stops.slice().sort((a, b) => (b.type === "alert") - (a.type === "alert") || (hoursOf(b) - hoursOf(a)) || byImportance(a, b)).slice(0, 2);
  } else if (r.call === "delay") {
    lead = stops.filter((x) => x.from < r.startAt).sort(byImportance).slice(0, 2);
    if (r.until) lead = lead.concat(stops.filter((x) => x.from >= r.until).sort((a, b) => a.from - b.from).slice(0, 1));
  } else if (r.until) {
    lead = stops.filter((x) => x.from >= r.until).sort(byImportance).slice(0, 2);
  }
  // Heads-ups for the hours being worked (an official alert always makes the text).
  const inWork = (x) => !r.best || (x.from < r.best.to && x.to > r.best.from);
  const heads = watches.filter(inWork).sort(byImportance);
  const extra = [];
  alerts.forEach((a) => { if (!lead.includes(a) && !extra.includes(a)) extra.push(a); });
  heads.forEach((x) => { if (extra.length < 2 && !extra.includes(x) && !lead.includes(x)) extra.push(x); });
  return { lead, extra, heads };
}

/** One site's line in the morning text. `compact` keeps just the call and its main reason. */
function wdSmsLine(siteName, r, compact) {
  const name = wdPlain(siteName).trim() || "Job site";
  if (r.over) return `${name}: workday over.`;
  if (r.call === "unknown") return `${name}: NO CALL YET. The NWS forecast doesn't cover these hours yet.`;
  const trade = r.tradeObj || wdTrade(r.tradeKey);
  const say = (x) => wdPlain(wdReasonText(x, trade, r.tz, r.window.from, r.window.to, "-"));
  const { lead, extra, heads } = wdSmsReasons(r);
  if (compact) {
    const first = lead[0] || extra[0];
    const alert = lead.concat(extra).find((x) => x.type === "alert");
    const bits = [first, alert && alert !== first ? alert : null].filter(Boolean).map((x) => say(x).split(": ")[0]);
    return `${name}: ${r.label}${bits.length ? " - " + bits.join("; ") : ""}`;
  }
  const precipHead = heads.some((x) => WD_PRECIP_TYPES.includes(x.type));
  const dry = r.stats && r.stats.pop != null && r.stats.pop < 25 && !precipHead;
  const statsTxt = wdStatsText(r.stats);
  const parts = [];
  if (r.call === "stop") {
    const stopSpans = r.reasons.filter((x) => x.level === "stop");
    const oneCovers = stopSpans.some((x) => x.from <= r.window.from && x.to >= r.window.to);
    if (!oneCovers && stopSpans.length > 1) {
      // Several stretches of bad weather: list them in order, briefly, so the reader sees the day.
      const inOrder = [];
      stopSpans.slice().sort((a, b) => (a.from - b.from) || (wdPriority(a) - wdPriority(b))).forEach((x) => {
        if (inOrder.length < 3 && !inOrder.some((c) => c.from <= x.from && c.to >= x.to)) inOrder.push(x);   // one reason per stretch
      });
      const short = inOrder.map((x) => say(x).split(": ")[0]).map((x) => (/^NWS /.test(x) ? x : x.charAt(0).toLowerCase() + x.slice(1)));
      parts.push(`No ${r.need}-hour workable stretch: ${short.join(", ")}`);
    } else {
      parts.push(lead.map(say).join(". "));
    }
    extra.filter((x) => x.type === "alert" && !parts.join(" ").includes(x.hits[0].event)).forEach((x) => parts.push(say(x)));
  } else if (r.call === "delay") {
    lead.forEach((x) => parts.push(say(x)));
    if (statsTxt) parts.push(`Then ${dry ? "dry, " : ""}${statsTxt}`);
    extra.forEach((x) => parts.push(say(x)));
  } else if (r.until) {
    lead.forEach((x) => parts.push(say(x)));
    if (statsTxt) parts.push(dry ? `Dry till then, ${statsTxt}` : `Till then: ${statsTxt}`);
    extra.forEach((x) => parts.push(say(x)));
  } else {
    extra.forEach((x) => parts.push(say(x)));
    const pop = r.dayStats && r.dayStats.pop != null ? r.dayStats.pop : 0;
    const lead2 = precipHead ? "" : pop < 20 ? "Dry" : `Mostly dry (${pop}% rain chance)`;
    parts.push([lead2, statsTxt].filter(Boolean).join(", "));
  }
  (r.notes || []).slice(0, 1).forEach((nt) => parts.push(wdPlain(nt.text)));
  return `${name}: ${r.label}. ${parts.filter(Boolean).join(". ")}.`.replace(/\.\./g, ".");
}

/**
 * The morning text for one phone. One or two sites get full lines; three or more get one
 * short line each; if that still runs past 4 parts, a summary lists only the sites that
 * aren't a plain GO.
 */
function wdMorningSms(sites, ymd) {
  const head = `Hard Hat Weather - ${weekdayOfYmd(ymd, "short")} ${Number(ymd.slice(5, 7))}/${Number(ymd.slice(8, 10))}`;
  const foot = "Reply STOP to opt out";
  const build = (lines) => [head].concat(lines).concat([foot]).join("\n");
  if (sites.length <= 2) return build(sites.map((s) => wdSmsLine(s.name, s.result)));
  const compact = build(sites.map((s) => wdSmsLine(s.name, s.result, true)));
  if (compact.length <= 612) return compact;
  // Too long: group the sites by their call ("STOP: Oak St, Main St"), plain GOs last.
  const count = (c) => sites.filter((s) => !s.result.over && s.result.call === c).length;
  const tally = [["go", "GO"], ["delay", "DELAY"], ["stop", "STOP"], ["unknown", "NO CALL"]].filter(([c]) => count(c)).map(([c, w]) => `${count(c)} ${w}`).join(", ");
  const groups = new Map();
  const order = { stop: 0, unknown: 1, delay: 2, go: 3 };
  sites.slice().sort((a, b) => (order[a.result.call] - order[b.result.call])).forEach((s) => {
    if (s.result.over) return;
    const key = s.result.call === "go" && !s.result.until ? "GO" : s.result.label;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(wdPlain(s.name).trim() || "Job site");
  });
  // Official alerts always make the text: "NWS Tornado Watch: Oak St, Main St".
  const alertSites = new Map();
  sites.forEach((s) => (s.result.reasons || []).filter((x) => x.type === "alert").forEach((x) => {
    const ev = x.hits[0].event;
    if (!alertSites.has(ev)) alertSites.set(ev, []);
    const nm = wdPlain(s.name).trim() || "Job site";
    if (!alertSites.get(ev).includes(nm)) alertSites.get(ev).push(nm);
  }));
  const alertLines = [...alertSites].slice(0, 3).map(([ev, names]) => wdPlain(`NWS ${ev}: ${names.join(", ")}`));
  const groupLines = [];
  groups.forEach((names, label) => { if (label !== "GO") groupLines.push(`${label}: ${names.join(", ")}`); });
  const goLine = groups.has("GO") ? [groups.size > 1 ? "All other sites: GO." : "All sites: GO."] : [];
  const assemble = (extra) => build([`${sites.length} sites: ${tally}`].concat(alertLines, groupLines, goLine, extra || []));
  let text = assemble();
  // Still too long (lots of long names): drop call lines from the end, keep the counts and alerts.
  while (text.length > 612 && groupLines.length) {
    groupLines.pop();
    text = assemble(["Details on your dashboard."]);
  }
  return text;
}

/** A warning text when the NWS issues a warning that covers a site. */
function wdWarningSms(siteName, alertProps, tz) {
  const p = alertProps || {};
  const until = typeof alertUntilText === "function" ? alertUntilText(p, tz) : "";
  const params = p.parameters || {};
  const extra = [];
  const gust = params.maxWindGust && String(params.maxWindGust[0] || "").match(/\d+/);
  if (gust) extra.push(`Gusts to ${gust[0]} mph possible`);
  const hail = params.maxHailSize && String(params.maxHailSize[0] || "").match(/[\d.]+/);
  if (hail && Number(hail[0]) > 0) extra.push(`hail up to ${Number(hail[0])} ${Number(hail[0]) === 1 ? "inch" : "inches"}`);
  const tornado = params.tornadoDetection && String(params.tornadoDetection[0] || "");
  if (tornado) extra.push(`Tornado ${tornado.toLowerCase()}`);
  return [
    `Hard Hat Weather WARNING - ${wdPlain(siteName)}`,
    `NWS ${wdPlain(p.event || "warning")}${until ? " " + wdPlain(until) : ""}.${extra.length ? " " + wdPlain(extra.join(", ")) + "." : ""} Follow your crew's safety plan.`,
    "Reply STOP to opt out",
  ].join("\n");
}

const WD_SMS_CONFIRM = "Hard Hat Weather from La Porte Weather Now: you're signed up for job-site weather calls. Usually 1-3 msgs per workday. Msg & data rates may apply. Reply HELP for help, STOP to cancel.";

/* ---------- Loading a job site ---------- */

const wdCache = new Map();

async function wdGetWithRetry(url, tries, ms) {
  let last;
  for (let i = 0; i < (tries || 3); i++) {
    try { return await nwsGet(url, ms || 20000); } catch (e) {
      last = e;
      if (e.status === 404 || e.status === 400) break;   // NWS has no data there; retrying won't help
      await new Promise((r) => setTimeout(r, 700 * (i + 1)));
    }
  }
  throw last;
}

/**
 * Everything the engine needs for one spot: time zone, NWS grid, and active alerts.
 * Cached for 10 minutes so switching trades or days doesn't ask NWS again.
 */
async function wdLoadPoint(lat, lon) {
  const key = `${lat.toFixed(4)},${lon.toFixed(4)}`;
  const hit = wdCache.get(key);
  if (hit && Date.now() - hit.at < 600000) return hit.promise;
  const promise = (async () => {
    const point = await wdGetWithRetry(`${NWS_BASE}/points/${key}`, 2, 15000);
    const props = point.properties || {};
    if (!props.forecastGridData) { const e = new Error("No NWS forecast grid here"); e.status = 404; throw e; }
    const [gridR, alertsR] = await Promise.allSettled([
      wdGetWithRetry(props.forecastGridData, 3, 25000),
      nwsGet(`${NWS_BASE}/alerts/active?point=${key}`, 12000),
    ]);
    if (gridR.status !== "fulfilled") throw gridR.reason;
    const rel = props.relativeLocation && props.relativeLocation.properties;
    return {
      lat, lon,
      tz: nwsPointTimeZone(props) || "America/Chicago",
      place: rel ? `${rel.city}, ${rel.state}` : "",
      office: props.gridId || props.cwa || "",
      grid: wdParseGrid(gridR.value),
      alerts: alertsR.status === "fulfilled" ? sortAlerts(liveAlerts(alertsR.value.features)) : null,
      loadedAt: new Date(),
    };
  })();
  wdCache.set(key, { at: Date.now(), promise });
  promise.catch(() => wdCache.delete(key));
  return promise;
}

/** The call for a site on a given day ("today", "tomorrow", or "YYYY-MM-DD"). */
function wdCallFor(point, tradeKey, day, opts) {
  const o = opts || {};
  const now = o.now || new Date();
  const today = ymdInZone(now, point.tz);
  const ymd = day === "tomorrow" ? addDaysYmd(today, 1) : day === "today" || !day ? today : day;
  return wdDecideDay(point.grid, tradeKey, ymd, Object.assign({ tz: point.tz, now, alerts: point.alerts || [] }, o));
}

/** Before 11 AM at the site, today's call matters most; after that, tomorrow's. */
function wdDefaultDay(tz, now) {
  return wdLocalHour(now || new Date(), tz) < 11 ? "today" : "tomorrow";
}

/* ---------- Finding a job site ---------- */
// Addresses, towns, and ZIP codes are looked up with OpenStreetMap's Nominatim, only when
// someone asks (never as they type), which its usage policy allows. Results are
// \u00A9 OpenStreetMap contributors; the pages that search say so.

const WD_OSM_CREDIT = 'Address search by <a href="https://nominatim.openstreetmap.org/" target="_blank" rel="noopener">Nominatim</a>, &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap contributors</a>';

async function wdFindPlace(q) {
  const s = String(q || "").trim();
  if (s.length < 2) return [];
  const zip = /^\d{5}(?:-\d{4})?$/.test(s);
  const query = zip ? `postalcode=${encodeURIComponent(s.slice(0, 5))}` : `q=${encodeURIComponent(s)}`;
  const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&countrycodes=us&limit=5&addressdetails=1&${query}`;
  const data = await fetchJson(url, { headers: { Accept: "application/json" } }, 12000);
  const seen = new Set();
  return (Array.isArray(data) ? data : []).map((r) => {
    const a = r.address || {};
    const town = a.city || a.town || a.village || a.hamlet || a.township || a.municipality || a.county || "";
    const st = String(a["ISO3166-2-lvl4"] || "").replace(/^US-/, "") || (typeof stateAbbrev === "function" ? stateAbbrev(a.state || "") : a.state || "");
    const street = [a.house_number, a.road].filter(Boolean).join(" ");
    let name = [street, town, st].filter(Boolean).join(", ");
    if (zip && a.postcode) name = `${[town, st].filter(Boolean).join(", ")} ${a.postcode}`.trim();
    if (!name) name = String(r.display_name || "").split(",").slice(0, 3).join(",").trim();
    return { name: name.slice(0, 80), lat: Math.round(Number(r.lat) * 1e4) / 1e4, lon: Math.round(Number(r.lon) * 1e4) / 1e4 };
  }).filter((r) => isFinite(r.lat) && isFinite(r.lon) && r.name && !seen.has(r.name) && seen.add(r.name));
}

const WD_QUICK_PLACES = [
  { name: "La Porte, IN", lat: 41.6081, lon: -86.7189 },
  { name: "Michigan City, IN", lat: 41.7075, lon: -86.8950 },
  { name: "Valparaiso, IN", lat: 41.4731, lon: -87.0611 },
  { name: "South Bend, IN", lat: 41.6764, lon: -86.2520 },
];

/* ---------- Drawing a result (shared by the product page and the dashboard) ---------- */

const WD_CALL_CLASS = { go: "wd-go", delay: "wd-delay", stop: "wd-stop", unknown: "wd-unknown" };

function wdDayTitle(ymd, now, tz) {
  const today = ymdInZone(now || new Date(), tz);
  const rel = ymd === today ? "Today" : ymd === addDaysYmd(today, 1) ? "Tomorrow" : weekdayOfYmd(ymd, "long");
  return `${rel}, ${weekdayOfYmd(ymd, "short")} ${monthDayOfYmd(ymd)}`;
}

/** What the call means for the crew, in one line under the big call (the reasons are listed below it). */
function wdHeadline(r) {
  if (r.over) return "Today's work hours are over. Check tomorrow's call.";
  if (r.call === "unknown") return "The National Weather Service forecast doesn't cover all of these hours yet, so there's no call.";
  const tz = r.tz;
  const cond = r.stats ? wdStatsText(r.stats).replace(/(\d)-(\d)/g, "$1\u2013$2").replace(/(\d)F\b/g, "$1\u00B0F") : "";
  if (r.call === "stop") {
    if (r.restOfDay) return `No workable hours left before ${wdHourWord(wdLocalHour(r.window.to, tz), true)}.`;
    return `No ${r.need}-hour stretch of workable weather between ${wdHourWord(wdLocalHour(r.window.from, tz), true)} and ${wdHourWord(wdLocalHour(r.window.to, tz), true)}.`;
  }
  if (r.call === "delay") return `Start at ${wdTimeText(r.startAt, tz)}. Workable ${wdRangeText(r.startAt, r.best.to, tz)}${cond ? ": " + cond : ""}.`;
  if (r.until) return `${r.restOfDay ? "Work now" : "Start on time"} and wrap by ${wdTimeText(r.until, tz)}. Workable ${wdRangeText(r.window.from, r.until, tz)}${cond ? ": " + cond : ""}.`;
  const heads = r.reasons.filter((x) => x.level === "watch");
  const count = heads.length + (r.notes || []).length;
  const precip = heads.some((x) => WD_PRECIP_TYPES.includes(x.type));
  const pop = r.dayStats && r.dayStats.pop != null ? r.dayStats.pop : 0;
  const dry = precip ? "" : pop < 20 ? "dry" : "mostly dry";
  const lead = r.restOfDay ? "Workable for the rest of the workday" : "Workable all day";
  const body = [dry, cond].filter(Boolean).join(", ");
  const extra = count === 1 ? " One heads-up below." : count > 1 ? " A few heads-ups below." : "";
  return `${lead}${body ? ": " + body : ""}.${extra}`;
}

/** The hour-by-hour strip. */
function wdHourStripHtml(r) {
  const tz = r.tz;
  const cells = r.hours.map((x) => {
    const h = x.h;
    const lvl = x.level;
    const pop = h && h.pop != null ? Math.round(h.pop) : null;
    const gust = h ? Math.round(Math.max(h.gustMph || 0, h.windMph || 0)) : null;
    const temp = h && h.tempF != null ? Math.round(h.tempF) : null;
    const word = lvl === "stop" ? "stop" : lvl === "watch" ? "caution" : lvl === "nodata" ? "no forecast" : "workable";
    const why = x.hits.filter((y) => y.level === lvl).map((y) => y.type === "alert" ? y.event : y.type).filter((v, i, a) => a.indexOf(v) === i).join(", ");
    return `<li class="wd-hr wd-hr-${lvl}">
      <span class="wd-hr-time">${escapeHtml(wdHourWord(wdLocalHour(x.t, tz), true).replace(/^noon$/, "Noon").replace(/^midnight$/, "12 AM").replace(" ", "\u00A0"))}</span>
      <span class="wd-hr-bar" aria-hidden="true"></span>
      <span class="wd-hr-pop">${pop == null ? "&ndash;" : pop + "%"}</span>
      <span class="wd-hr-gust">${gust == null ? "&ndash;" : gust}</span>
      <span class="wd-hr-temp">${temp == null ? "&ndash;" : temp + "&deg;"}</span>
      <span class="visually-hidden">${escapeHtml(word)}${why ? " (" + escapeHtml(why) + ")" : ""}; rain chance ${pop == null ? "unknown" : pop + " percent"}, gusts ${gust == null ? "unknown" : gust + " miles per hour"}, ${temp == null ? "" : temp + " degrees"}</span>
    </li>`;
  }).join("");
  return `<div class="wd-strip-wrap">
    <div class="wd-strip-legend" aria-hidden="true"><span>Hour</span><span></span><span>Rain</span><span>Gust</span><span>Temp</span></div>
    <ol class="wd-strip" aria-label="Hour by hour">${cells}</ol>
  </div>
  <ul class="wd-strip-key" aria-hidden="true"><li><span><i style="background:var(--go)"></i>Workable</span></li><li><span><i style="background:var(--delay)"></i>Heads-up</span></li><li><span><i style="background:var(--stop)"></i>Stop</span></li><li>Gusts in mph</li></ul>`;
}

function wdReasonsHtml(r) {
  const items = r.reasons.map((x) => `<li class="wd-reason wd-reason-${x.level}"><span class="wd-dot" aria-hidden="true"></span><span><span class="visually-hidden">${x.level === "stop" ? "Stops work: " : "Caution: "}</span>${escapeHtml(x.text)}</span></li>`)
    .concat((r.notes || []).map((n) => `<li class="wd-reason wd-reason-watch"><span class="wd-dot" aria-hidden="true"></span><span><span class="visually-hidden">Caution: </span>${escapeHtml(n.text)}</span></li>`));
  if (!items.length) items.push(`<li class="wd-reason wd-reason-ok"><span class="wd-dot" aria-hidden="true"></span><span>Nothing in the forecast crosses your limits.</span></li>`);
  return `<ul class="wd-reasons">${items.join("")}</ul>`;
}

function wdPillHtml(r, big) {
  return `<span class="wd-pill ${WD_CALL_CLASS[r.call] || "wd-unknown"}${big ? " wd-pill-big" : ""}">${escapeHtml(r.label)}</span>`;
}

function wdSmsBubbleHtml(text) {
  return `<div class="wd-sms"><div class="wd-sms-from">Hard Hat Weather</div><p class="wd-sms-bubble">${escapeHtml(text).replace(/\n/g, "<br>")}</p></div>`;
}

function wdSourceLine(point, r) {
  const upd = point.grid.updated ? `${fmtInZone(point.grid.updated, point.tz, { weekday: "short", hour: "numeric", minute: "2-digit" })} ${zoneAbbrev(point.grid.updated, point.tz)}` : "";
  return `From the National Weather Service forecast${upd ? ` updated ${escapeHtml(upd)}` : ""}${point.office ? ` (NWS ${escapeHtml(point.office)} office)` : ""}. <a href="${nwsPointPageUrl(point.lat, point.lon)}" target="_blank" rel="noopener">See it at weather.gov<span class="visually-hidden"> (opens in a new tab)</span> &#8599;</a>`;
}

/** Full result card body (used by the live check). */
function wdResultHtml(point, r, siteName, now) {
  const alertsNote = point.alerts === null ? `<p class="wd-note">We couldn't check NWS alerts just now, so this call is from the forecast only. <a href="${nwsPointPageUrl(point.lat, point.lon)}" target="_blank" rel="noopener">Check weather.gov<span class="visually-hidden"> (opens in a new tab)</span></a>.</p>` : "";
  const hours = `Work hours ${escapeHtml(wdHourWord(r.start, true))}&ndash;${escapeHtml(wdHourWord(r.end, true))}`;
  return `<div class="wd-result-head">
      <div>
        <div class="wd-result-day">${escapeHtml(wdDayTitle(r.ymd, now, r.tz))}</div>
        <div class="wd-result-meta">${escapeHtml(r.trade)} &middot; ${hours}</div>
      </div>
      ${wdPillHtml(r, true)}
    </div>
    <p class="wd-headline">${escapeHtml(wdHeadline(r))}</p>
    ${alertsNote}
    ${r.over || r.call === "unknown" ? "" : wdReasonsHtml(r)}
    ${r.over || r.call === "unknown" ? "" : wdHourStripHtml(r)}
    ${r.over || r.call === "unknown" ? "" : `<div class="wd-result-sms"><div class="wd-label">The text your crew gets</div>${wdSmsBubbleHtml(wdMorningSms([{ name: siteName, result: r }], r.ymd))}</div>`}
    <p class="wd-source">${wdSourceLine(point, r)}</p>`;
}
