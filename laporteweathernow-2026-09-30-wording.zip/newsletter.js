// Newsletter signup (Netlify Forms). Works for every <form data-newsletter> on the page.
// Submissions show up in Netlify under Site > Forms > "newsletter".
(function () {
  // Only suggest a town the visitor actually picked (not the La Porte default
  // everyone sees), so signups aren't mis-tagged.
  function savedLocation() {
    try {
      const chose = localStorage.getItem("lpwn_custom_location") || localStorage.getItem("lpwn_location");
      if (!chose || typeof getCurrentLocation !== "function") return null;
      return getCurrentLocation();
    } catch (e) { return null; }
  }

  function prepare(form) {
    const town = form.querySelector('[name="town"]');
    const source = form.querySelector('[name="source"]');
    if (source) source.value = location.pathname || "/";
    const loc = savedLocation();
    if (town && !town.value && loc && loc.name) town.value = loc.name;
  }

  function beforeSend(form) {
    // Coordinates only go along when the visitor kept the town we suggested.
    const town = form.querySelector('[name="town"]');
    const lat = form.querySelector('[name="lat"]');
    const lon = form.querySelector('[name="lon"]');
    const loc = savedLocation();
    const keep = town && loc && town.value.trim() === loc.name;
    if (lat) lat.value = keep ? Number(loc.lat).toFixed(3) : "";
    if (lon) lon.value = keep ? Number(loc.lon).toFixed(3) : "";
  }

  document.querySelectorAll("form[data-newsletter]").forEach((form) => {
    prepare(form);
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const status = form.querySelector(".newsletter-status");
      const btn = form.querySelector('button[type="submit"]');
      beforeSend(form);
      if (btn) btn.disabled = true;
      try {
        const res = await fetch("/", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams(new FormData(form)).toString(),
        });
        if (!res.ok) throw new Error(String(res.status));
        form.reset();
        // reset() leaves hidden fields alone, so clear them too (the trip only
        // goes along when its box is checked again).
        form.querySelectorAll('input[type="hidden"]:not([name="form-name"])').forEach((el) => { el.value = ""; });
        const optIn = form.querySelector("#tripOptIn");
        if (optIn) optIn.dispatchEvent(new Event("change"));
        prepare(form);
        if (status) status.textContent = "Thanks, you're on the list! Watch your inbox for the next update.";
        if (typeof lpwnTrack === "function") lpwnTrack("newsletter-signup", location.pathname);
      } catch (err) {
        if (status) status.textContent = "Sorry, that didn't go through. Please try again in a minute.";
      } finally {
        if (btn) btn.disabled = false;
      }
    });
  });
})();
