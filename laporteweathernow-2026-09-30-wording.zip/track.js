// Lightweight, privacy-friendly event tracking.
//
// Visit counting is ON. Counts go to GoatCounter (free, no cookies, no consent
// banner needed); the dashboard is at https://scoopanddude.goatcounter.com
// To turn counting off, empty the quotes below and publish the site again.
// The dashboard shows page views plus these events:
//   city-search, camp-map-search, camp-filter-*, camp-open-*, newsletter-signup,
//   trip-planned, trip-saved, trip-share, emergency-view, path-local, path-trip,
//   etsy/<listing>.
// Privacy: events never include town names, trips, or coordinates, page views
// are counted by path only (no ?lat=... query strings), and only the domain of
// an outside referring site is sent. No cookies.
const LPWN_GOATCOUNTER_CODE = "scoopanddude";

(function () {
  // Counts go straight to GoatCounter's /count endpoint with only what's listed
  // here: the page path (never the ?query), the page title or event label, and
  // for page views the site a visitor came from (its domain only). We don't load
  // GoatCounter's count.js, because it also sends the full query string and referrer.
  function gcUrl(params) {
    return "https://" + LPWN_GOATCOUNTER_CODE + ".goatcounter.com/count?" + new URLSearchParams(params).toString();
  }
  // Same delivery GoatCounter's own script uses (sendBeacon), with the
  // documented tracking-pixel method as a fallback.
  function beacon(url) {
    try {
      if (navigator.sendBeacon && navigator.sendBeacon(url)) return;
    } catch (e) { /* fall back to an image */ }
    const img = new Image();
    img.referrerPolicy = "no-referrer";
    img.src = url;
  }
  function externalReferrer() {
    try {
      if (!document.referrer) return "";
      const r = new URL(document.referrer);
      return r.origin === location.origin ? "" : r.origin;
    } catch (e) { return ""; }
  }

  function send(path, title) {
    if (!LPWN_GOATCOUNTER_CODE) return;
    try {
      beacon(gcUrl({ p: path, t: title || path, e: "true", rnd: Math.random().toString(36).slice(2) }));
    } catch (e) { /* never let analytics break the page */ }
  }

  /** lpwnTrack("camp-map-search", "50 mi") — labels must never include towns, trips, or coordinates. */
  window.lpwnTrack = function (path, title) {
    const clean = String(path || "").toLowerCase().replace(/[^a-z0-9/_-]+/g, "-").slice(0, 80);
    const label = String(title || "").slice(0, 120);
    if (!clean) return;
    if (window.LPWN_DEBUG) console.log("[track]", clean, label);
    (window.__lpwnEvents = window.__lpwnEvents || []).push([clean, label]);
    send(clean, label);
  };
  // Events logged before this file loaded (the pages' one-line stub queues them).
  (window.__lpwnQueue || []).splice(0).forEach(function (args) { window.lpwnTrack.apply(null, args); });

  // One page view per page load, counted by path only.
  if (LPWN_GOATCOUNTER_CODE) {
    try {
      beacon(gcUrl({ p: location.pathname || "/", t: document.title || "", r: externalReferrer(), rnd: Math.random().toString(36).slice(2) }));
    } catch (e) { /* ignore */ }
  }

  // Count clicks to Etsy anywhere on the site, one bucket per listing.
  document.addEventListener("click", function (e) {
    const a = e.target && e.target.closest ? e.target.closest("a[href]") : null;
    if (!a) return;
    let url;
    try { url = new URL(a.href, location.href); } catch (err) { return; }
    if (!/(^|\.)etsy\.com$/i.test(url.hostname)) return;
    const m = url.pathname.match(/\/listing\/(\d+)(?:\/([^/?#]+))?/);
    const bucket = m ? (m[2] || m[1]).slice(0, 50) : "shop";
    window.lpwnTrack("etsy/" + bucket, "from " + location.pathname);
  }, true);
})();
