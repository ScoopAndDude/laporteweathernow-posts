// Hard Hat Weather and Field Day Weather: the "Try it" box (rebuilt Oct. 11, 2026, from Scoop's
// list: "map-pin style field / job-site setup" and "multi-day windows view").
//
//  - A map (Leaflet + OpenStreetMap, no key) in the try-it form. Tap the map or drag the pin to check
//    that exact spot; searching, the quick picks and "Use my location" move the pin too. Leaflet only
//    loads when the map comes near the screen.
//  - The next 5 days as a strip of GO / DELAY / STOP cards above the call, from the same engine as the
//    5 AM text (wdCallFor), with the next clear stretch and any STOP days spelled out. Tap a day for
//    its full call.
//  - Saved sites, kept only in this browser. Hard Hat's are the live demo dashboard's own list
//    (wd_demo_sites_v1), so they show up there too; Field Day's have their own (fd_demo_fields_v1).
//    Each shows its call for the day picked, and a dot on the map in that call's color.
// Loaded after timeutil.js, weather.js and workday.js. The engine (workday.js) isn't changed: the
// 5 AM sender runs a copy of it.

const WD_LEAFLET = { css: "/leaflet.css?v=a783710282", js: "/leaflet.js?v=db49d009c8" };
const WD_OSM_TILES = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
const WD_OSM_ATTRIBUTION = '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors';
const WD_WEEK_DAYS = 5;
const WD_MAX_SITES = 12;   // the dashboard's own limit

let wdLeafletPromise = null;
/** Leaflet's script and style, loaded once, when first needed. */
function wdLoadLeaflet() {
  if (window.L && window.L.map) return Promise.resolve(window.L);
  if (wdLeafletPromise) return wdLeafletPromise;
  wdLeafletPromise = new Promise((resolve, reject) => {
    if (!document.querySelector('link[href^="/leaflet.css"]')) {
      const css = document.createElement("link");
      css.rel = "stylesheet";
      css.href = WD_LEAFLET.css;
      document.head.appendChild(css);
    }
    const s = document.createElement("script");
    s.src = WD_LEAFLET.js;
    s.async = true;
    s.onload = () => (window.L && window.L.map ? resolve(window.L) : reject(new Error("Leaflet didn't start")));
    s.onerror = () => reject(new Error("Leaflet didn't load"));
    document.head.appendChild(s);
  });
  wdLeafletPromise.catch(() => { wdLeafletPromise = null; });
  return wdLeafletPromise;
}

/* ---------- The next five days ---------- */

/** The calls for the next five days at a spot, today first: [{ ymd, r }]. A day the engine can't do is left out. */
function wdWeekDays(point, tradeKey, opts) {
  const o = opts || {};
  const now = o.now || new Date();
  const today = ymdInZone(now, point.tz);
  const out = [];
  for (let i = 0; i < WD_WEEK_DAYS; i++) {
    const ymd = addDaysYmd(today, i);
    try {
      const r = wdCallFor(point, tradeKey, ymd, Object.assign({}, o, { now }));
      if (r) out.push({ ymd, r });
    } catch (e) { /* a day past the forecast: no card */ }
  }
  return out;
}

// One or two words for what stops work, for the small day cards (the full reason is in the call).
const WD_SHORT_WHY = {
  alert: "Warning", season: "Season over", ice: "Ice", icy: "Icy", thunder: "Storms", winter: "Snow", rain: "Rain",
  dayhigh: "Too hot", rainahead: "Rain ahead", nocure: "No drying days", cure: "Rain too soon", gust: "Gusts", wind: "Wind",
  calm: "Calm air", wet: "Wet", heat: "Heat", chill: "Wind chill", cold: "Cold", hot: "Heat", dew: "Dew", humid: "Humid",
};

function wdShortWhy(r) {
  const stop = (r.reasons || []).filter((x) => x.level === "stop");
  if (!stop.length) return "";
  // The kind that stops the most hours speaks for the day.
  const hours = {};
  stop.forEach((x) => { hours[x.type] = (hours[x.type] || 0) + Math.max(1, Math.round((x.to - x.from) / WD_HOUR)); });
  const top = Object.keys(hours).sort((a, b) => (hours[b] - hours[a]) || (wdPriority({ type: a }) - wdPriority({ type: b })))[0];
  return WD_SHORT_WHY[top] || "";
}

function wdDayShort(ymd, today) {
  if (ymd === today) return "Today";
  if (ymd === addDaysYmd(today, 1)) return "Tomorrow";
  return weekdayOfYmd(ymd, "short");
}

/** What a day card says under the call. */
function wdDayNote(r) {
  const tz = r.tz;
  if (r.over) return "Workday over";
  if (r.call === "unknown") return r.cureGap ? "Too far out" : "No forecast yet";
  if (r.call === "stop") return wdShortWhy(r) || "No window";
  if (r.call === "delay" && r.startAt) return `Start ${wdTimeText(r.startAt, tz)}`;
  if (r.call === "go" && r.until) return `Wrap by ${wdTimeText(r.until, tz)}`;
  return r.restOfDay ? "Rest of day" : "All day";
}

function wdCallWord(r) {
  if (r.over) return "DONE";
  return r.call === "go" ? "GO" : r.call === "delay" ? "DELAY" : r.call === "stop" ? "STOP" : "NO CALL";
}

/** The next clear stretch and the STOP days, in one line. */
function wdWeekSummary(days, today) {
  const usable = days.filter((d) => !d.r.over);
  const name = (ymd) => wdDayShort(ymd, today);
  const runs = [];
  let cur = null;
  usable.forEach((d) => {
    if (d.r.call === "go") {
      if (cur && cur.last === addDaysYmd(d.ymd, -1)) { cur.last = d.ymd; cur.n++; } else { cur = { first: d.ymd, last: d.ymd, n: 1 }; runs.push(cur); }
    } else {
      cur = null;
    }
  });
  const stretch = runs.find((x) => x.n >= 2) || runs[0];
  const stops = usable.filter((d) => d.r.call === "stop");
  const parts = [];
  if (stretch) {
    parts.push(stretch.n >= 2
      ? `<span class="wd-week-ok">Next GO stretch: ${escapeHtml(name(stretch.first))}&ndash;${escapeHtml(name(stretch.last))}</span>`
      : `<span class="wd-week-ok">Next GO day: ${escapeHtml(name(stretch.first))}</span>`);
  } else if (usable.length) {
    parts.push(`<span class="wd-week-none">No GO day in the next ${usable.length === 1 ? "day" : usable.length + " days"}</span>`);
  }
  if (stops.length) {
    parts.push(`<span class="wd-week-stop">STOP: ${stops.map((d) => {
      const why = wdShortWhy(d.r);
      return escapeHtml(name(d.ymd)) + (why ? ` (${escapeHtml(why.toLowerCase())})` : "");
    }).join(", ")}</span>`);
  } else if (usable.length > 1) {
    parts.push(`<span class="wd-week-ok">No STOP days</span>`);
  }
  return { html: parts.join(" "), stretch };
}

/** The strip of day cards (buttons; data-day is the date) and its summary line. */
function wdWeekHtml(days, selected, now, tz) {
  const today = ymdInZone(now || new Date(), tz);
  const sum = wdWeekSummary(days, today);
  const inRun = (ymd) => sum.stretch && sum.stretch.n >= 2 && ymd >= sum.stretch.first && ymd <= sum.stretch.last;
  const cards = days.map((d) => {
    const r = d.r;
    const call = r.over ? "over" : r.call || "unknown";
    const label = `${wdDayShort(d.ymd, today) === "Today" || wdDayShort(d.ymd, today) === "Tomorrow" ? wdDayShort(d.ymd, today) + ", " : ""}${weekdayOfYmd(d.ymd, "long")} ${monthDayOfYmd(d.ymd)}: ${wdCallWord(r)}, ${wdDayNote(r)}`;
    return `<button type="button" class="wd-day wd-day-${call}${inRun(d.ymd) ? " wd-day-run" : ""}" data-day="${d.ymd}" aria-pressed="${d.ymd === selected}" aria-label="${escapeHtml(label)}">` +
      // "Tomorrow" doesn't fit a phone's narrow card: phones show the weekday instead.
      `<span class="wd-day-name"><span class="wd-day-long">${escapeHtml(wdDayShort(d.ymd, today))}</span><span class="wd-day-short">${escapeHtml(d.ymd === today ? "Today" : weekdayOfYmd(d.ymd, "short"))}</span></span>` +
      `<span class="wd-day-date">${escapeHtml(monthDayOfYmd(d.ymd))}</span>` +
      `<span class="wd-day-call">${escapeHtml(wdCallWord(r))}</span>` +
      `<span class="wd-day-note">${escapeHtml(wdDayNote(r))}</span>` +
      `</button>`;
  }).join("");
  return `<div class="wd-days5" role="group" aria-label="The next ${days.length} days">${cards}</div>` +
    (sum.html ? `<p class="wd-week-sum">${sum.html}</p>` : "");
}

/** "Today, Mon Oct 12" for today and tomorrow, "Wednesday, Oct 14" after that. */
function wdDayHeading(ymd, now, tz) {
  const today = ymdInZone(now || new Date(), tz);
  if (ymd === today || ymd === addDaysYmd(today, 1)) return wdDayTitle(ymd, now, tz);
  return `${weekdayOfYmd(ymd, "long")}, ${monthDayOfYmd(ymd)}`;
}

/* ---------- The whole try-it box ---------- */

/**
 * Runs the try-it box on /hardhat/ or /farm/. cfg: { product: "hardhat" | "farm", trades: [keys],
 * defaultTrade, noun ("job site" | "field"), storageKey, events: { check, pin, save, day },
 * notCovered (the 404 message), cta (HTML), filterResult(html) (optional), dashboard (address or null) }.
 */
function wdTryIt(cfg) {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const tradeSel = $("tradeSel"), startSel = $("startSel"), endSel = $("endSel");
  const form = $("checkForm"), input = $("siteInput"), errEl = $("checkError"), matchesEl = $("matches");
  const body = $("resultBody"), resultBox = $("result"), statusEl = $("resultStatus"), btn = $("checkBtn");
  const mapEl = $("pinMap"), pinNote = $("pinNote");
  const noun = cfg.noun, Noun = noun.charAt(0).toUpperCase() + noun.slice(1);
  const track = (what, label) => { if (what && typeof lpwnTrack === "function") lpwnTrack(what, label || ""); };
  const short = (name) => String(name || "").split(",")[0];

  tradeSel.innerHTML = cfg.trades.map((k) => `<option value="${k}">${escapeHtml(WD_TRADES[k].label)}</option>`).join("");
  const hourOpt = (h) => `<option value="${h}">${escapeHtml(wdHourWord(h, true).replace(/^noon$/, "Noon"))}</option>`;
  startSel.innerHTML = [5, 6, 7, 8, 9, 10].map(hourOpt).join("");
  endSel.innerHTML = [12, 13, 14, 15, 16, 17, 18, 19, 20].map(hourOpt).join("");

  /* ----- saved sites (this browser only) ----- */
  const validSite = (s) => s && typeof s.name === "string" && s.place && isFinite(s.place.lat) && isFinite(s.place.lon) &&
    WD_TRADES[s.trade] && Number.isInteger(s.start) && Number.isInteger(s.end) && s.start >= 0 && s.end <= 24 && s.end > s.start;
  function loadSites() {
    try {
      const v = JSON.parse(localStorage.getItem(cfg.storageKey) || "null");
      if (Array.isArray(v)) return v.filter(validSite).slice(0, WD_MAX_SITES);
    } catch (e) { /* private browsing or blocked storage: no saved sites */ }
    return [];
  }
  function storeSites() {
    try { localStorage.setItem(cfg.storageKey, JSON.stringify(state.sites)); return true; } catch (e) { return false; }
  }
  const keyOf = (lat, lon) => `${Number(lat).toFixed(4)},${Number(lon).toFixed(4)}`;

  const state = {
    place: WD_QUICK_PLACES[0], trade: cfg.defaultTrade, day: null, start: null, end: null, point: null, seq: 0,
    sites: loadSites(), sitePoints: new Map(), siteLoading: new Set(), siteFailed: new Set(),
  };

  function syncHours() {
    const t = wdTrade(state.trade);
    startSel.value = String(state.start != null ? state.start : t.start);
    endSel.value = String(state.end != null ? state.end : t.end);
  }
  syncHours();

  function showError(msg) {
    errEl.textContent = msg;
    errEl.hidden = !msg;
  }
  function loading() {
    resultBox.setAttribute("aria-busy", "true");
    btn.disabled = true;
    statusEl.textContent = "Checking the forecast...";
  }
  function done() {
    resultBox.removeAttribute("aria-busy");
    btn.disabled = false;
  }

  /* ----- the map ----- */
  let map = null, pin = null, dots = null;
  function pinIcon() {
    return L.divIcon({ className: "wd-pin", html: "<span></span>", iconSize: [28, 36], iconAnchor: [14, 34] });
  }
  function startMap() {
    if (map || !mapEl) return;
    wdLoadLeaflet().then((L) => {
      if (map) return;
      map = L.map(mapEl, { scrollWheelZoom: false, zoomControl: true }).setView([state.place.lat, state.place.lon], 11);
      L.tileLayer(WD_OSM_TILES, { maxZoom: 18, attribution: WD_OSM_ATTRIBUTION }).addTo(map);
      dots = L.layerGroup().addTo(map);
      pin = L.marker([state.place.lat, state.place.lon], { icon: pinIcon(), draggable: true, keyboard: true, title: `Your ${noun}`, alt: `Your ${noun}`, zIndexOffset: 1000 }).addTo(map);
      map.on("click", (e) => dropPin(e.latlng.lat, e.latlng.lng));
      pin.on("dragend", () => { const ll = pin.getLatLng(); dropPin(ll.lat, ll.lng); });
      mapEl.classList.add("wd-pinmap-on");
      drawDots();
      setTimeout(() => map.invalidateSize(), 80);
    }).catch(() => {
      mapEl.classList.add("wd-pinmap-off");
      mapEl.textContent = "The map didn't load. You can still type an address above.";
    });
  }
  if (mapEl) {
    if ("IntersectionObserver" in window) {
      const io = new IntersectionObserver((seen) => {
        if (seen.some((x) => x.isIntersecting)) { io.disconnect(); startMap(); }
      }, { rootMargin: "400px 0px" });
      io.observe(mapEl);
    } else {
      startMap();
    }
  }
  function movePin(lat, lon, zoom) {
    if (!map || !pin) return;
    pin.setLatLng([lat, lon]);
    map.setView([lat, lon], zoom || Math.max(map.getZoom(), 12), { animate: true });
  }
  function dropPin(lat, lon) {
    const p = { name: "Dropped pin", lat: Math.round(lat * 1e4) / 1e4, lon: Math.round(lon * 1e4) / 1e4, pin: true };
    if (pin) pin.setLatLng([p.lat, p.lon]);
    input.value = "";
    matchesEl.hidden = true;
    showError("");
    track(cfg.events.pin, state.trade);
    choose(p, true);
  }
  function drawDots() {
    if (!map || !dots) return;
    dots.clearLayers();
    state.sites.forEach((s, i) => {
      const r = siteCall(s);
      const call = !r ? "unknown" : r.over ? "over" : r.call;
      const dot = L.circleMarker([s.place.lat, s.place.lon], { radius: 8, weight: 2, color: "#fff", fillOpacity: 1, className: `wd-dot-${call}` });
      dot.bindTooltip(`${escapeHtml(s.name)}${r ? ": " + escapeHtml(wdCallWord(r)) : ""}`, { direction: "top" });
      dot.on("click", (e) => { L.DomEvent.stopPropagation(e); pickSite(i); });
      dot.addTo(dots);
    });
  }

  /* ----- checking a place ----- */
  async function run() {
    const mine = ++state.seq;
    loading();
    try {
      const point = await wdLoadPoint(state.place.lat, state.place.lon);
      if (mine !== state.seq) return;
      state.point = point;
      if (state.place.pin && point.place) state.place = Object.assign({}, state.place, { name: `Pin near ${point.place}` });
      render();
    } catch (e) {
      if (mine !== state.seq) return;
      const msg = e && e.status === 404
        ? `The National Weather Service doesn't forecast that spot. ${cfg.notCovered}`
        : "We couldn't reach the National Weather Service just now. Please try again in a minute.";
      body.innerHTML = `<p class="wd-headline">${escapeHtml(msg)}</p><button type="button" class="wd-btn wd-btn-ghost wd-btn-sm" id="retryBtn">Try again</button>`;
      $("retryBtn").addEventListener("click", run);
      statusEl.textContent = msg;
      if (pinNote) pinNote.textContent = msg;
    } finally {
      if (mine === state.seq) done();
    }
  }

  function hoursOpt(now) { return { now, start: Number(startSel.value), end: Number(endSel.value) }; }

  function render(focusDay) {
    const point = state.point;
    const now = new Date();
    const days = wdWeekDays(point, state.trade, hoursOpt(now));
    const today = ymdInZone(now, point.tz);
    if (!state.day || !days.some((d) => d.ymd === state.day)) {
      state.day = wdDefaultDay(point.tz, now) === "today" ? today : addDaysYmd(today, 1);
    }
    const pick = days.find((d) => d.ymd === state.day);
    const r = pick ? pick.r : wdCallFor(point, state.trade, state.day, hoursOpt(now));
    const savedAt = state.sites.findIndex((s) => keyOf(s.place.lat, s.place.lon) === keyOf(state.place.lat, state.place.lon));
    const placeLine = `<div class="wd-result-place"><strong>${escapeHtml(state.place.name)}</strong>` +
      `${point.place && point.place !== state.place.name && !state.place.pin ? `<span>NWS forecast point near ${escapeHtml(point.place)}</span>` : ""}</div>`;
    const saveRow = `<div class="wd-save" id="saveRow">${savedAt >= 0
      ? `<span class="wd-saved-note">&#10003; Saved as ${escapeHtml(state.sites[savedAt].name)}</span>`
      : `<button type="button" class="wd-linkbtn" id="saveOpen">&#9734; Save this ${escapeHtml(noun)}</button>`}</div>`;
    let html = wdResultHtml(point, r, short(state.place.name), now);
    if (cfg.filterResult) html = cfg.filterResult(html);
    body.innerHTML = placeLine + saveRow + wdWeekHtml(days, state.day, now, point.tz) + html +
      `<div class="wd-saved" id="savedBox"></div>` + cfg.cta;
    const head = body.querySelector(".wd-result-day");
    if (head) head.textContent = wdDayHeading(r.ymd, now, point.tz);
    body.querySelectorAll(".wd-days5 [data-day]").forEach((b) => b.addEventListener("click", () => {
      const was = state.day;
      state.day = b.dataset.day;
      if (state.day !== was && state.day > addDaysYmd(today, 1)) track(cfg.events.day, state.trade);
      render(true);
    }));
    if (focusDay) {
      const again = body.querySelector(`.wd-days5 [data-day="${state.day}"]`);
      if (again) again.focus();
    }
    const open = $("saveOpen");
    if (open) open.addEventListener("click", openSave);
    renderSites();
    const when = wdDayHeading(r.ymd, now, point.tz).split(",")[0];
    statusEl.textContent = `${when} at ${state.place.name}: ${r.label}.`;
    if (pinNote) {
      pinNote.innerHTML = `<strong>${escapeHtml(short(state.place.name))}</strong>, ${escapeHtml(when.toLowerCase() === "today" || when.toLowerCase() === "tomorrow" ? when.toLowerCase() : when)}: ` +
        `<span class="wd-pill wd-pill-mini ${WD_CALL_CLASS[r.call] || "wd-unknown"}">${escapeHtml(r.over ? "DONE" : wdCallWord(r))}</span> ` +
        `<a href="#result" class="wd-pin-jump">See the call</a>`;
    }
    if (pin) pin.setLatLng([state.place.lat, state.place.lon]);
  }

  /* ----- saving and showing saved sites ----- */
  function openSave() {
    const row = $("saveRow");
    if (!row) return;
    if (state.sites.length >= WD_MAX_SITES) {
      row.innerHTML = `<span class="wd-saved-note">You can save up to ${WD_MAX_SITES} ${noun}s here. Remove one below first.</span>`;
      return;
    }
    const def = short(state.place.name).replace(/^Pin near /, "").slice(0, 40);
    row.innerHTML = `<form class="wd-save-form" id="saveForm"><label for="saveName">Name this ${escapeHtml(noun)}</label>` +
      `<span class="wd-save-line"><input class="wd-input wd-input-sm" id="saveName" maxlength="40" value="${escapeHtml(def)}" autocomplete="off" />` +
      `<button type="submit" class="wd-btn wd-btn-primary wd-btn-sm">Save</button>` +
      `<button type="button" class="wd-linkbtn" id="saveCancel">Cancel</button></span>` +
      `<span class="wd-hint">Saved only in this browser${cfg.dashboard ? ", and shown on the live demo dashboard" : ""}.</span></form>`;
    const name = $("saveName");
    name.focus();
    name.select();
    $("saveCancel").addEventListener("click", () => render());
    $("saveForm").addEventListener("submit", (e) => {
      e.preventDefault();
      const site = {
        id: "u" + Date.now(),
        name: (name.value.replace(/\s+/g, " ").trim() || def || Noun).slice(0, 40),
        place: Object.assign({ name: state.place.name, lat: state.place.lat, lon: state.place.lon }, state.place.pin ? { pin: true } : {}),
        trade: state.trade, start: Number(startSel.value), end: Math.max(Number(endSel.value), Number(startSel.value) + 1),
      };
      state.sites.push(site);
      if (state.point) state.sitePoints.set(keyOf(site.place.lat, site.place.lon), state.point);
      const kept = storeSites();
      track(cfg.events.save, site.trade);
      render();
      if (!kept) {
        const note = body.querySelector(".wd-saved-note");
        if (note) note.textContent = "This browser won't keep saved sites (private browsing?), so it's only saved until you leave.";
      }
    });
  }

  function siteCall(s) {
    const pt = state.sitePoints.get(keyOf(s.place.lat, s.place.lon));
    if (!pt || !state.day) return null;
    try { return wdCallFor(pt, s.trade, state.day, { now: new Date(), start: s.start, end: s.end }); } catch (e) { return null; }
  }

  function loadSitePoints() {
    state.sites.forEach((s) => {
      const k = keyOf(s.place.lat, s.place.lon);
      if (state.sitePoints.has(k) || state.siteLoading.has(k) || state.siteFailed.has(k)) return;
      state.siteLoading.add(k);
      wdLoadPoint(s.place.lat, s.place.lon).then((pt) => {
        state.siteLoading.delete(k);
        state.sitePoints.set(k, pt);
        renderSites();
      }, () => {
        state.siteLoading.delete(k);
        state.siteFailed.add(k);
        renderSites();
      });
    });
  }

  function renderSites() {
    const box = $("savedBox");
    if (!box) return;
    loadSitePoints();
    drawDots();
    if (!state.sites.length) { box.innerHTML = ""; return; }
    const dayWord = state.point ? wdDayHeading(state.day, new Date(), state.point.tz).split(",")[0] : "";
    const here = keyOf(state.place.lat, state.place.lon);
    box.innerHTML = `<div class="wd-label">Your saved ${escapeHtml(noun)}s, ${escapeHtml(dayWord.toLowerCase() === "today" || dayWord.toLowerCase() === "tomorrow" ? dayWord.toLowerCase() : dayWord)}</div>` +
      `<ul class="wd-saved-list">${state.sites.map((s, i) => {
        const r = siteCall(s);
        const failed = state.siteFailed.has(keyOf(s.place.lat, s.place.lon));
        const call = r ? (r.over ? "DONE" : wdCallWord(r)) : failed ? "NO DATA" : "...";
        const cls = r ? (WD_CALL_CLASS[r.call] || "wd-unknown") : "wd-unknown";
        const current = keyOf(s.place.lat, s.place.lon) === here;
        return `<li${current ? ' class="wd-saved-here"' : ""}><button type="button" class="wd-saved-pick" data-pick="${i}"${current ? ' aria-current="true"' : ""}>` +
          `<span class="wd-pill wd-pill-mini ${cls}">${escapeHtml(call)}</span>` +
          `<span class="wd-saved-name">${escapeHtml(s.name)}</span>` +
          `<span class="wd-saved-meta">${escapeHtml(WD_TRADES[s.trade].label)} &middot; ${escapeHtml(short(s.place.name).replace(/^Pin near /, "near "))}</span></button>` +
          `<button type="button" class="wd-saved-x" data-remove="${i}" aria-label="Remove ${escapeHtml(s.name)}">&times;</button></li>`;
      }).join("")}</ul>` +
      (cfg.dashboard ? `<p class="wd-saved-more"><a href="${cfg.dashboard}">See them all, with the week at a glance, on the live demo dashboard &rarr;</a></p>` : "");
    box.querySelectorAll("[data-pick]").forEach((b) => b.addEventListener("click", () => pickSite(Number(b.dataset.pick))));
    box.querySelectorAll("[data-remove]").forEach((b) => b.addEventListener("click", () => {
      state.sites.splice(Number(b.dataset.remove), 1);
      storeSites();
      render();
    }));
  }

  function pickSite(i) {
    const s = state.sites[i];
    if (!s) return;
    if (cfg.trades.indexOf(s.trade) !== -1) {
      state.trade = s.trade;
      tradeSel.value = s.trade;
      state.start = s.start;
      state.end = s.end;
      syncHours();
    }
    input.value = s.place.pin ? "" : s.place.name;   // a dropped pin has no address to show
    matchesEl.hidden = true;
    showError("");
    choose(Object.assign({}, s.place), false, true);
  }

  /* ----- the form ----- */
  async function checkTyped() {
    const q = input.value.trim();
    matchesEl.hidden = true;
    if (q.length < 2) { showError("Type an address, town, or ZIP code."); input.focus(); return; }
    showError("");
    loading();
    let found;
    try {
      found = await wdFindPlace(q);
    } catch (e) {
      done();
      showError("Address search isn't answering right now. Try a town name or ZIP code, or tap the map.");
      return;
    }
    if (!found.length) {
      done();
      showError("We couldn't find that place. Try a town name or ZIP code, or tap the map.");
      return;
    }
    choose(found[0]);
    if (found.length > 1) {
      matchesEl.innerHTML = `Not the right spot? <ul>${found.slice(1, 5).map((m, i) => `<li><button type="button" data-i="${i + 1}">${escapeHtml(m.name)}</button></li>`).join("")}</ul>`;
      matchesEl.hidden = false;
      matchesEl.querySelectorAll("button").forEach((b) => b.addEventListener("click", () => { choose(found[Number(b.dataset.i)]); matchesEl.hidden = true; }));
    }
  }

  function choose(place, fromMap, quiet) {
    state.place = place;
    if (!fromMap) movePin(place.lat, place.lon, /^\d|,.*,/.test(place.name) ? 14 : 12);
    if (!quiet && !fromMap) track(cfg.events.check, state.trade);
    run();
  }

  form.addEventListener("submit", (e) => { e.preventDefault(); checkTyped(); });
  document.querySelectorAll("[data-place]").forEach((b) => b.addEventListener("click", () => {
    const p = WD_QUICK_PLACES[Number(b.dataset.place)];
    input.value = p.name;
    matchesEl.hidden = true;
    showError("");
    choose(p);
  }));
  tradeSel.addEventListener("change", () => {
    state.trade = tradeSel.value;
    state.start = null; state.end = null;
    syncHours();
    if (state.point) render();
  });
  [startSel, endSel].forEach((s) => s.addEventListener("change", () => {
    state.start = Number(startSel.value); state.end = Number(endSel.value);
    if (state.end <= state.start) { state.end = Math.min(20, state.start + 4); endSel.value = String(state.end); }
    if (state.point) render();
  }));
  $("useLocation").addEventListener("click", () => {
    if (!navigator.geolocation) { showError("This browser can't share its location. Type the address instead."); return; }
    showError("");
    loading();
    navigator.geolocation.getCurrentPosition((pos) => {
      input.value = "";
      choose({ name: "Your location", lat: Math.round(pos.coords.latitude * 1e4) / 1e4, lon: Math.round(pos.coords.longitude * 1e4) / 1e4 });
    }, () => { done(); showError("We couldn't get your location. Type the address instead, or tap the map."); }, { timeout: 10000, maximumAge: 300000 });
  });

  run();
  return { state };
}

/* =============================================================================
   The rest of the product page (Oct. 11, 2026, from Scoop's list: "clearer GO/DELAY/STOP
   examples, English and Spanish" and "a consistent Start free button, kept in reach on phones").
   wdProductPage({ event }) on /hardhat/ and /farm/ wires up:
   - The example calls (#examples): English/Español, and on phones and tablets, where the three
     cards sit in a row you swipe, buttons that jump to each one. Without this script the cards
     still swipe and the English texts show.
   - The Start free bar at the bottom of a phone screen, shown once the hero's buttons scroll away,
     and hidden again at the sign-up form, while typing, and at the very top.
   - A link to a question in the FAQ (like #faq-guarantee) opens that question.
   ============================================================================= */
function wdProductPage(cfg) {
  "use strict";
  const track = (what) => { if (what && typeof lpwnTrack === "function") lpwnTrack(what); };
  const reduce = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);

  /* ----- the example calls ----- */
  const sec = document.getElementById("examples");
  if (sec) {
    sec.classList.add("wd-calls-js");
    const row = sec.querySelector(".wd-calls");
    const tabs = [...sec.querySelectorAll("[data-call-tab]")];
    const langBtns = [...sec.querySelectorAll("[data-lang-btn]")];
    const setLang = (lang) => {
      langBtns.forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.langBtn === lang)));
      sec.querySelectorAll("[data-lang]").forEach((el) => { el.hidden = el.dataset.lang !== lang; });
    };
    langBtns.forEach((b) => b.addEventListener("click", () => {
      if (b.getAttribute("aria-pressed") === "true") return;
      setLang(b.dataset.langBtn);
      track(`${cfg.event}-examples-${b.dataset.langBtn}`);
    }));
    const light = (id) => tabs.forEach((t) => t.classList.toggle("is-on", t.dataset.callTab === id));
    tabs.forEach((t) => t.addEventListener("click", () => {
      const card = document.getElementById(t.dataset.callTab);
      if (!card || !row) return;
      const pad = parseFloat(getComputedStyle(row).paddingLeft) || 0;
      row.scrollTo({ left: Math.max(0, card.offsetLeft - pad), behavior: reduce ? "auto" : "smooth" });
      light(card.id);
    }));
    if (row && tabs.length && "IntersectionObserver" in window) {
      const io = new IntersectionObserver((entries) => {
        entries.forEach((en) => { if (en.isIntersecting) light(en.target.id); });
      }, { root: row, threshold: 0.6 });
      sec.querySelectorAll(".wd-call").forEach((c) => io.observe(c));
    }
  }

  /* ----- Start free, kept in reach on phones ----- */
  const bar = document.getElementById("stickyStart");
  const heroCtas = document.querySelector(".wd-hero .wd-cta-row");
  const signup = document.getElementById("start");
  if (bar && heroCtas && signup && "IntersectionObserver" in window) {
    let heroIn = true, signupIn = false, typing = false;
    const show = () => {
      const on = !heroIn && !signupIn && !typing;
      bar.classList.toggle("is-on", on);
      document.documentElement.classList.toggle("wd-sticky-on", on);
    };
    new IntersectionObserver((e) => { heroIn = e[e.length - 1].isIntersecting; show(); }).observe(heroCtas);
    new IntersectionObserver((e) => { signupIn = e[e.length - 1].isIntersecting; show(); }, { rootMargin: "0px 0px -15% 0px" }).observe(signup);
    const field = (el) => el && el.matches && el.matches("input:not([type=checkbox]):not([type=radio]):not([type=hidden]), select, textarea");
    document.addEventListener("focusin", (e) => { if (field(e.target)) { typing = true; show(); } });
    document.addEventListener("focusout", (e) => { if (field(e.target)) { typing = false; show(); } });
    bar.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => track(`${cfg.event}-sticky-start`)));
  }

  /* ----- a link to a question opens it ----- */
  const openTarget = () => {
    let el = null;
    try { el = location.hash.length > 1 ? document.getElementById(decodeURIComponent(location.hash.slice(1))) : null; } catch (e) { el = null; }
    if (el && el.tagName === "DETAILS") el.open = true;
  };
  window.addEventListener("hashchange", openTarget);
  document.addEventListener("click", (e) => {
    const a = e.target && e.target.closest ? e.target.closest('a[href^="#"]') : null;
    const el = a && a.getAttribute("href").length > 1 ? document.getElementById(a.getAttribute("href").slice(1)) : null;
    if (el && el.tagName === "DETAILS") el.open = true;
  });
  openTarget();
}
